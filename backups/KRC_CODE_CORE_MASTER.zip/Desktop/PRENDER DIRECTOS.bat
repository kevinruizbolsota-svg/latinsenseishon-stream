@echo off
title LATINSENSEISHON - PRENDER DIRECTOS 24/7
color 0A
echo ======================================================
echo    LATINSENSEISHON - PRENDIENDO DIRECTOS EN VIVO
echo ======================================================
echo.
echo Iniciando Guardi?n Centinela y Transmisi?n...
powershell -NoProfile -Command "Start-Process -FilePath 'C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe' -ArgumentList '-u stream_eterno.py' -WorkingDirectory 'C:\Users\kevin\StudioProdigio'"
echo.
echo Transmision enviada a Kick y Twitch con exito.
echo Ticker y Marco Retro TV activos.
echo.
timeout /t 3 >nul
exit
