@echo off
title LOS CALLE TV - PONER PROPAGANDA
color 0E
echo ======================================================
echo    EMITIENDO SPOT: PROPAGANDA OFICIAL KRC
echo ======================================================
echo.
powershell -NoProfile -Command "Set-Content -Path 'C:\Users\kevin\StudioProdigio\serie_activa.txt' -Value 'propaganda' -Encoding ASCII"
powershell -NoProfile -Command "try { Invoke-RestMethod -Uri 'https://latinsenseishon-stream.onrender.com/api/control/cambiar_serie' -Method POST -Body '{\"serie\":\"propaganda\"}' -ContentType 'application/json' -TimeoutSec 5 | Out-Null } catch {}"
echo Propaganda lanzada con exito.
timeout /t 2 >nul
exit
