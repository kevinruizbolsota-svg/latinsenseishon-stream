@echo off
title LOS CALLE TV - CAMBIAR A SUPERMAN
color 0B
echo ======================================================
echo    CAMBIANDO A: SUPERMAN (1941) BLOQUE 3 HORAS
echo ======================================================
echo.
powershell -NoProfile -Command "Set-Content -Path 'C:\Users\kevin\StudioProdigio\serie_activa.txt' -Value 'superman' -Encoding ASCII"
powershell -NoProfile -Command "try { Invoke-RestMethod -Uri 'https://latinsenseishon-stream.onrender.com/api/control/cambiar_serie' -Method POST -Body '{\"serie\":\"superman\"}' -ContentType 'application/json' -TimeoutSec 5 | Out-Null } catch {}"
echo Cambiado con exito a Superman.
timeout /t 2 >nul
exit
