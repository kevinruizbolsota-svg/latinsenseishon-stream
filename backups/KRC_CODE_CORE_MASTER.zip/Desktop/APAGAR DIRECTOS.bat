@echo off
title LATINSENSEISHON - APAGAR PC Y ACTIVAR NUBE 24/7
color 0A
echo ======================================================
echo    CAMBIANDO A TRANSMISION 24/7 EN LA NUBE (RENDER)
echo ======================================================
echo.
echo 1. Activando servidor en la nube...
powershell -NoProfile -Command "try { Invoke-RestMethod -Uri 'https://latinsenseishon-stream.onrender.com/api/control/toggle_stream' -Method POST -Body '{\"accion\":\"start\"}' -ContentType 'application/json' -TimeoutSec 6 | Out-Null } catch {}"
echo.
echo 2. Deteniendo procesos locales de este computador...
taskkill /F /IM ffmpeg.exe >nul 2>&1
powershell -NoProfile -Command "Get-Process python -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle -match 'stream' -or $_.CommandLine -match 'stream_eterno|dbz_stream' } | Stop-Process -Force -ErrorAction SilentlyContinue"
echo.
echo ======================================================
echo    NUBE ACTIVA! PUEDES APAGAR EL PC CON TOTAL TRANQUILIDAD
echo ======================================================
timeout /t 3 >nul
exit
