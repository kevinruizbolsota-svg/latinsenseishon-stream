@echo off
title LOS CALLE TV - CAMBIAR A POPEYE
color 0D
echo ======================================================
echo    CAMBIANDO A: POPEYE EL MARINO BLOQUE 3 HORAS
echo ======================================================
echo.
powershell -NoProfile -Command "Set-Content -Path 'C:\Users\kevin\StudioProdigio\serie_activa.txt' -Value 'popeye' -Encoding ASCII"
powershell -NoProfile -Command "try { Invoke-RestMethod -Uri 'https://latinsenseishon-stream.onrender.com/api/control/cambiar_serie' -Method POST -Body '{\"serie\":\"popeye\"}' -ContentType 'application/json' -TimeoutSec 5 | Out-Null } catch {}"
echo Cambiado con exito a Popeye.
timeout /t 2 >nul
exit
