@echo off
title LOS CALLE TV - CAMBIAR A NEZHA
color 0A
echo ======================================================
echo    CAMBIANDO A: NEZHA EL REY DRAGON (1979) BLOQUE 3H
echo ======================================================
echo.
powershell -NoProfile -Command "Set-Content -Path 'C:\Users\kevin\StudioProdigio\serie_activa.txt' -Value 'nezha' -Encoding ASCII"
powershell -NoProfile -Command "try { Invoke-RestMethod -Uri 'https://latinsenseishon-stream.onrender.com/api/control/cambiar_serie' -Method POST -Body '{\"serie\":\"nezha\"}' -ContentType 'application/json' -TimeoutSec 5 | Out-Null } catch {}"
echo Cambiado con exito a Nezha.
timeout /t 2 >nul
exit
