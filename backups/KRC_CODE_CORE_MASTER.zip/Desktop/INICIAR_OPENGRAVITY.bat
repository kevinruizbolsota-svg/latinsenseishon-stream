﻿@echo off
title OPENGRAVITY KRC - 24/7 AGENT RUNNER
cd /d "C:\Users\kevin\LATINSENSEISHON\OpenGravity"
node server.js
pause
