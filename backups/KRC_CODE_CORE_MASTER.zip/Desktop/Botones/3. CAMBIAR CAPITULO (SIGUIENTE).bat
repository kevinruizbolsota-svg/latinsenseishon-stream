@echo off
title [NEXT] CAMBIAR AL SIGUIENTE CAPITULO - LOS CALLE TV
color 0E
cd /d "C:\Users\kevin\StudioProdigio"

echo ============================================================
echo   [NEXT] CAMBIANDO AL SIGUIENTE CAP�TULO DE LA COLA...
echo ============================================================
echo.

"C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe" saltar_capitulo.py

echo.
echo ============================================================
echo   [OK] Siguiente cap�tulo cargado en vivo.
echo ============================================================
exit /b 0
