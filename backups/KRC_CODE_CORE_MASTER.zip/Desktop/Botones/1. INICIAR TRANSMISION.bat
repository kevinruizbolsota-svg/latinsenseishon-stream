@echo off
title [STREAM] INICIAR TRANSMISION - LOS CALLE TV
color 0A
cd /d "C:\Users\kevin\StudioProdigio"

echo ============================================================
echo   [STREAM] INICIANDO TRANSMISI�N 24/7 (TWITCH + KICK)
echo ============================================================
echo.

taskkill /IM ffmpeg.exe /F >nul 2>&1
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*dbz_stream*' -or $_.CommandLine -like '*stream_eterno*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }" >nul 2>&1

"C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe" -c "import json; p=r'C:\Users\kevin\StudioProdigio\stream_config.json'; cfg=json.load(open(p,encoding='utf-8-sig')); cfg['twitch']['activo']=True; cfg['kick']['activo']=True; json.dump(cfg,open(p,'w',encoding='utf-8'),indent=4,ensure_ascii=False); print('   -> Twitch: ACTIVO | Kick: ACTIVO')"

start "STREAM_ETERNO_KRC" "C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe" -u stream_eterno.py

echo.
echo ============================================================
echo   [OK] TRANSMISI�N EN MARCHA
echo ============================================================
exit /b 0
