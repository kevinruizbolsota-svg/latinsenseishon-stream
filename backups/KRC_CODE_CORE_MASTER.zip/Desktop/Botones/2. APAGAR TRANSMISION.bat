@echo off
title [OFF] APAGAR TRANSMISION - LOS CALLE TV
color 0C
cd /d "C:\Users\kevin\StudioProdigio"

echo ============================================================
echo   [OFF] APAGANDO TRANSMISI�N Y MOTORES DE STREAMING
echo ============================================================
echo.

taskkill /IM ffmpeg.exe /F >nul 2>&1
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*dbz_stream*' -or $_.CommandLine -like '*stream_eterno*' -or $_.CommandLine -like '*kabalion*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }" >nul 2>&1

echo ============================================================
echo   [OK] TRANSMISI�N APAGADA CORRECTAMENTE.
echo ============================================================
exit /b 0
