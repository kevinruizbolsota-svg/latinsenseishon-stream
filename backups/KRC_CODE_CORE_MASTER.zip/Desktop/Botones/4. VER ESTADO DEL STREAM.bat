@echo off
title [CHECK] ESTADO DEL STREAMING - KRC SENTINEL
color 0B
cd /d "C:\Users\kevin\StudioProdigio"

echo ============================================================
echo   [CHECK] AUDITOR�A EN TIEMPO REAL DEL DIRECTO (N8N SENTINEL)
echo ============================================================
echo.

"C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe" n8n_auditor_stream.py

echo.
echo ============================================================
echo   Presiona cualquier tecla para salir...
echo ============================================================
pause >nul
exit /b 0
