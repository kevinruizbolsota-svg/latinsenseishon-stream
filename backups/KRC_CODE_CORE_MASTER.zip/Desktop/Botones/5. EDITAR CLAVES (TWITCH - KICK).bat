@echo off
title [CONFIG] CONFIGURAR CLAVES DE TRANSMISION - LOS CALLE TV
color 0F
cd /d "C:\Users\kevin\StudioProdigio"

echo ============================================================
echo   [CONFIG] CONFIGURACI�N DE CLAVES Y PLATAFORMAS (TWITCH / KICK)
echo ============================================================
echo.
echo Abriendo stream_config.json en el Bloc de Notas...
echo Guarda los cambios (Ctrl+S) y cierra el archivo.
echo.

notepad.exe stream_config.json

echo.
echo Configuraci�n actualizada.
exit /b 0
