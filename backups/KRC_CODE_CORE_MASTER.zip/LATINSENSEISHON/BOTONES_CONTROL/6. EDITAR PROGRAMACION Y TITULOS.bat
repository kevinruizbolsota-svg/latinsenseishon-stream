@echo off
title LATINSENSEISHON - EDITAR PROGRAMACION
color 0D
notepad "C:\Users\kevin\StudioProdigio\titulos_programacion.json"