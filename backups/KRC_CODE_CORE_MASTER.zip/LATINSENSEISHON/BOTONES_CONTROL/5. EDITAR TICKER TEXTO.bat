@echo off
title LATINSENSEISHON - EDITAR TICKER
color 0D
notepad "C:\Users\kevin\StudioProdigio\TICKER_TEXTO.txt"