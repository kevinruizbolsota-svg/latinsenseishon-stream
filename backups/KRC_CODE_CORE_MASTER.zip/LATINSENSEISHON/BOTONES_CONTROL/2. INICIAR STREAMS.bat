@echo off
title LATINSENSEISHON - INICIAR STREAMS
color 0B
echo Iniciando Twitch y Kick...
start "" "C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe" "C:\Users\kevin\StudioProdigio\twitch_stream_cultural.py"
timeout /t 3 >nul
start "" "C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe" "C:\Users\kevin\StudioProdigio\stream_eterno.py"
echo Streams iniciados!
pause