@echo off
title LATINSENSEISHON - N8N DASHBOARD
color 09
echo Abriendo N8N...
start http://localhost:5678
pause