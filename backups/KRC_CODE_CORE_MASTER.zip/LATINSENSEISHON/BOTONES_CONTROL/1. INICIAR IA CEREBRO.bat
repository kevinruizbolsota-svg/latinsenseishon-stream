@echo off
title LATINSENSEISHON - IA CEREBRO MAESTRO
color 0A
echo.
echo  =====================================================
echo   LATINSENSEISHON - IA CEREBRO ACTIVO
echo   Reviviendo nuestra infancia en los barrios
echo  =====================================================
echo.
"C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe" "C:\Users\kevin\LATINSENSEISHON\IA_CEREBRO\twitch_ia_bot.py"
pause