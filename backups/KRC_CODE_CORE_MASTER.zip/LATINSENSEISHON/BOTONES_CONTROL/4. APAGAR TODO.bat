@echo off
title LATINSENSEISHON - APAGAR TODO
color 0C
echo Apagando todo el sistema LATINSENSEISHON...
taskkill /f /im ffmpeg.exe >nul 2>&1
taskkill /f /im python.exe >nul 2>&1
echo Sistema apagado.
pause