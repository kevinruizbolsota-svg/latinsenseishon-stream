@echo off
title LATINSENSEISHON - ESTADO DEL SISTEMA
color 0E
echo.
echo  === ESTADO LATINSENSEISHON ===
echo.
tasklist | findstr ffmpeg
tasklist | findstr python
echo.
echo  Logs recientes:
type "C:\Users\kevin\LATINSENSEISHON\STUDIO_LOGS\ia_cerebro.log" 2>nul | more
pause