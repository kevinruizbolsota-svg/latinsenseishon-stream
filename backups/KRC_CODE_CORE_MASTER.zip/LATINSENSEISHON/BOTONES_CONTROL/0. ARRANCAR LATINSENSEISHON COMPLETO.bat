@echo off
title LATINSENSEISHON - INICIAR TODO COMPLETO
color 0A
echo.
echo  =====================================================
echo   LATINSENSEISHON - INICIANDO SISTEMA COMPLETO
echo  =====================================================
echo.
echo [1/4] Iniciando IA Cerebro Maestro...
start "IA CEREBRO" "C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe" "C:\Users\kevin\LATINSENSEISHON\IA_CEREBRO\twitch_ia_bot.py"
timeout /t 2 >nul
echo [2/4] Iniciando Stream Twitch...
start "TWITCH STREAM" "C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe" "C:\Users\kevin\StudioProdigio\twitch_stream_cultural.py"
timeout /t 2 >nul
echo [3/4] Iniciando Stream Kick...
start "KICK STREAM" "C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe" "C:\Users\kevin\StudioProdigio\stream_eterno.py"
timeout /t 2 >nul
echo [4/4] Listo! Sistema LATINSENSEISHON activo!
echo.
echo  Twitch: https://www.twitch.tv/los_calle_tv
echo  Kick:   https://kick.com/los-calle-tv
echo  N8N:    http://localhost:5678
pause