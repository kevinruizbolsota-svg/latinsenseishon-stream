---
title: Latinsenseishon Cloud Runner 24-7
emoji: 📺
colorFrom: red
colorTo: purple
sdk: docker
app_port: 7860
pinned: false
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
