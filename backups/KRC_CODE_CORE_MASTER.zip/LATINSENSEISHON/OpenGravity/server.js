﻿require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const Groq = require('groq-sdk');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

console.log("==================================================");
console.log("🪐 OPENGRAVITY KRC — AGENTE SUPREMO 6 EVOLUCIONES");
console.log("==================================================");

const groqKey = process.env.GROQ_API_KEY;
const openRouterKey = process.env.OPENROUTER_API_KEY;
const token = process.env.TELEGRAM_BOT_TOKEN;
const allowedUser = process.env.TELEGRAM_ALLOWED_USER_ID;

if (!token || token.includes("tu_token")) {
    console.log("⚠️ AVISO: Configura tu TELEGRAM_BOT_TOKEN en el archivo .env para conectar Telegram.");
}

const groq = groqKey && !groqKey.includes("tu_clave") ? new Groq({ apiKey: groqKey }) : null;

// Memoria local de respaldo / fallback si Firebase no está vinculado
const MEMORY_FILE = path.join(__dirname, 'memoria_contexto.json');
let memoriaHistorial = [];
if (fs.existsSync(MEMORY_FILE)) {
    try {
        memoriaHistorial = JSON.parse(fs.readFileSync(MEMORY_FILE, 'utf-8'));
    } catch (e) {
        memoriaHistorial = [];
    }
}

function guardarMemoria(rol, contenido) {
    memoriaHistorial.push({ role: rol, content: contenido, date: new Date().toISOString() });
    if (memoriaHistorial.length > 50) memoriaHistorial.shift();
    fs.writeFileSync(MEMORY_FILE, JSON.stringify(memoriaHistorial, null, 2), 'utf-8');
}

// Cerebro LLM Multimodelo con Fallback automático
async function consultarCerebro(promptUsuario) {
    guardarMemoria("user", promptUsuario);
    
    // 1. Intentar Groq Llama 3.3 (Ultra rápido)
    if (groq) {
        try {
            console.log("⚡ Consultando Groq Llama 3.3...");
            const chatCompletion = await groq.chat.completions.create({
                messages: [
                    {
                        role: "system",
                        content: "Eres OpenGravity KRC, el agente supremo de Kevin Esteban Ruiz Calle. Tienes capacidades completas de desarrollo, análisis, voz y control 24/7. Responde de forma precisa, ejecutiva y leal."
                    },
                    ...memoriaHistorial.slice(-10).map(m => ({ role: m.role, content: m.content })),
                    { role: "user", content: promptUsuario }
                ],
                model: "llama-3.3-70b-versatile",
            });
            const respuesta = chatCompletion.choices[0]?.message?.content || "Sin respuesta";
            guardarMemoria("assistant", respuesta);
            return respuesta;
        } catch (err) {
            console.log("⚠️ Falló Groq, activando fallback OpenRouter:", err.message);
        }
    }

    // 2. Fallback OpenRouter
    if (openRouterKey && !openRouterKey.includes("tu_clave")) {
        try {
            console.log("🌐 Consultando OpenRouter...");
            const res = await axios.post("https://openrouter.ai/api/v1/chat/completions", {
                model: "meta-llama/llama-3.3-70b-instruct:free",
                messages: [
                    { role: "system", content: "Eres OpenGravity KRC." },
                    { role: "user", content: promptUsuario }
                ]
            }, {
                headers: { "Authorization": `Bearer ${openRouterKey}` }
            });
            const r = res.data.choices[0]?.message?.content;
            guardarMemoria("assistant", r);
            return r;
        } catch (e) {
            console.log("⚠️ Falló OpenRouter:", e.message);
        }
    }

    return "⚠️ [OpenGravity]: Por favor configura tus API Keys en el archivo .env para activar el cerebro.";
}

// Inicializar Bot si el token es válido
if (token && !token.includes("tu_token")) {
    const bot = new TelegramBot(token, { polling: true });

    bot.on('message', async (msg) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();

        // Control de seguridad por ID
        if (allowedUser && allowedUser !== userId && !allowedUser.includes("tu_id")) {
            console.log(`⛔ Acceso no autorizado bloqueado: Usuario ${userId}`);
            return bot.sendMessage(chatId, "⛔ Acceso denegado. Este agente OpenGravity es privado.");
        }

        const texto = msg.text;
        console.log(`📩 Mensaje recibido de ${msg.from.first_name}: ${texto}`);

        // Responder con cerebro IA
        const respuesta = await consultarCerebro(texto);
        bot.sendMessage(chatId, respuesta);
    });

    console.log("✅ Bot de Telegram activo y escuchando...");
} else {
    console.log("ℹ️ OpenGravity base lista. Esperando credenciales en .env.");
}
