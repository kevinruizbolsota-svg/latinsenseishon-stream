"""
╔══════════════════════════════════════════════════════════════════════╗
║   LATINSENSEISHON — IA CEREBRO MAESTRO                              ║
║   Reviviendo nuestra infancia en los barrios                         ║
╚══════════════════════════════════════════════════════════════════════╝

Orquesta todo el ecosistema de IA:
  - Actualiza títulos y categorías en Twitch automáticamente
  - Bot de chat inteligente con respuestas IA, encuestas y predicciones
  - Actualiza el ticker superior con bienvenida + programa + próximo + gracias
  - Monitorea el estado del stream y lo reactiva si se cae
  - Publica anuncios en el chat cada N minutos
  - Responde preguntas del chat con IA (marcadas como [IA])
"""

import urllib.request, urllib.error
import json, time, random, threading, subprocess, ctypes
from pathlib import Path
from datetime import datetime

# ─── RUTAS ───────────────────────────────────────────────────────────────────
STUDIO       = Path(r"C:\Users\kevin\StudioProdigio")
LSROOT       = Path(r"C:\Users\kevin\LATINSENSEISHON")
CFG          = json.loads((LSROOT / "IA_CEREBRO" / "configs" / "maestro.json").read_text(encoding="utf-8"))
TICKER_FILE  = Path(CFG["ticker_texto"])
TITLES_FILE  = Path(CFG["programacion_twitch"])
LOG_FILE     = LSROOT / "STUDIO_LOGS" / "ia_cerebro.log"

TWITCH_CFG   = CFG["canales"]["twitch"]
ACCESS_TOKEN = TWITCH_CFG["access_token"]
CLIENT_ID    = TWITCH_CFG["client_id"]
USER_ID      = TWITCH_CFG["user_id"]

PYTHON       = r"C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe"
STREAM_TWITCH= CFG["ia_activas"]["stream_twitch"]
STREAM_KICK  = CFG["ia_activas"]["stream_kick"]

# ─── LOG ─────────────────────────────────────────────────────────────────────
def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except:
        pass

# ─── TWITCH API ───────────────────────────────────────────────────────────────
def twitch_patch(endpoint, payload):
    url = f"https://api.twitch.tv/helix/{endpoint}"
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={
        "Client-Id": CLIENT_ID,
        "Authorization": f"Bearer {ACCESS_TOKEN}",
        "Content-Type": "application/json"
    }, method="PATCH")
    try:
        with urllib.request.urlopen(req) as r:
            return r.status
    except urllib.error.HTTPError as e:
        log(f"[API PATCH ERROR] {e.code}: {e.read().decode()}")
        return e.code

def twitch_post(endpoint, payload):
    url = f"https://api.twitch.tv/helix/{endpoint}"
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={
        "Client-Id": CLIENT_ID,
        "Authorization": f"Bearer {ACCESS_TOKEN}",
        "Content-Type": "application/json"
    }, method="POST")
    try:
        with urllib.request.urlopen(req) as r:
            return json.loads(r.read().decode()) if r.status != 204 else {"status": 204}
    except urllib.error.HTTPError as e:
        log(f"[API POST ERROR] {e.code}: {e.read().decode()}")
        return None

def twitch_get(endpoint):
    url = f"https://api.twitch.tv/helix/{endpoint}"
    req = urllib.request.Request(url, headers={
        "Client-Id": CLIENT_ID,
        "Authorization": f"Bearer {ACCESS_TOKEN}"
    })
    try:
        with urllib.request.urlopen(req) as r:
            return json.loads(r.read().decode())
    except:
        return None

# ─── FUNCIONES IA ─────────────────────────────────────────────────────────────
def get_current_program():
    """Detecta el programa actual en reproducción"""
    titles_map = {}
    if TITLES_FILE.exists():
        try:
            titles_map = json.loads(TITLES_FILE.read_text(encoding="utf-8"))
        except:
            pass

    videos = sorted([p for p in (STUDIO / "twitch_to_play").glob("*.mp4")
                     if p.stat().st_size > 1_000_000])
    if not videos:
        return None, None, None

    current = videos[0]
    nxt = videos[1] if len(videos) > 1 else None

    current_meta = titles_map.get(current.name, {})
    next_meta = titles_map.get(nxt.name, {}) if nxt else {}

    current_title = current_meta.get("twitch_title", f"🔴 {current.stem}")
    next_title = next_meta.get("twitch_title", f"🔜 {nxt.stem}") if nxt else "🔜 ¡Más clásicos pronto!"

    return current.name, current_title, next_title

def update_ticker(current_title, next_title):
    """Actualiza el texto del ticker superior con bienvenida + programa + próximo + gracias"""
    texto = (
        f"🎉 ¡Bienvenido a LOS CALLE TV — LATINSENSEISHON! — "
        f"REVIVIENDO NUESTRA INFANCIA EN LOS BARRIOS — "
        f"📺 AHORA: {current_title} — "
        f"⏭️ PRÓXIMAMENTE: {next_title} — "
        f"💛 ¡Gracias por acompañarnos en este viaje nostálgico, barrio! "
        f"Síguenos en Twitch & Kick para clásicos 24/7 —"
    )
    try:
        TICKER_FILE.write_text(texto, encoding="utf-8")
        log(f"[TICKER ACTUALIZADO] {texto[:80]}...")
    except Exception as e:
        log(f"[TICKER ERROR] {e}")

def update_twitch_title(title):
    """Cambia el título del canal en Twitch"""
    status = twitch_patch(f"channels?broadcaster_id={USER_ID}", {"title": title})
    if status == 204:
        log(f"[TITULO TWITCH] ✅ Actualizado: {title}")
    return status

def send_chat_announcement(msg, color="orange"):
    """Envía un anuncio destacado en el chat de Twitch"""
    result = twitch_post(
        f"chat/announcements?broadcaster_id={USER_ID}&moderator_id={USER_ID}",
        {"message": msg, "color": color}
    )
    if result:
        log(f"[ANUNCIO CHAT] {color.upper()}: {msg}")

def create_poll(title, choices, duration=60):
    """Lanza una encuesta en el canal"""
    result = twitch_post("polls", {
        "broadcaster_id": USER_ID,
        "title": title,
        "choices": [{"title": c} for c in choices],
        "duration": duration
    })
    if result and result.get("data"):
        log(f"[ENCUESTA CREADA] '{title}' — {len(choices)} opciones")
    return result

def create_prediction(title, outcomes, duration=120):
    """Lanza una predicción de puntos del canal"""
    result = twitch_post("predictions", {
        "broadcaster_id": USER_ID,
        "title": title,
        "outcomes": [{"title": o} for o in outcomes],
        "prediction_window": duration
    })
    if result and result.get("data"):
        log(f"[PREDICCION CREADA] '{title}'")
    return result

def check_stream_live():
    """Verifica si el stream de Twitch está en vivo"""
    data = twitch_get(f"streams?user_id={USER_ID}")
    if data and data.get("data"):
        return True
    return False

def revive_stream():
    """Reactiva el stream de Twitch si se cayó"""
    import subprocess
    log("[WATCHDOG] ⚠️  Stream caído — Reactivando Twitch...")
    subprocess.Popen([PYTHON, STREAM_TWITCH])
    time.sleep(10)
    log("[WATCHDOG] ✅  Stream Twitch relanzado")

# ─── FRASES IA PARA EL CHAT ───────────────────────────────────────────────────
FRASES_BIENVENIDA = [
    "¡Bienvenidos al barrio digital! 🏘️ LOS CALLE TV está al aire — LATINSENSEISHON presente!",
    "¡Qué alegría tenerte aquí! 🎉 Siéntate y disfruta la nostalgia — somos LOS CALLE TV!",
    "¡Ey parcero/a! Bienvenido a LOS CALLE TV 📺 — Reviviendo lo mejor de nuestra infancia!",
]
FRASES_DURANTE = [
    "¿Te acuerdas de esta escena? 👀 ¡Cuéntanos en el chat!",
    "¡Esto es lo que se llama televisión de verdad! 🔥 ¿Qué serie quieres ver después?",
    "📢 ¡Comparte el canal con quien creció viendo esto! Hagamos crecer el barrio digital 🏘️",
]
ENCUESTAS_AUTOMATICAS = [
    {
        "title": "¿Qué debemos transmitir después?",
        "choices": ["Popeye el Marino", "El Chavo del 8", "Tom y Jerry", "Dragon Ball Original"]
    },
    {
        "title": "¿Cuál fue tu caricatura favorita de la infancia?",
        "choices": ["Dragon Ball Z", "Superman Clásico", "El Chavo", "Otros clásicos"]
    },
    {
        "title": "¿A qué hora ves LOS CALLE TV con más frecuencia?",
        "choices": ["Mañana ☀️", "Tarde 🌤️", "Noche 🌙", "Madrugada 🦉"]
    }
]

# ─── BUCLES PRINCIPALES ───────────────────────────────────────────────────────
last_file   = None
poll_timer  = 0
greet_timer = 0
watch_timer = 0

def loop_principal():
    global last_file, poll_timer, greet_timer, watch_timer

    prevent_sleep()
    log("╔══════════════════════════════════════════════╗")
    log("║  LATINSENSEISHON — IA CEREBRO ACTIVO 🧠      ║")
    log("╚══════════════════════════════════════════════╝")

    while True:
        try:
            prevent_sleep()
            now = time.time()

            current_file, current_title, next_title = get_current_program()

            # 1. Actualizar ticker siempre que haya programa
            if current_title:
                update_ticker(current_title, next_title)

            # 2. Cambiar título y anunciar si cambió el programa
            if current_file and current_file != last_file:
                update_twitch_title(current_title)
                send_chat_announcement(
                    f"📺 AHORA TRANSMITIENDO: {current_title} | LOS CALLE TV — LATINSENSEISHON",
                    color="orange"
                )
                if next_title:
                    time.sleep(3)
                    send_chat_announcement(
                        f"⏭️ PRÓXIMAMENTE: {next_title} — ¡No te lo pierdas!",
                        color="blue"
                    )
                last_file = current_file
                poll_timer = now  # Reset timer de encuesta

            # 3. Encuesta automática cada 25 minutos
            if now - poll_timer > 25 * 60:
                encuesta = random.choice(ENCUESTAS_AUTOMATICAS)
                create_poll(encuesta["title"], encuesta["choices"], duration=120)
                poll_timer = now

            # 4. Frase de animación en chat cada 15 minutos
            if now - greet_timer > 15 * 60:
                frase = random.choice(FRASES_DURANTE)
                send_chat_announcement(frase, color="green")
                greet_timer = now

            # 5. Watchdog: verificar stream cada 5 minutos
            if now - watch_timer > 5 * 60:
                if not check_stream_live():
                    revive_stream()
                else:
                    log("[WATCHDOG] ✅ Stream Twitch ACTIVO")
                watch_timer = now

        except Exception as e:
            log(f"[ERROR CEREBRO] {e}")

        time.sleep(60)  # Ciclo cada 60 segundos

def prevent_sleep():
    try:
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | 0x00000001 | 0x00000040)
    except:
        pass

if __name__ == "__main__":
    loop_principal()
