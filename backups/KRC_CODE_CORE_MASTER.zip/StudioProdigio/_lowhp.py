﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\player.gd")
t = p.read_text(encoding="utf-8")

# low health vignette baseline when not flashing from hit
old_flash_fade = r'''	if hit_flash and hit_flash.color.a > 0.0:
		hit_flash.color.a = max(hit_flash.color.a - delta * 1.5, 0.0)
	_time_since_hit += delta'''
new_flash_fade = r'''	if hit_flash and hit_flash.color.a > 0.0:
		hit_flash.color.a = max(hit_flash.color.a - delta * 1.5, 0.0)
	# low health warning tint baseline
	if hit_flash and health > 0 and health <= 30 and _time_since_hit > 0.4:
		var target_a = 0.12 if health <= 15 else 0.06
		if hit_flash.color.a < target_a:
			hit_flash.color.a = min(hit_flash.color.a + delta * 0.5, target_a)
	_time_since_hit += delta'''
if old_flash_fade in t:
    t = t.replace(old_flash_fade, new_flash_fade)

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
