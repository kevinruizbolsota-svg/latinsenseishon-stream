import sys, json, time
sys.path.insert(0, r"C:\Users\kevin\StudioProdigio")
import yt_dlp

# Try to find downloadable videos for different series
# Use "shorts" or shorter videos that are less likely to be restricted
series_queries = [
    "El Chavo del 8 completo",
    "Dragon Ball Z episodio",
    "Los Simpsons episodio",
    "Bob Esponja episodio",
    "Naruto episodio",
    "Coraje perro cobarde episodio",
    "Dexter laboratorio episodio",
    "Johnny Bravo episodio",
    "Avatar Aang episodio",
    "Kim Possible episodio",
]

working = {}
for query in series_queries:
    try:
        opts = {"extract_flat": True, "quiet": True, "default_search": "ytsearch5"}
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(f"ytsearch5:{query}", download=False)
            entries = info.get("entries", [])
            vids = []
            for e in entries:
                vid_id = e.get("id", "")
                title = e.get("title", "")
                duration = e.get("duration", 0)
                # Prefer shorter videos (under 30 min) that are more likely downloadable
                if vid_id and duration and duration < 1800:
                    vids.append({"id": vid_id, "title": title, "duration": duration})
            if vids:
                key = query.split(" ")[0:3]
                key = " ".join(key)
                working[key] = vids[:3]
                print(f"OK: {key} - {len(vids[:3])} videos")
            time.sleep(2)
    except Exception as e:
        print(f"FAIL: {query}: {str(e)[:60]}")

# Test download of first video from each series
print("\n=== Testing downloads ===")
test_results = {}
for key, vids in working.items():
    vid = vids[0]
    try:
        opts = {"format": "best", "quiet": True, "no_warnings": True, "skip_download": True}
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(f"https://www.youtube.com/watch?v={vid['id']}", download=False)
            formats = info.get("formats", [])
            print(f"  {key}: {len(formats)} formats available, duration={info.get('duration',0)}s")
            test_results[key] = True
    except Exception as e:
        print(f"  {key}: {str(e)[:60]}")
        test_results[key] = False

# Save working series
with open(r"C:\Users\kevin\StudioProdigio\videos_test.json", "w", encoding="utf-8") as f:
    json.dump(working, f, ensure_ascii=False, indent=2)
print(f"\nTotal series with testable videos: {len(working)}")
print(f"Downloadable: {sum(1 for v in test_results.values() if v)}")
