﻿import wave, struct, math, random, os
out = r"C:\Users\kevin\Documents\COLWAR_NUEVO"
sr = 44100

def write_wav(name, samples):
    path = os.path.join(out, name)
    with wave.open(path, 'w') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        data = b''.join(struct.pack('<h', max(-32767,min(32767,int(s*32767)))) for s in samples)
        w.writeframes(data)
    print(name, len(samples))

random.seed(1)
# shot: noise burst
dur = 0.18
n = int(sr*dur)
s=[]
for i in range(n):
    t=i/sr
    env = math.exp(-t*28)
    s.append((random.random()*2-1)*0.7*env + math.sin(2*math.pi*120*t)*0.2*env)
write_wav('sfx_shot.wav', s)

# shot mg: sharper
dur=0.09
n=int(sr*dur); s=[]
for i in range(n):
    t=i/sr; env=math.exp(-t*45)
    s.append((random.random()*2-1)*0.6*env + math.sin(2*math.pi*160*t)*0.15*env)
write_wav('sfx_shot_fast.wav', s)

# reload
dur=0.5; n=int(sr*dur); s=[0.0]*n
for click_t, freq, amp in [(0.05,800,0.5),(0.18,600,0.4),(0.35,900,0.45)]:
    ci=int(click_t*sr); cl=int(0.03*sr)
    for i in range(cl):
        if ci+i<n:
            t=i/sr; env=math.exp(-t*80)
            s[ci+i]+=math.sin(2*math.pi*freq*t)*amp*env
write_wav('sfx_reload.wav', s)

# hit
dur=0.12; n=int(sr*dur); s=[]
for i in range(n):
    t=i/sr; env=math.exp(-t*35)
    s.append((random.random()*2-1)*0.4*env + math.sin(2*math.pi*90*t)*0.5*env)
write_wav('sfx_hit.wav', s)

# empty
dur=0.06; n=int(sr*dur); s=[]
for i in range(n):
    t=i/sr; env=math.exp(-t*60)
    s.append(math.sin(2*math.pi*1200*t)*0.4*env)
write_wav('sfx_empty.wav', s)

# hurt
dur=0.25; n=int(sr*dur); s=[]
for i in range(n):
    t=i/sr; env=math.exp(-t*18)
    s.append((random.random()*2-1)*0.3*env + math.sin(2*math.pi*70*t)*0.5*env)
write_wav('sfx_hurt.wav', s)

# kill/ding
dur=0.18; n=int(sr*dur); s=[]
for i in range(n):
    t=i/sr; env=math.exp(-t*12)
    s.append((math.sin(2*math.pi*880*t)+math.sin(2*math.pi*1320*t)*0.5)*0.25*env)
write_wav('sfx_kill.wav', s)

print('done')
