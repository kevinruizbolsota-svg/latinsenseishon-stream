import zipfile, os
base=r"C:\Users\kevin\Downloads\COLWAR"
zs=['a-forest-3-with-a-road-at-night-for-game.zip','pack-de-armas.zip','m4-fps-weapon-animations-pack-v1.zip','akmn-zenitco.zip','game-ready-military-base-asset-pack.zip','scene.zip','neptunia-sword-pack.zip','hero-guinevere-summer-breeze.zip','auric-warlord-the-gilded-conqueror.zip','peak-cliff-mountain-rock.zip']
for z in zs:
    p=os.path.join(base,z)
    if os.path.exists(p):
        print('\n==',z)
        try:
            with zipfile.ZipFile(p) as zf:
                for n in zf.namelist()[:15]: print(' ',n)
        except Exception as e: print(' err',e)
