const fs = require('fs');
const p = 'C:/Users/kevin/StudioProdigio/elephant-goldfish-model/pyproject.toml';

let toml = fs.readFileSync(p, 'utf8');
if (!toml.includes('[tool.setuptools.packages.find]')) {
  toml += '\n\n[tool.setuptools.packages.find]\ninclude = ["agents*", "adapters*", "skills*"]\n';
  fs.writeFileSync(p, toml, 'utf8');
  console.log('pyproject.toml configurado correctamente con packages.find');
}
