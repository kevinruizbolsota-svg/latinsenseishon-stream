﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.tscn")
t = p.read_text(encoding="utf-8")

# add start and pause menus at end of UI (after HitMarker)
old_end_ui = r'''[node name="HitMarker" type="Label" parent="UI"]
anchors_preset = 8
anchor_left = 0.5
anchor_top = 0.5
anchor_right = 0.5
anchor_bottom = 0.5
offset_left = -20.0
offset_top = -22.0
offset_right = 20.0
offset_bottom = 22.0
theme_override_colors/font_color = Color(1, 0.9, 0.9, 1)
text = ""
horizontal_alignment = 1
vertical_alignment = 1'''

new_end_ui = old_end_ui + r'''

[node name="MenuInicio" type="ColorRect" parent="UI"]
anchors_preset = 15
anchor_right = 1.0
anchor_bottom = 1.0
grow_horizontal = 2
grow_vertical = 2
color = Color(0.02, 0.03, 0.05, 0.92)

[node name="Titulo" type="Label" parent="UI/MenuInicio"]
anchors_preset = 5
anchor_left = 0.5
anchor_right = 0.5
offset_left = -300.0
offset_top = 180.0
offset_right = 300.0
offset_bottom = 240.0
theme_override_font_sizes/font_size = 42
text = "COLWAR - OPERACIÓN BASE"
horizontal_alignment = 1

[node name="Sub" type="Label" parent="UI/MenuInicio"]
anchors_preset = 5
anchor_left = 0.5
anchor_right = 0.5
offset_left = -320.0
offset_top = 250.0
offset_right = 320.0
offset_bottom = 320.0
text = "Defiende la base. Repara barricadas. Sobrevive a las rondas."
horizontal_alignment = 1

[node name="Iniciar" type="Label" parent="UI/MenuInicio"]
anchors_preset = 5
anchor_left = 0.5
anchor_right = 0.5
offset_left = -260.0
offset_top = 360.0
offset_right = 260.0
offset_bottom = 400.0
text = "Presiona ENTER para jugar"
horizontal_alignment = 1

[node name="Controles" type="Label" parent="UI/MenuInicio"]
anchors_preset = 5
anchor_left = 0.5
anchor_right = 0.5
offset_left = -360.0
offset_top = 430.0
offset_right = 360.0
offset_bottom = 520.0
text = "WASD mover | Mouse mirar | Click disparar | 1/2/3 armas | R recargar | E/F reparar | ESC pausa"
horizontal_alignment = 1

[node name="Pausa" type="ColorRect" parent="UI"]
visible = false
anchors_preset = 15
anchor_right = 1.0
anchor_bottom = 1.0
grow_horizontal = 2
grow_vertical = 2
color = Color(0, 0, 0, 0.55)

[node name="Txt" type="Label" parent="UI/Pausa"]
anchors_preset = 8
anchor_left = 0.5
anchor_top = 0.5
anchor_right = 0.5
anchor_bottom = 0.5
offset_left = -200.0
offset_top = -40.0
offset_right = 200.0
offset_bottom = 40.0
theme_override_font_sizes/font_size = 32
text = "PAUSA\nESC continuar | ENTER reiniciar"
horizontal_alignment = 1
vertical_alignment = 1'''

if old_end_ui in t:
    t = t.replace(old_end_ui, new_end_ui)

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
