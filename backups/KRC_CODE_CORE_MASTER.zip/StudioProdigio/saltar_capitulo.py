"""
SALTAR AL SIGUIENTE CAPITULO EN VIVO
Mueve el capítulo actual a dbz_played y reinicia el stream para que tome el siguiente en cola.
"""
import shutil, subprocess, time, json
from pathlib import Path

STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
TO_PLAY = STUDIO / "dbz_to_play"
PLAYED = STUDIO / "dbz_played"
STATE = STUDIO / "dbz_stream_state.json"
PROGRESS = STUDIO / "dbz_progress.txt"

def saltar():
    caps = sorted([p for p in TO_PLAY.glob("*.mp4") if not p.name.startswith("_")])
    if not caps:
        print("No hay capítulos en dbz_to_play.")
        return
    
    actual = caps[0]
    print(f"Saltando capítulo actual: {actual.name}")
    
    # 1. Matar ffmpeg temporalmente
    subprocess.run(["taskkill", "/IM", "ffmpeg.exe", "/F"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    # 2. Mover a played
    dest = PLAYED / actual.name
    try:
        shutil.move(str(actual), str(dest))
        print(f"Movido a dbz_played: {dest.name}")
    except Exception as e:
        print(f"Error moviendo: {e}")
        
    # 3. Limpiar estado anterior
    STATE.unlink(missing_ok=True)
    PROGRESS.unlink(missing_ok=True)
    
    print("Capítulo cambiado con éxito. El supervisor reanudará con el siguiente.")

if __name__ == "__main__":
    saltar()
