﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\player.gd")
t = p.read_text(encoding="utf-8")
t = t.replace('var near_b = _nearest_barricade(2.6)', 'var near_b = _nearest_barricade(3.5)')
t = t.replace('hint.text = "[E] / Cuadrado: reparar tabla (%d/%d)" % [near_b.boards_up, near_b.boards_total]',
              'hint.text = "[E / F] MANTENER: reparar tabla (%d/%d)" % [near_b.boards_up, near_b.boards_total]')
p.write_text(t, encoding="utf-8", newline="\n")
print("ok")
