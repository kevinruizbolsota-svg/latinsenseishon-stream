"""
KABALION STREAM MANAGER 24/7 - Gestor robusto de streaming
Auto-reinicio, monitoreo, y gestion de plataformas
"""
import subprocess, time, json, os, sys, threading
from pathlib import Path
from datetime import datetime

# === CONFIGURACION ===
FFMPEG = r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe"
STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
CONFIG_FILE = STUDIO / "stream_config.json"
VIDEO_DIR = Path(r"C:\Users\kevin\StudioProdigio\dbz_to_play")
LOG_FILE = STUDIO / "stream_manager.log"

# Plataformas y sus RTMP bases
RTMP_BASES = {
    "kick": "rtmps://fa723794a661.global-contribute.live-video.net:443/app/",
    "twitch": "rtmp://live.twitch.tv/app/",
    "facebook": "rtmps://live-api-s.facebook.com:443/rtmp/",
    "youtube": "rtmp://a.rtmp.youtube.com/live2/",
}

class StreamManager:
    def __init__(self):
        self.processes = {}  # {platform: subprocess.Popen}
        self.restart_count = {}  # {platform: int}
        self.max_restarts = 10
        self.running = True
        self.current_video = None
        self.log("Stream Manager iniciado")

    def log(self, msg):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{timestamp}] {msg}"
        print(line)
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")

    def load_config(self):
        if not CONFIG_FILE.exists():
            self.log("ERROR: stream_config.json no encontrado")
            return {}
        return json.loads(CONFIG_FILE.read_text())

    def get_video(self):
        """Obtiene el video a transmitir (el mas reciente en la carpeta)."""
        if not VIDEO_DIR.exists():
            self.log(f"ERROR: Directorio de videos no existe: {VIDEO_DIR}")
            return None
        videos = list(VIDEO_DIR.glob("*.mp4"))
        if not videos:
            self.log("ERROR: No hay videos en la carpeta")
            return None
        # Usar el mas reciente
        videos.sort(key=lambda f: f.stat().st_mtime, reverse=True)
        return videos[0]

    def start_stream(self, platform, key, video_path):
        """Inicia un stream a una plataforma."""
        rtmp_url = RTMP_BASES[platform] + key
        cmd = [
            FFMPEG, "-re", "-stream_loop", "-1", "-i", str(video_path),
            "-c:v", "libx264", "-preset", "veryfast", "-b:v", "4500k",
            "-maxrate", "4500k", "-bufsize", "9000k", "-pix_fmt", "yuv420p",
            "-g", "60", "-c:a", "aac", "-b:a", "160k", "-ar", "44100",
            "-f", "flv", rtmp_url
        ]
        try:
            p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self.processes[platform] = p
            self.restart_count[platform] = self.restart_count.get(platform, 0)
            self.log(f"Stream iniciado en {platform.upper()} (PID: {p.pid})")
            return True
        except Exception as e:
            self.log(f"ERROR iniciando stream en {platform}: {e}")
            return False

    def stop_stream(self, platform):
        """Detiene un stream."""
        if platform in self.processes:
            try:
                self.processes[platform].terminate()
                self.processes[platform].wait(timeout=5)
            except:
                self.processes[platform].kill()
            del self.processes[platform]
            self.log(f"Stream detenido en {platform.upper()}")

    def check_streams(self):
        """Verifica si los streams estan vivos y los reinicia si es necesario."""
        for platform in list(self.processes.keys()):
            p = self.processes[platform]
            if p.poll() is not None:
                self.log(f"Stream en {platform.upper()} se cayo (exit code: {p.returncode})")
                self.restart_count[platform] = self.restart_count.get(platform, 0) + 1
                if self.restart_count[platform] <= self.max_restarts:
                    self.log(f"Reiniciando {platform.upper()} (intento {self.restart_count[platform]}/{self.max_restarts})")
                    del self.processes[platform]
                    config = self.load_config()
                    if platform in config and config[platform].get("activo"):
                        video = self.get_video()
                        if video:
                            self.start_stream(platform, config[platform]["key"], video)
                else:
                    self.log(f"Maximo de reinicios alcanzado para {platform.upper()}. Deteniendo.")
                    del self.processes[platform]

    def start_all(self, platforms=None):
        """Inicia streams en todas las plataformas activas."""
        config = self.load_config()
        if not config:
            return

        if platforms is None:
            platforms = [p for p, c in config.items() if c.get("activo") and "PEGA" not in c.get("key", "")]

        video = self.get_video()
        if not video:
            self.log("ERROR: No se encontro video para transmitir")
            return

        self.current_video = video
        self.log(f"Video a transmitir: {video.name}")

        for platform in platforms:
            if platform in RTMP_BASES and platform in config:
                self.start_stream(platform, config[platform]["key"], video)
                time.sleep(3)  # Evitar sobrecarga

    def run(self, platforms=None, check_interval=30):
        """Loop principal de monitoreo."""
        self.start_all(platforms)
        self.log("Monitoreo activo. Ctrl+C para detener.")
        try:
            while self.running:
                self.check_streams()
                time.sleep(check_interval)
        except KeyboardInterrupt:
            self.log("Deteniendo todos los streams...")
            for platform in list(self.processes.keys()):
                self.stop_stream(platform)
            self.log("Stream Manager detenido.")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Kabalion Stream Manager 24/7")
    parser.add_argument("--platforms", nargs="+", default=None,
                        help="Plataformas a transmitir (ej: kick twitch)")
    parser.add_argument("--interval", type=int, default=30,
                        help="Intervalo de monitoreo en segundos")
    args = parser.parse_args()

    manager = StreamManager()
    manager.run(platforms=args.platforms, check_interval=args.interval)
