import subprocess, sys
sys.argv = ['video_factory.py', '--mode', 'gemini', '--prompt', 'Video viral de TikTok sobre trading', '--duration', '5', '--style', 'cyberpunk']
exec(open('video_factory.py').read().split('if __name__')[0])
# Now call main manually
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("--mode", choices=["ffmpeg", "gemini", "manim", "ai", "moviepy", "sd"], default="gemini")
parser.add_argument("--prompt", type=str, required=True)
parser.add_argument("--duration", type=int, default=15)
parser.add_argument("--style", type=str, default="cinematic")
args = parser.parse_args(['--mode', 'gemini', '--prompt', 'Video viral de TikTok sobre trading', '--duration', '5', '--style', 'cyberpunk'])

if args.mode == "gemini":
    result = generate_gemini_video(args.prompt, args.duration, args.style)
    print(f"\nRESULT: {result}")
