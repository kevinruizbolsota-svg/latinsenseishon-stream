extends Node3D

@onready var player = $Player
@onready var camera_player = $Player/CameraPivot/Camera3D

# Nodos del Oráculo y Terminal Matrix
@onready var oracle_entity = $OracleOfUrantino
@onready var matrix_table = $MatrixCommandStation
@onready var matrix_cam = $MatrixCommandStation/MatrixCamera3D

# UI y Consolas
@onready var dialog_box = $UI/HUD/DialogBox
@onready var inspector_title = $UI/HUD/DialogBox/VBox/Header/Title
@onready var inspector_status = $UI/HUD/DialogBox/VBox/Header/StatusBadge
@onready var inspector_msg = $UI/HUD/DialogBox/VBox/Message
@onready var code_panel = $UI/HUD/DialogBox/VBox/CodePanel
@onready var code_label = $UI/HUD/DialogBox/VBox/CodePanel/CodeLabel
@onready var action_btn = $UI/HUD/DialogBox/VBox/ActionBtn

# Terminal PC Matrix HUD
@onready var matrix_hud = $UI/MatrixHUD
@onready var oracle_chat_hud = $UI/OracleChatHUD
@onready var oracle_input = $UI/OracleChatHUD/Panel/VBox/InputHBox/LineEdit
@onready var oracle_send_btn = $UI/OracleChatHUD/Panel/VBox/InputHBox/SendBtn
@onready var oracle_dialog_text = $UI/OracleChatHUD/Panel/VBox/ChatScroll/ChatHistory

# Titanes
@onready var titan_atlas = $Titans/Titan_Atlas
@onready var titan_orion = $Titans/Titan_Orion
@onready var titan_axen = $Titans/Titan_Axen
@onready var titan_andromeda = $Titans/Titan_Andromeda

# 5 Puertas Dimensionales
@onready var door_trading = $Doors/Door_Trading
@onready var door_contenido = $Doors/Door_Contenido
@onready var door_broadcast = $Doors/Door_Broadcast
@onready var door_luxury = $Doors/Door_Luxury
@onready var door_morontia = $Doors/Door_Morontia

var ws := WebSocketPeer.new()
var ws_url: String = "ws://127.0.0.1:8765"
var is_ws_connected: bool = false

var is_in_matrix_pc_view: bool = false
var current_target_data = null
var poll_timer = 0.0

var interactive_entities = {}

func _ready():
	_register_entities()
	action_btn.pressed.connect(_on_action_button_pressed)
	if oracle_send_btn:
		oracle_send_btn.pressed.connect(_on_oracle_send_pressed)
	if oracle_input:
		oracle_input.text_submitted.connect(_on_oracle_input_submitted)
	
	_connect_to_cosmic_broker()

func _connect_to_cosmic_broker():
	var err = ws.connect_to_url(ws_url)
	if err == OK:
		print("[Godot] Conectando a ws://127.0.0.1:8765...")

func _register_entities():
	# 🔮 EL ORÁCULO SUPREMO DE URANTINO
	interactive_entities["Oracle"] = {
		"node": oracle_entity,
		"type": "ORACLE",
		"title": "🔮 EL ORÁCULO SUPREMO DE URANTINO",
		"badge": "[IA OMNISCIENTE ACTIVA]",
		"badge_color": Color(0.3, 0.9, 1.0),
		"msg": "Saludos Kevin. Soy el Oráculo de Urantino. Albergo todas las habilidades cósmicas de Antigravity: orquesto los 4 Titanes, controlo flujos de n8n, compilo en la Matrix y vigilo tu imperio. Háblame libremente.",
		"code": "# ORACLE NEURAL BRAIN\nAGENT_COUNCIL: ['ATLAS', 'ORION', 'AXEN', 'ANDROMEDA']\nCAPABILITIES: Full Matrix Access, Workflow Dispatcher, Live Memory\nPORT: ws://127.0.0.1:8765 (Active)",
		"action_label": "🗣️ ABRIR COMUNIÓN CON EL ORÁCULO"
	}

	# 🖥️ TERMINAL PC DE LA MATRIX
	interactive_entities["MatrixPC"] = {
		"node": matrix_table,
		"type": "MATRIX_PC",
		"title": "🖥️ ESTACIÓN DE COMANDO & PC DE LA MATRIX",
		"badge": "[ZOOM AL PC DISPONIBLE]",
		"badge_color": Color(0.1, 1.0, 0.5),
		"msg": "Mesa central de mando. Aquí convergen las terminales de los 4 Titanes y el código cuántico. Acércate e interactúa para hacer ZOOM profundo en la pantalla y codificar la Matrix.",
		"code": "# MATRIX WORKSTATION\nSCREEN_RESOLUTION: Ultra HD 4K Virtual Screen\nCONNECTED_TITANS: 4\nACTIVE_WORKFLOWS: Video Render, Stream Watchdog, n8n Automation",
		"action_label": "🔍 HACER ZOOM AL PC DE LA MATRIX"
	}

	# Puertas Dimensionales
	interactive_entities["Door_Trading"] = {
		"node": door_trading,
		"type": "DOOR",
		"title": "🏛️ HABITACIÓN 01: TRADING CUÁNTICO",
		"badge": "[RATIO 3:1 VINCULADO]",
		"badge_color": Color(0.1, 1.0, 0.5),
		"msg": "Swarm de Trading Cuántico con refuerzo por dolor de pérdida y cámara de meditación 432 Hz.",
		"code": "# TRADING REINFORCEMENT\nSTOP_LOSS_GUARD: Active\nDB: cosmic_matrix.db (SQLite)",
		"action_label": "📈 LANZAR ESCANEO DE MERCADO"
	}
	interactive_entities["Door_Contenido"] = {
		"node": door_contenido,
		"type": "DOOR",
		"title": "🎬 HABITACIÓN 02: FORJA VIRAL & REDES",
		"badge": "[CLIPS LISTOS EN 9:16]",
		"badge_color": Color(1.0, 0.45, 0.05),
		"msg": "Renderizado automático 9:16 vertical con subtítulos dinámicos y marca KRC Gold.",
		"code": "# FORJA VIRAL AXEN & ORION\nOUTPUT: C:\\Users\\kevin\\Desktop\\Videos para tiktok",
		"action_label": "🚀 DISPARAR CLIP AL COSMOS"
	}
	interactive_entities["Door_Broadcast"] = {
		"node": door_broadcast,
		"type": "DOOR",
		"title": "📡 HABITACIÓN 03: TELECOMUNICACIONES & MATRIX",
		"badge": "[STREAMING 24/7 ONLINE]",
		"badge_color": Color(0.1, 0.7, 1.0),
		"msg": "Supervisión de sockets Twitch y Facebook Live y orquestador n8n.",
		"code": "# TELECOM MATRIX\nTWITCH: ONLINE (live_851574809)",
		"action_label": "⚡ REINICIAR DIRECTOS MATRIX"
	}
	interactive_entities["Door_Luxury"] = {
		"node": door_luxury,
		"type": "DOOR",
		"title": "💎 HABITACIÓN 04: CREACIÓN & REMEMBER LUXURY",
		"badge": "[MARGEN 74% PROYECTADO]",
		"badge_color": Color(1.0, 0.85, 0.15),
		"msg": "E-Commerce de streetwear oversize y joyería mística de alta rentabilidad.",
		"code": "# REMEMBER LUXURY COMMERCE\nFUNNEL: TikTok -> Shopify Checkout",
		"action_label": "🛒 ACTUALIZAR CATÁLOGO LUXURY"
	}
	interactive_entities["Door_Morontia"] = {
		"node": door_morontia,
		"type": "DOOR",
		"title": "🌌 HABITACIÓN 05: SANTUARIO MORONTIAL & DEEP AI",
		"badge": "[ANDRÓMEDA 24/7 ACTIVA]",
		"badge_color": Color(0.8, 0.25, 1.0),
		"msg": "Purga inteligente de almacenamiento y frecuencias armónicas Solfeggio 432 Hz.",
		"code": "# DEEP AI WATCHDOG\nAUTOCURING: Active\nDISK_PURGE: Max 30 episodes FIFO",
		"action_label": "🛡️ PING ESCUDO CÓSMICO"
	}

func _process(delta):
	# Polling WebSocket con el Cosmic Broker local
	ws.poll()
	var state = ws.get_ready_state()
	if state == WebSocketPeer.STATE_OPEN:
		if not is_ws_connected:
			is_ws_connected = true
			print("[Godot] ¡Conectado al Broker Cósmico!")
		while ws.get_available_packet_count() > 0:
			var packet_str = ws.get_packet().get_string_from_utf8()
			_handle_broker_message(packet_str)
	elif state == WebSocketPeer.STATE_CLOSED:
		is_ws_connected = false

	# Rotación cinemática del Oráculo y de los Titanes
	if oracle_entity:
		oracle_entity.rotate_y(0.8 * delta)
	titan_atlas.rotate_y(0.6 * delta)
	titan_orion.rotate_y(0.8 * delta)
	titan_axen.rotate_y(1.1 * delta)
	titan_andromeda.rotate_y(0.5 * delta)

	# Salir de vista PC con tecla Escape o TAB
	if is_in_matrix_pc_view and Input.is_action_just_pressed("ui_cancel"):
		_exit_matrix_pc_zoom()

	# Detección de proximidad
	if not is_in_matrix_pc_view:
		_check_proximity()

func _handle_broker_message(msg: String):
	var parsed = JSON.parse_string(msg)
	if not (parsed is Dictionary):
		return
	var mtype = parsed.get("type", "")
	var data = parsed.get("data", {})

	if mtype == "ORACLE_RESPONSE":
		var reply = data.get("reply", "")
		if oracle_dialog_text:
			oracle_dialog_text.text += "\n🔮 [ORÁCULO]: " + reply + "\n"
		_start_titan_debate()
	elif mtype == "ORACLE_STATUS":
		var welcome = data.get("message", "")
		if oracle_dialog_text:
			oracle_dialog_text.text = "🔮 [ORÁCULO]: " + welcome + "\n"
	elif mtype == "TITAN_STATUS_RESPONSE":
		_update_titan_status_display(data.get("titans", {}))
	elif mtype == "TITANS_ADMINISTERED":
		if oracle_dialog_text:
			oracle_dialog_text.text += "\n⚡ [TITANES]: " + data.get("message", "") + "\n"
		_update_titan_status_display(data.get("titans", {}))
	elif mtype == "TITAN_TRIGGERED":
		if oracle_dialog_text:
			oracle_dialog_text.text += "\n⚡ [" + data.get("titan", "TITAN") + "]: " + data.get("message", "") + "\n"
	elif mtype == "WORKFLOW_CREATED":
		if oracle_dialog_text:
			oracle_dialog_text.text += "\n📋 [WORKFLOW]: '" + data.get("name", "") + "' creado - Estado: " + data.get("status", "") + "\n"
	elif mtype == "WORKFLOW_LIST":
		var wfs = data.get("workflows", [])
		if oracle_dialog_text:
			oracle_dialog_text.text += "\n📋 [WORKFLOWS ACTIVOS]: " + str(wfs.size()) + " encontrados\n"
			for wf in wfs:
				oracle_dialog_text.text += "  • " + wf.get("name", "") + " [" + wf.get("status", "") + "]\n"
	elif mtype == "MATRIX_RESULT":
		if oracle_dialog_text:
			oracle_dialog_text.text += "\n🖥️ [MATRIX]: " + data.get("output", "") + "\n"

func _start_titan_debate():
	# Los 4 Titanes pulsan sus auras en secuencia (debate en la mesa redonda)
	var titans = [titan_atlas, titan_orion, titan_axen, titan_andromeda]
	for i in range(titans.size()):
		var t = titans[i]
		if t and is_instance_valid(t):
			# Crear un pulso de luz en cada Titan secuencialmente
			var timer = get_tree().create_timer(i * 0.4 + 0.1)
			timer.timeout.connect(func():
				if is_instance_valid(t):
					for child in t.get_children():
						if child is OmniLight3D:
							child.light_energy = 5.0
							var reset_timer = get_tree().create_timer(0.6)
							reset_timer.timeout.connect(func():
								if is_instance_valid(child):
									child.light_energy = 2.0
							)
			)

func _update_titan_status_display(titans_data: Dictionary):
	# Actualizar el MatrixHUD con el estado de los Titanes
	if matrix_hud and matrix_hud.visible:
		var log = matrix_hud.get_node_or_null("Panel/VBox/MatrixLog")
		if log:
			log.text = "[MATRIX CORE - TITAN STATUS UPDATE]\n"
			for key in titans_data:
				var t = titans_data[key]
				log.text += "> " + t.get("name", key.upper()) + " [" + t.get("status", "ONLINE") + "] - " + t.get("task", "") + "\n"

func _check_proximity():
	var p_pos = player.global_position
	var found_entity = null

	for key in interactive_entities:
		var ent = interactive_entities[key]
		if ent["node"] and is_instance_valid(ent["node"]):
			var dist = p_pos.distance_to(ent["node"].global_position)
			if dist < 4.2:
				found_entity = ent
				break

	if found_entity:
		current_target_data = found_entity
		inspector_title.text = found_entity.get("title", "ENTIDAD")
		inspector_status.text = found_entity.get("badge", "[ACTIVO]")
		inspector_msg.text = found_entity.get("msg", "")
		code_label.text = found_entity.get("code", "")
		action_btn.text = found_entity.get("action_label", "⚡ ACCIÓN")
		dialog_box.visible = true
	else:
		current_target_data = null
		dialog_box.visible = false

func _on_action_button_pressed():
	if not current_target_data:
		return

	if current_target_data["type"] == "MATRIX_PC":
		_enter_matrix_pc_zoom()
	elif current_target_data["type"] == "ORACLE":
		_toggle_oracle_chat()
	else:
		# Enviar orden al Broker
		if is_ws_connected:
			var action_name = "TRIGGER_" + current_target_data.get("title", "ACTION")
			ws.send_text(JSON.stringify({"action": "TRIGGER_TITAN", "data": {"titan": current_target_data.get("title")}}))
		action_btn.text = "✨ ¡ORDEN ENVIADA A LA MATRIX!"

func _enter_matrix_pc_zoom():
	is_in_matrix_pc_view = true
	dialog_box.visible = false
	camera_player.current = false
	matrix_cam.current = true
	matrix_hud.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	# Solicitar estado de Titanes y workflows al Broker
	if is_ws_connected:
		ws.send_text(JSON.stringify({"action": "TITAN_STATUS", "data": {}}))
		ws.send_text(JSON.stringify({"action": "LIST_WORKFLOWS", "data": {}}))

func _exit_matrix_pc_zoom():
	is_in_matrix_pc_view = false
	matrix_hud.visible = false
	matrix_cam.current = false
	camera_player.current = true

func _toggle_oracle_chat():
	oracle_chat_hud.visible = !oracle_chat_hud.visible
	if oracle_chat_hud.visible:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		oracle_input.grab_focus()

func _on_oracle_send_pressed():
	var text = oracle_input.text.strip_edges()
	if text == "":
		return
	oracle_dialog_text.text += "\n👤 [KEVIN]: " + text
	oracle_input.text = ""
	if is_ws_connected:
		ws.send_text(JSON.stringify({"action": "ORACLE_QUERY", "data": {"query": text}}))
	else:
		oracle_dialog_text.text += "\n🔮 [ORÁCULO]: (Procesando localmente) Orden cósmica asimilada, mi rey. Los 4 Titanes están ejecutando."

func _on_oracle_input_submitted(_new_text: String):
	_on_oracle_send_pressed()
