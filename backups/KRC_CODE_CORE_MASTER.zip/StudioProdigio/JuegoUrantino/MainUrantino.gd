extends Control

# PLANETA URANTINO - CEREBRO CENTRAL DE CONEXIÓN IA
# Conecta a Kevin KRC con n8n, terminal local y los 4 Titanes (Atlas, Orión, Axen, Andrómeda)

@onready var chat_history = $VBoxContainer/ScrollContainer/ChatHistory
@onready var input_text = $VBoxContainer/HBoxContainer/LineEdit
@onready var send_btn = $VBoxContainer/HBoxContainer/SendButton
@onready var http_request = $HTTPRequest
@onready var status_lbl = $VBoxContainer/StatusLabel

const N8N_CHAT_URL = "http://localhost:5678/webhook/628fb0bb-dfb0-404b-a30b-188c8c04f643/chat"

func _ready():
	add_chat_msg("🪐 SISTEMA URANTINO", "Bienvenido a Urantino, Kevin (El Prodigio). Los 4 Titanes (Atlas, Orión, Axen y Andrómeda) están despiertos y conectados con n8n.")
	send_btn.pressed.connect(_on_send_pressed)
	input_text.text_submitted.connect(_on_text_submitted)
	http_request.request_completed.connect(_on_http_completed)

func _on_send_pressed():
	var msg = input_text.text.strip_edges()
	if msg == "": return
	input_text.clear()
	enviar_mensaje_ia(msg)

func _on_text_submitted(_new_text):
	_on_send_pressed()

func add_chat_msg(emisor: String, texto: String):
	var lbl = Label.new()
	lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lbl.text = "[" + emisor + "]: " + texto
	chat_history.add_child(lbl)

func enviar_mensaje_ia(msg: String):
	add_chat_msg("👑 KEVIN", msg)
	status_lbl.text = "⚡ Conectando con los Titanes de Urantino en n8n..."
	
	var headers = ["Content-Type: application/json"]
	var body = JSON.stringify({
		"action": "sendMessage",
		"sessionId": "urantino-godot-client",
		"chatInput": msg
	})
	
	var err = http_request.request(N8N_CHAT_URL, headers, HTTPClient.METHOD_POST, body)
	if err != OK:
		status_lbl.text = "Error al despachar mensaje a n8n."

func _on_http_completed(_result, response_code, _headers, body):
	status_lbl.text = "● Civilización de Urantino en Armonía (Online)"
	if response_code == 200:
		var json = JSON.parse_string(body.get_string_from_utf8())
		if json and json.has("output"):
			add_chat_msg("🪐 CEREBRO URANTINO", str(json["output"]))
		else:
			add_chat_msg("🪐 CEREBRO URANTINO", "Comando procesado con éxito por el titán.")
	else:
		add_chat_msg("⚠️ ALERTA", "Fallo al conectar con n8n local (Código: " + str(response_code) + ")")
