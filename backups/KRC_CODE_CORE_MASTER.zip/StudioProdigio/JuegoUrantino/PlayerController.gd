extends CharacterBody3D

const SPEED = 7.0
const SPRINT_SPEED = 12.0
const JUMP_VELOCITY = 6.0

@onready var camera_pivot = $CameraPivot
@onready var camera = $CameraPivot/Camera3D
@onready var mesh_container = $MeshContainer

# Articulaciones procedimentales
@onready var leg_l = $MeshContainer/LegL
@onready var leg_r = $MeshContainer/LegR
@onready var arm_l = $MeshContainer/ArmL
@onready var arm_r = $MeshContainer/ArmR

var gravity = ProjectSettings.get_setting("physics/3d/default_gravity")
var mouse_sensitivity = 0.0028
var mouse_captured = false
var walk_cycle = 0.0

func _unhandled_input(event):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
		mouse_captured = !mouse_captured
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED if mouse_captured else Input.MOUSE_MODE_VISIBLE
	
	if event is InputEventKey and event.keycode == KEY_ESCAPE and event.pressed:
		mouse_captured = false
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

	if mouse_captured and event is InputEventMouseMotion:
		camera_pivot.rotate_y(-event.relative.x * mouse_sensitivity)
		camera.rotate_x(-event.relative.y * mouse_sensitivity)
		camera.rotation.x = clamp(camera.rotation.x, -deg_to_rad(65), deg_to_rad(50))

func _physics_process(delta):
	if not is_on_floor():
		velocity.y -= gravity * delta

	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	var current_speed = SPRINT_SPEED if Input.is_key_pressed(KEY_SHIFT) else SPEED

	var input_dir = Vector2.ZERO
	if Input.is_key_pressed(KEY_W) or Input.is_action_pressed("ui_up"):
		input_dir.y -= 1
	if Input.is_key_pressed(KEY_S) or Input.is_action_pressed("ui_down"):
		input_dir.y += 1
	if Input.is_key_pressed(KEY_A) or Input.is_action_pressed("ui_left"):
		input_dir.x -= 1
	if Input.is_key_pressed(KEY_D) or Input.is_action_pressed("ui_right"):
		input_dir.x += 1

	input_dir = input_dir.normalized()
	var forward = -camera_pivot.global_transform.basis.z
	var right = camera_pivot.global_transform.basis.x
	forward.y = 0
	right.y = 0
	forward = forward.normalized()
	right = right.normalized()

	var direction = (forward * (-input_dir.y) + right * input_dir.x).normalized()

	if direction:
		velocity.x = direction.x * current_speed
		velocity.z = direction.z * current_speed
		var target_angle = atan2(direction.x, direction.z)
		mesh_container.rotation.y = lerp_angle(mesh_container.rotation.y, target_angle, 14 * delta)

		# Animación procedimental de caminata humana (piernas y brazos)
		walk_cycle += delta * (current_speed * 1.5)
		var leg_swing = sin(walk_cycle) * 0.55
		var arm_swing = -sin(walk_cycle) * 0.45
		
		if leg_l: leg_l.rotation.x = leg_swing
		if leg_r: leg_r.rotation.x = -leg_swing
		if arm_l: arm_l.rotation.x = arm_swing
		if arm_r: arm_r.rotation.x = -arm_swing
	else:
		velocity.x = move_toward(velocity.x, 0, current_speed)
		velocity.z = move_toward(velocity.z, 0, current_speed)
		# Reposo natural
		walk_cycle = 0.0
		if leg_l: leg_l.rotation.x = lerp_angle(leg_l.rotation.x, 0.0, 10 * delta)
		if leg_r: leg_r.rotation.x = lerp_angle(leg_r.rotation.x, 0.0, 10 * delta)
		if arm_l: arm_l.rotation.x = lerp_angle(arm_l.rotation.x, 0.0, 10 * delta)
		if arm_r: arm_r.rotation.x = lerp_angle(arm_r.rotation.x, 0.0, 10 * delta)

	move_and_slide()
