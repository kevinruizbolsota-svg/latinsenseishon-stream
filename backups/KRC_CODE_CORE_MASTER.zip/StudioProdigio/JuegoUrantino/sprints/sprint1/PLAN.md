# SPRINT 1: EL PUENTE DE LA MATRIX & EL DESPERTAR DEL ORÁCULO

## 🎯 Objetivo Principal
Establecer la comunicación bidireccional en tiempo real entre el motor 3D (Godot 4.7) y el cerebro de n8n/IA, implementando la interfaz del Oráculo y la Terminal de Codificación de la Matrix.

## 🛠️ Componentes Técnicos a Implementar

### 1. El Cosmic Broker (WebSocket Bridge)
- **Implementación**: Servidor Node.js / Python corriendo en segundo plano.
- **Función**: Recibe órdenes del juego -> Las manda a n8n -> Devuelve la respuesta al juego en <100ms.
- **Endpoint**: `ws://127.0.0.1:8765`

### 2. El Oráculo (La IA Suprema del Juego)
- **Identidad**: Entidad omnisciente con acceso total a las habilidades de Atlas, Orión, Axen y Andrómeda.
- **Capacidades**:
    - Administración total de los 4 Titanes.
    - Ejecución de Workflows de n8n desde el diálogo.
    - Creación de nuevos agentes y asignación de misiones.
    - Interfaz de voz y texto en HD.
- **Ubicación**: Trono central del Templo Morontial.

### 3. La Terminal de la Matrix (El PC Maestro)
- **Visual**: Mesa de mando con un PC hiperrealista (Calidad GTA 6).
- **Mecánica**: Zoom cinemático al interactuar.
- **Funcionalidad**: 
    - Visor de código en tiempo real.
    - Panel de control de agentes (On/Off, Estado, Misión Actual).
    - Consola de comandos para "Codificar la Matrix" (Modificar el entorno del juego en vivo).

## 📅 Roadmap de Ejecución (Días 1-7)
- **Día 1-2**: Montaje del servidor WebSocket y conexión básica con Godot.
- **Día 3**: Modelado 3D del PC Maestro y configuración del zoom de cámara.
- **Día 4**: Implementación del diálogo del Oráculo (Conexión con API de LLM).
- **Día 5**: Integración de comandos de administración de Titanes.
- **Día 6**: Pulido de texturas HD y shaders de luz volumétrica en la zona del PC.
- **Día 7**: Pruebas de estrés y primera "Codificación de la Matrix" exitosa.
