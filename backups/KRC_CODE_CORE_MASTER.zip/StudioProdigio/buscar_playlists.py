import sys, json, time
sys.path.insert(0, r"C:\Users\kevin\StudioProdigio")
import yt_dlp

# Search for working playlists
queries = [
    "El Chavo del 8 playlist completa",
    "Dragon Ball Z playlist completa español",
    "Los Simpsons playlist completa español",
    "Bob Esponja playlist completa español",
    "Naruto playlist completa español",
    "Coraje perro cobarde playlist completa",
    "Dexter laboratorio playlist completa",
    "Johnny Bravo playlist completa",
    "Avatar Aang playlist completa español",
    "Kim Possible playlist completa español",
]

working_playlists = {}
for query in queries:
    try:
        opts = {"extract_flat": True, "quiet": True, "default_search": "ytsearch5"}
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(f"ytsearch5:{query}", download=False)
            entries = info.get("entries", [])
            for e in entries:
                url = e.get("url") or e.get("webpage_url", "")
                title = e.get("title", "")
                # Check if it's a playlist
                if "list=" in url or "playlist" in url.lower():
                    # Test if playlist works
                    try:
                        test_opts = {"extract_flat": True, "quiet": True, "playlist_items": "1"}
                        with yt_dlp.YoutubeDL(test_opts) as ydl2:
                            test_info = ydl2.extract_info(url, download=False)
                        test_entries = test_info.get("entries", [])
                        if test_entries and len(test_entries) > 0:
                            key = query.split(" playlist")[0]
                            working_playlists[key] = {"url": url, "title": title, "count": len(test_entries)}
                            print(f"OK: {key} - {len(test_entries)} videos - {title[:50]}")
                            break
                    except:
                        continue
            time.sleep(2)
    except Exception as e:
        print(f"FAIL: {query}: {str(e)[:60]}")

# Save
with open(r"C:\Users\kevin\StudioProdigio\playlists_working.json", "w", encoding="utf-8") as f:
    json.dump(working_playlists, f, ensure_ascii=False, indent=2)
print(f"\nTotal working playlists: {len(working_playlists)}")
for k, v in working_playlists.items():
    print(f"  {k}: {v['count']} videos")
