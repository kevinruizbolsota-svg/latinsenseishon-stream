﻿import re
from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.tscn")
t = p.read_text(encoding="utf-8")

# bump load_steps by 7
t = t.replace('[gd_scene load_steps=25 format=3]', '[gd_scene load_steps=32 format=3]', 1)

# add audio ext_resources after id 12
old = '[ext_resource type="Script" path="res://main.gd" id="12"]'
new = old + '''
[ext_resource type="AudioStream" path="res://sfx_shot.wav" id="13"]
[ext_resource type="AudioStream" path="res://sfx_shot_fast.wav" id="14"]
[ext_resource type="AudioStream" path="res://sfx_reload.wav" id="15"]
[ext_resource type="AudioStream" path="res://sfx_hit.wav" id="16"]
[ext_resource type="AudioStream" path="res://sfx_empty.wav" id="17"]
[ext_resource type="AudioStream" path="res://sfx_hurt.wav" id="18"]
[ext_resource type="AudioStream" path="res://sfx_kill.wav" id="19"]'''
t = t.replace(old, new)

# add muzzle flash and audio players under Player/Camera3D (after WeaponHolder block ends, before UI)
# insert before [node name="UI"
ui_marker = '\n[node name="UI" type="CanvasLayer" parent="."]'
audio_block = r'''
[node name="MuzzleFlash" type="OmniLight3D" parent="Player/Camera3D"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0.2, -0.15, -0.9)
visible = false
light_color = Color(1, 0.85, 0.45, 1)
light_energy = 2.5
omni_range = 4.0

[node name="SfxShot" type="AudioStreamPlayer" parent="Player"]
stream = ExtResource("13")
volume_db = -6.0

[node name="SfxShotFast" type="AudioStreamPlayer" parent="Player"]
stream = ExtResource("14")
volume_db = -7.0

[node name="SfxReload" type="AudioStreamPlayer" parent="Player"]
stream = ExtResource("15")
volume_db = -4.0

[node name="SfxHit" type="AudioStreamPlayer" parent="Player"]
stream = ExtResource("16")
volume_db = -5.0

[node name="SfxEmpty" type="AudioStreamPlayer" parent="Player"]
stream = ExtResource("17")
volume_db = -6.0

[node name="SfxHurt" type="AudioStreamPlayer" parent="Player"]
stream = ExtResource("18")
volume_db = -4.0

[node name="SfxKill" type="AudioStreamPlayer" parent="Player"]
stream = ExtResource("19")
volume_db = -5.0
'''
if ui_marker in t:
    t = t.replace(ui_marker, audio_block + ui_marker)

# add HitMarker in UI (after Mira)
mira_block = r'''[node name="Mira" type="Label" parent="UI"]
anchors_preset = 8
anchor_left = 0.5
anchor_top = 0.5
anchor_right = 0.5
anchor_bottom = 0.5
offset_left = -10.0
offset_top = -12.0
offset_right = 10.0
offset_bottom = 12.0
text = "+"
horizontal_alignment = 1
vertical_alignment = 1'''
hitmarker = mira_block + r'''

[node name="HitMarker" type="Label" parent="UI"]
anchors_preset = 8
anchor_left = 0.5
anchor_top = 0.5
anchor_right = 0.5
anchor_bottom = 0.5
offset_left = -20.0
offset_top = -22.0
offset_right = 20.0
offset_bottom = 22.0
theme_override_colors/font_color = Color(1, 0.9, 0.9, 1)
text = ""
horizontal_alignment = 1
vertical_alignment = 1'''
if mira_block in t:
    t = t.replace(mira_block, hitmarker)

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
