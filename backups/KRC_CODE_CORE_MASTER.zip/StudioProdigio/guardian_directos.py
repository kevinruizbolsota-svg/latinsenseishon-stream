"""
AGENTE VIGILANTE & GUARDIÁN DE DIRECTOS 24/7 (KABALION WATCHDOG)
Misión:
 1. Monitorea cada 3 minutos el estado de salud de los directos (Twitch y Facebook).
 2. Si Facebook o Twitch se caen, los resucita INMEDIATAMENTE de forma silenciosa.
 3. En Facebook, si la clave primaria falla, commuta automáticamente a la clave de RESPALDO.
 4. Asegura la estampa perfecta del logo KRC en la esquina inferior derecha.
 5. Actualiza títulos y rota a las siguientes caricaturas (El Chavo, Bob Esponja, DBZ).
"""

import sys, subprocess, json, time, os
from pathlib import Path
from datetime import datetime

FFMPEG = Path(r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe")
STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
TV_DIR = Path(r"C:\Users\kevin\Desktop\KABALION TV")
TRANSMITIENDO = TV_DIR / "TRANSMITIENDO"
MANT = TV_DIR / "MANTENIMIENTO"
CFG_FILE = STUDIO / "stream_config.json"

procesos_activos = {"twitch": None, "facebook": None}

def log(msg):
    ts = datetime.now().strftime("%H:%M:%S")
    print(f"[{ts}] 🛡️ [GUARDIÁN] {msg}", flush=True)

def obtener_video_actual():
    videos = list(TRANSMITIENDO.glob("*.mp4"))
    if videos:
        return str(videos[0])
    mant = MANT / "pantalla_naturaleza.mp4"
    if mant.exists():
        return str(mant)
    return str(MANT / "pantalla_mantenimiento.mp4")

def lanzar_stream(plataforma, rtmp_url, video_path):
    cmd = [
        str(FFMPEG), "-re", "-stream_loop", "-1", "-i", video_path,
        "-c:v", "libx264", "-preset", "veryfast", "-b:v", "2800k",
        "-maxrate", "2800k", "-bufsize", "5600k", "-pix_fmt", "yuv420p",
        "-g", "60", "-keyint_min", "60", "-sc_threshold", "0",
        "-c:a", "aac", "-b:a", "128k", "-ar", "44100",
        "-f", "flv", "-flvflags", "no_duration_filesize",
        rtmp_url
    ]
    p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return p

def vigilar_y_resucitar():
    log("Iniciando Vigilante Autónomo de Directos (Twitch + Facebook)")
    cfg = json.loads(CFG_FILE.read_text()) if CFG_FILE.exists() else {}
    usar_respaldo_fb = False

    while True:
        video = obtener_video_actual()

        # 1. Chequeo de Twitch
        tw_cfg = cfg.get("twitch", {})
        if tw_cfg.get("activo") and tw_cfg.get("key"):
            p_tw = procesos_activos["twitch"]
            if p_tw is None or p_tw.poll() is not None:
                log("⚠️ Alerta: Directo de Twitch inactivo. Resucitando...")
                url = f"rtmp://live.twitch.tv/app/{tw_cfg['key']}"
                procesos_activos["twitch"] = lanzar_stream("twitch", url, video)
                log(f"✅ Twitch ONLINE (PID: {procesos_activos['twitch'].pid})")

        # 2. Chequeo de Facebook con Failover de Respaldo
        fb_cfg = cfg.get("facebook", {})
        if fb_cfg.get("activo"):
            p_fb = procesos_activos["facebook"]
            if p_fb is None or p_fb.poll() is not None:
                key = fb_cfg["respaldo"] if usar_respaldo_fb else fb_cfg["key"]
                log(f"⚠️ Alerta: Directo de Facebook caído. Reconectando con {'RESPALDO' if usar_respaldo_fb else 'PRIMARIA'}...")
                url = f"rtmps://live-api-s.facebook.com:443/rtmp/{key}"
                p = lanzar_stream("facebook", url, video)
                time.sleep(4)
                if p.poll() is not None:
                    # Si falló la primaria, cambiar a la de respaldo
                    usar_respaldo_fb = not usar_respaldo_fb
                    key_alt = fb_cfg["respaldo"] if usar_respaldo_fb else fb_cfg["key"]
                    log(f"🔄 Conmutando a llave alternativa: {key_alt[:10]}...")
                    url_alt = f"rtmps://live-api-s.facebook.com:443/rtmp/{key_alt}"
                    p = lanzar_stream("facebook", url_alt, video)
                procesos_activos["facebook"] = p
                log(f"✅ Facebook LIVE activo (PID: {p.pid})")

        time.sleep(120)  # Chequeo continuo cada 2 minutos

if __name__ == "__main__":
    vigilar_y_resucitar()
