"""
COMPILADOR MARATÓN CHAVO DEL 8 - KRC
Descarga 3 episodios, les pone Intro+Logo KRC+Outro entre cada uno, y saca 1 video largo listo para streaming.
"""
import sys, subprocess, os, json
from pathlib import Path

PYTHON  = r"C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe"
FFMPEG  = r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe"
STUDIO  = Path(r"C:\Users\kevin\StudioProdigio")
OUTPUT  = Path(r"C:\Users\kevin\Desktop\VIDEOS LARGOS PARA STREAMING")
RAW     = STUDIO / "episodes_raw"
NORM    = STUDIO / "episodes_norm"
INTRO   = STUDIO / "assets/intro/intro_oficial.mp4"
OUTRO   = STUDIO / "assets/outro/outro_oficial.mp4"
LOGO    = STUDIO / "assets/logo/logo_krc_transparent.png"
PLAYLIST= "https://www.youtube.com/playlist?list=PLuxcLq9n25BEINVPnsS419gD8E6WSeiS-"
NUM_EP  = 3  # Cambia este número para más capítulos

RAW.mkdir(exist_ok=True)
NORM.mkdir(exist_ok=True)
OUTPUT.mkdir(exist_ok=True)

def run(cmd, label=""):
    print(f"\n▶ {label}")
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print("  ⚠", r.stderr[-500:])
    return r.returncode == 0

def get_episodes():
    import yt_dlp
    opts = {"extract_flat": True, "quiet": True}
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(PLAYLIST, download=False)
    return info.get("entries", [])[:NUM_EP]

def download_ep(vid_id, title, idx):
    out_mp4 = RAW / f"ep{idx:02d}_{vid_id}.mp4"
    if out_mp4.exists() and out_mp4.stat().st_size > 500000:
        print(f"  ✓ Ya descargado: {out_mp4.name}")
        return out_mp4
    print(f"  ⬇ Descargando ep{idx}: {title[:55]}...")
    opts = {
        "format": "bv[height<=720]+ba/best[height<=720]",
        "outtmpl": str(RAW / f"ep{idx:02d}_{vid_id}.%(ext)s"),
        "ffmpeg_location": str(Path(FFMPEG).parent),
        "merge_output_format": "mp4",
        "quiet": True,
        "postprocessors": [{"key":"FFmpegVideoConvertor","preferedformat":"mp4"}]
    }
    import yt_dlp
    with yt_dlp.YoutubeDL(opts) as ydl:
        ydl.download([f"https://www.youtube.com/watch?v={vid_id}"])
    return out_mp4

def normalize(src, dst):
    """Normaliza a 1280x720 30fps AAC 44100Hz para evitar desync en concat."""
    if dst.exists() and dst.stat().st_size > 100000:
        print(f"  ✓ Ya normalizado: {dst.name}")
        return True
    return run([FFMPEG, "-y", "-i", str(src),
        "-vf", f"scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=30",
        "-c:v", "libx264", "-preset", "fast", "-b:v", "2500k",
        "-c:a", "aac", "-ar", "44100", "-ac", "2", "-b:a", "160k",
        str(dst)], f"Normalizando {src.name}")

def overlay_logo(src, dst):
    """Aplica logo KRC con fade in/out sobre el video."""
    if dst.exists() and dst.stat().st_size > 100000:
        print(f"  ✓ Logo ya aplicado: {dst.name}")
        return True
    overlay_filter = (
        "[0:v]scale=1280:720:force_original_aspect_ratio=decrease,"
        "pad=1280:720:(ow-iw)/2:(oh-ih)/2[base];"
        "[1:v]scale=160:160,format=rgba,"
        "fade=t=in:st=2:d=1:alpha=1,fade=t=out:st=20:d=1:alpha=1[logo];"
        "[base][logo]overlay=W-w-25:H-h-40[v]"
    )
    return run([FFMPEG, "-y", "-i", str(src), "-i", str(LOGO),
        "-filter_complex", overlay_filter,
        "-map", "[v]", "-map", "0:a",
        "-c:v", "libx264", "-preset", "fast", "-b:v", "2500k",
        "-c:a", "aac", "-ar", "44100", "-ac", "2", "-b:a", "160k",
        str(dst)], f"Logo KRC -> {dst.name}")

def norm_asset(src, dst, w=1280, h=720):
    if dst.exists() and dst.stat().st_size > 10000:
        return
    run([FFMPEG, "-y", "-i", str(src),
        "-vf", f"scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,fps=30",
        "-c:v", "libx264", "-preset", "fast",
        "-c:a", "aac", "-ar", "44100", "-ac", "2",
        str(dst)], f"Normalizando asset {src.name}")

print("\n╔══════════════════════════════════════════════════╗")
print("║  COMPILADOR MARATÓN KRC - Chavo del 8 24/7       ║")
print("╚══════════════════════════════════════════════════╝\n")

# 1. Normalizar intro y outro
intro_n = NORM / "intro_n.mp4"
outro_n = NORM / "outro_n.mp4"
norm_asset(INTRO, intro_n)
norm_asset(OUTRO, outro_n)

# 2. Descargar episodios
eps = get_episodes()
raw_eps = []
for i, e in enumerate(eps):
    mp4 = download_ep(e["id"], e.get("title","ep"), i+1)
    raw_eps.append(mp4)

# 3. Normalizar + Logo KRC
logo_eps = []
for i, raw in enumerate(raw_eps):
    norm_path = NORM / f"norm_{raw.stem}.mp4"
    logo_path = NORM / f"logo_{raw.stem}.mp4"
    normalize(raw, norm_path)
    overlay_logo(norm_path, logo_path)
    logo_eps.append(logo_path)

# 4. Construir concat: Intro -> (Outro->Intro) entre capítulos -> Outro al final
concat_list = STUDIO / "maraton_concat.txt"
segments = []
for i, ep in enumerate(logo_eps):
    segments.append(str(intro_n))
    segments.append(str(ep))
    segments.append(str(outro_n))

with open(concat_list, "w") as f:
    for s in segments:
        f.write(f"file '{s}'\n")

# 5. Compilar el video largo final
out_final = OUTPUT / "MARATON_Chavo_del_8_KRC.mp4"
print("\n🎬 Compilando video final...")
run([FFMPEG, "-y", "-f", "concat", "-safe", "0",
    "-i", str(concat_list),
    "-c:v", "libx264", "-preset", "fast", "-b:v", "2500k",
    "-c:a", "aac", "-ar", "44100", "-ac", "2", "-b:a", "160k",
    str(out_final)], "Compilacion final de la maratón")

if out_final.exists():
    size_gb = out_final.stat().st_size / (1024**3)
    print(f"\n✅ MARATÓN LISTA: {out_final}")
    print(f"   Tamaño: {size_gb:.2f} GB")
    print(f"   Listo para streaming RTMP en YouTube/Twitch/Kick/Facebook")
else:
    print("\n⚠ Error en la compilación. Revisa los logs.")
