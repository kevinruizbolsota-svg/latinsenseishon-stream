@echo off
cd /d "C:\Users\kevin\StudioProdigio"
yt-dlp --js-runtimes node -f "bv*[height<=720]+ba/b[height<=720]/b" --merge-output-format mp4 --ffmpeg-location "C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin" --no-playlist -o "C:\Users\kevin\StudioProdigio\dbz_to_play\001_saiyajin_latino.%%(ext)s" "https://www.youtube.com/watch?v=3Nuo9qK6Zks" > "C:\Users\kevin\StudioProdigio\dl_saiyajin.log" 2> "C:\Users\kevin\StudioProdigio\dl_saiyajin_err.log"
