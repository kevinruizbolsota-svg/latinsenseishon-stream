﻿from pathlib import Path

def make_spawn(name, model_path, scale="0.6"):
    return r'''[gd_scene load_steps=5 format=3]

[ext_resource type="Script" path="res://zombie.gd" id="1"]
[ext_resource type="PackedScene" path="res://''' + model_path + r'''" id="2"]

[sub_resource type="CapsuleShape3D" id="ZombieShape"]
radius = 0.45
height = 1.8

[sub_resource type="StandardMaterial3D" id="MatZombieFallback"]
albedo_color = Color(0.22, 0.38, 0.2, 1)
roughness = 0.9

[node name="Zombie" type="CharacterBody3D"]
script = ExtResource("1")

[node name="CollisionShape3D" type="CollisionShape3D" parent="."]
shape = SubResource("ZombieShape")

[node name="Cuerpo" type="CSGCylinder3D" parent="."]
radius = 0.35
height = 1.3
material = SubResource("MatZombieFallback")

[node name="Cabeza" type="CSGSphere3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.95, 0)
radius = 0.26
material = SubResource("MatZombieFallback")

[node name="Modelo" parent="." instance=ExtResource("2")]
transform = Transform3D(''' + scale + r''', 0, 0, 0, ''' + scale + r''', 0, 0, 0, ''' + scale + r''', 0, -0.7, 0)
'''

base = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO")
(base/"zombie_spawn.tscn").write_text(make_spawn("zombie_spawn","demonio_pintado.glb"), encoding='utf-8', newline='\n')
(base/"zombie_spawn_dragon.tscn").write_text(make_spawn("zombie_spawn_dragon","dragon_nemesis.glb"), encoding='utf-8', newline='\n')
(base/"zombie_spawn_dark.tscn").write_text(make_spawn("zombie_spawn_dark","dark_sun_gwyndolin.glb"), encoding='utf-8', newline='\n')
print("ok")
