"""
DRAGON BALL Z AUTO-PLAYER 24/7
Sistema de reproduccion automatica de capitulos en secuencia
- Reproduce capitulos en orden
- Guarda capitulos reproducidos en carpeta separada
- Reinicia la lista cuando se acaban
- Auto-reinicio en caso de error
"""
import subprocess, time, json, os, shutil
from pathlib import Path
from datetime import datetime

# === CONFIGURACION ===
STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
FFMPEG = Path(r"C:\Users\kevin\AppData\Local\Microsoft\WinGen\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe")
FFMPEG = Path(r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe")

# Carpetas
DBZ_TO_PLAY = STUDIO / "dbz_to_play"      # Capitulos por reproducir
DBZ_PLAYED = STUDIO / "dbz_played"         # Capitulos ya reproducidos
DBZ_CURRENT = STUDIO / "dbz_current"       # Capitulo actual en reproduccion

# Stream config
CONFIG_FILE = STUDIO / "stream_config.json"
KICK_KEY = "sk_us-west-2_WA6SbsmU87cG_Ab6oRtrRR5SEyYViSA2rWoAuAeGdlR"
RTMP_KICK = "rtmps://fa723794a661.global-contribute.live-video.net:443/app/" + KICK_KEY

# Crear carpetas
for d in [DBZ_TO_PLAY, DBZ_PLAYED, DBZ_CURRENT]:
    d.mkdir(parents=True, exist_ok=True)

class DBZAutoPlayer:
    def __init__(self):
        self.current_process = None
        self.current_chapter = None
        self.played_count = 0
        self.log("DBZ Auto-Player iniciado")

    def log(self, msg):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{timestamp}] {msg}"
        print(line)
        with open(STUDIO / "dbz_player.log", "a", encoding="utf-8") as f:
            f.write(line + "\n")

    def get_next_chapter(self):
        """Obtiene el siguiente capitulo a reproducir."""
        chapters = sorted(DBZ_TO_PLAY.glob("*.mp4"))
        if not chapters:
            # Si no hay mas, mover todos los reproducidos de vuelta
            played = sorted(DBZ_PLAYED.glob("*.mp4"))
            if played:
                self.log("Lista terminada. Reiniciando ciclo...")
                for f in played:
                    shutil.move(str(f), str(DBZ_TO_PLAY / f.name))
                chapters = sorted(DBZ_TO_PLAY.glob("*.mp4"))
            if not chapters:
                return None
        return chapters[0]

    def play_chapter(self, chapter_path):
        """Reproduce un capitulo en Kick via FFmpeg."""
        self.current_chapter = chapter_path
        self.log(f"Reproduciendo: {chapter_path.name}")

        cmd = [
            str(FFMPEG), "-re", "-i", str(chapter_path),
            "-c:v", "libx264", "-preset", "veryfast", "-b:v", "4500k",
            "-maxrate", "4500k", "-bufsize", "9000k", "-pix_fmt", "yuv420p",
            "-g", "60", "-c:a", "aac", "-b:a", "160k", "-ar", "44100",
            "-f", "flv", RTMP_KICK
        ]

        try:
            self.current_process = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self.log(f"Stream iniciado (PID: {self.current_process.pid})")
            return True
        except Exception as e:
            self.log(f"ERROR iniciando stream: {e}")
            return False

    def wait_for_chapter_end(self):
        """Espera a que el capitulo termine."""
        if self.current_process:
            self.current_process.wait()
            self.log(f"Capitulo terminado: {self.current_chapter.name}")

    def move_to_played(self, chapter_path):
        """Mueve el capitulo a la carpeta de reproducidos."""
        dest = DBZ_PLAYED / chapter_path.name
        try:
            shutil.move(str(chapter_path), str(dest))
            self.played_count += 1
            self.log(f"Movido a reproducidos: {chapter_path.name} (total: {self.played_count})")
        except Exception as e:
            self.log(f"ERROR moviendo archivo: {e}")

    def run(self):
        """Loop principal."""
        self.log("=== DBZ AUTO-PLAYER INICIADO ===")
        self.log(f"Capitulos por reproducir: {len(list(DBZ_TO_PLAY.glob('*.mp4')))}")
        self.log(f"Capitulos ya reproducidos: {len(list(DBZ_PLAYED.glob('*.mp4')))}")

        try:
            while True:
                chapter = self.get_next_chapter()
                if not chapter:
                    self.log("No hay capitulos disponibles. Esperando...")
                    time.sleep(60)
                    continue

                if self.play_chapter(chapter):
                    self.wait_for_chapter_end()
                    self.move_to_played(chapter)
                else:
                    self.log("Error reproduciendo. Reintentando en 30s...")
                    time.sleep(30)

        except KeyboardInterrupt:
            self.log("Deteniendo auto-player...")
            if self.current_process:
                self.current_process.terminate()
            self.log("Auto-player detenido.")

if __name__ == "__main__":
    player = DBZAutoPlayer()
    player.run()
