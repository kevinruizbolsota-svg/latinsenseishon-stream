"""
Generador de videos DBZ simples con FFmpeg (sin ImageMagick)
Crea videos con fondos de colores y texto usando FFmpeg drawtext
"""
import subprocess, sys, os, json
from pathlib import Path
from datetime import datetime

STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
FFMPEG = Path(r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe")
OUTPUT_DIR = STUDIO / "videos_generados"
DBZ_DIR = STUDIO / "dbz_to_play"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
DBZ_DIR.mkdir(parents=True, exist_ok=True)

# DBZ episodes
episodes = [
    ("Dragon Ball Z - Frieza Saga Ep 1", "Goku arrives on Namek", "0x1a1a2e"),
    ("Dragon Ball Z - Frieza Saga Ep 2", "Battle with Frieza soldiers", "0x16213e"),
    ("Dragon Ball Z - Frieza Saga Ep 3", "Goku vs Frieza begins", "0x0f3460"),
    ("Dragon Ball Z - Frieza Saga Ep 4", "Frieza transforms", "0x533483"),
    ("Dragon Ball Z - Frieza Saga Ep 5", "Goku goes Super Saiyan", "0xe94560"),
]

def create_video(title, subtitle, color, duration=10, idx=1):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = OUTPUT_DIR / f"dbz_ep{idx:02d}_{timestamp}.mp4"
    frames_dir = STUDIO / "video_temp" / f"dbz_frames_{idx}"
    frames_dir.mkdir(parents=True, exist_ok=True)

    # Clean old frames
    for f in frames_dir.glob("*.png"):
        f.unlink()

    fps = 15  # Lower FPS for speed
    total_frames = duration * fps

    print(f"  Generating {total_frames} frames for: {title}")
    for i in range(total_frames):
        frame_path = frames_dir / f"frame_{i:05d}.png"
        # Use FFmpeg to create a frame with text
        cmd = [
            str(FFMPEG), "-y", "-f", "lavfi",
            "-i", f"color=c={color}:s=1280x720:d=1",
            "-vf", f"drawtext=text='{title}':fontcolor=white:fontsize=48:x=(w-text_w)/2:y=(h-text_h)/2-40:box=1:boxcolor=black@0.5:boxborderw=10,drawtext=text='{subtitle}':fontcolor=0xffcc00:fontsize=28:x=(w-text_w)/2:y=(h-text_h)/2+40",
            "-frames:v", "1", str(frame_path)
        ]
        subprocess.run(cmd, capture_output=True, timeout=30)

    # Compile
    print(f"  Compiling video...")
    cmd = [
        str(FFMPEG), "-y", "-framerate", str(fps),
        "-i", str(frames_dir / "frame_%05d.png"),
        "-c:v", "libx264", "-preset", "fast", "-b:v", "2000k",
        "-pix_fmt", "yuv420p", "-r", "30", str(output_file)
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    if result.returncode == 0 and output_file.exists() and output_file.stat().st_size > 0:
        print(f"  OK: {output_file.name} ({output_file.stat().st_size // 1024}KB)")
        return str(output_file)
    else:
        print(f"  ERROR: {result.stderr[-200:]}")
        return None

def main():
    print("=" * 60)
    print("  DBZ Frieza Saga - Generador de Videos")
    print("=" * 60)

    for i, (title, subtitle, color) in enumerate(episodes, 1):
        print(f"\n[{i}/{len(episodes)}] {title}")
        result = create_video(title, subtitle, color, 10, i)
        if result:
            # Copy to dbz_to_play
            import shutil
            dst = DBZ_DIR / f"dbz_ep{i:02d}.mp4"
            shutil.copy(result, str(dst))
            print(f"  Copied to: {dst}")

    print(f"\n{'='*60}")
    print(f"  Videos generados: {len(list(DBZ_DIR.glob('*.mp4')))}")
    print(f"  Carpeta: {DBZ_DIR}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
