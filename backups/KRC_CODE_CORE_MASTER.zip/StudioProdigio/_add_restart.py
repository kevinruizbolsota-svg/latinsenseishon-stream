﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\player.gd")
t = p.read_text(encoding="utf-8")

# when dead, allow restart with Enter or R (R also reloads but we can handle)
old_dead = r'''	if health <= 0:
		dead = true
		_show_msg("HAS CAÍDO - reinicia para intentar de nuevo", 9999.0)'''
new_dead = r'''	if health <= 0:
		dead = true
		_show_msg("HAS CAÍDO - Presiona ENTER para reiniciar", 9999.0)
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE'''
if old_dead in t: t = t.replace(old_dead, new_dead)

# in physics process, if dead allow restart
old_phys = r'''func _physics_process(delta):
	if dead:
		return'''
new_phys = r'''func _physics_process(delta):
	if dead:
		if Input.is_key_pressed(KEY_ENTER) or Input.is_key_pressed(KEY_KP_ENTER):
			get_tree().reload_current_scene()
		return'''
if old_phys in t: t = t.replace(old_phys, new_phys)

# unhandled input restart too
old_unh = r'''func _unhandled_input(event):
	if dead:
		return'''
new_unh = r'''func _unhandled_input(event):
	if dead:
		if event is InputEventKey and event.pressed and (event.keycode == KEY_ENTER or event.keycode == KEY_KP_ENTER):
			get_tree().reload_current_scene()
		return'''
if old_unh in t: t = t.replace(old_unh, new_unh)

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
