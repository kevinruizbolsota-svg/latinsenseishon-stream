﻿from pathlib import Path
import re
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.tscn")
t = p.read_text(encoding="utf-8")

# 1) Zombies: show fallback bodies again with better look (not invisible, not just green blob)
# Make Cuerpo/Cabeza visible and add arms/legs suggestion via more shapes? simple: visible cylinder+head with darker color
t = t.replace('visible = false\nradius = 0.4\nheight = 1.5\nmaterial = SubResource("MatZombieFallback")',
              'radius = 0.38\nheight = 1.4\nmaterial = SubResource("MatZombieFallback")')
# but be careful not to break other things - do it specifically for zombie cuerpos
for n in range(1, 13):
    old = f'[node name="Cuerpo" type="CSGCylinder3D" parent="Zombie{n}"]\nvisible = false\nradius = 0.4\nheight = 1.5\nmaterial = SubResource("MatZombieFallback")'
    new = f'[node name="Cuerpo" type="CSGCylinder3D" parent="Zombie{n}"]\nradius = 0.35\nheight = 1.3\nmaterial = SubResource("MatZombieFallback")'
    t = t.replace(old, new)
    old_h = f'[node name="Cabeza" type="CSGSphere3D" parent="Zombie{n}"]\ntransform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.0, 0)\nvisible = false\nradius = 0.28\nmaterial = SubResource("MatZombieFallback")'
    new_h = f'[node name="Cabeza" type="CSGSphere3D" parent="Zombie{n}"]\ntransform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.95, 0)\nradius = 0.26\nmaterial = SubResource("MatZombieFallback")'
    t = t.replace(old_h, new_h)

# Make GLB models smaller as overlay (so they don't look giant if scale is off) - try 0.5
t = t.replace('transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.9, 0)\n', 'transform = Transform3D(0.6, 0, 0, 0, 0.6, 0, 0, 0, 0.6, 0, -0.7, 0)\n')
# but the above might affect other things; be more specific - zombie Modelo transforms
for n in range(1, 13):
    # only in zombie context - look for pattern
    pass

# simpler: replace the specific zombie model transform pattern we set
t = t.replace('[node name="Modelo" parent="Zombie1" instance=ExtResource("5")]\ntransform = Transform3D(0.6, 0, 0, 0, 0.6, 0, 0, 0, 0.6, 0, -0.7, 0)',
              '[node name="Modelo" parent="Zombie1" instance=ExtResource("5")]\ntransform = Transform3D(0.6, 0, 0, 0, 0.6, 0, 0, 0, 0.6, 0, -0.7, 0)')
# actually do targeted replacement for all zombie modelos
t2 = t
# revert the broad replace I just did if it hit weapon? weapon Modelo transforms were different
# let me do it properly
p.write_text(t, encoding="utf-8", newline="\n")
print("partial")
