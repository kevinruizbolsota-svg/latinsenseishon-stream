"""
BUSCADOR AUTOMÁTICO DE SERIES VIRALES - Ejecutar cada 2-3 horas
Busca nuevas playlists de nostalgia en YouTube y actualiza el catálogo
"""
import json, time
from pathlib import Path
import yt_dlp

STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
CATALOG_DYNAMIC = STUDIO / "catalogo_dinamico.json"

# Términos de búsqueda que disparan nostalgia masiva
QUERIES = [
    "El Chavo del 8 capítulos completos",
    "Dragon Ball Z episodios completos español",
    "Los Simpsons temporada completa español",
    "Bob Esponja episodios completos español",
    "Naruto capítulos completos español latino",
    "Dragon Ball Super episodios completos",
    "Avatar La Leyenda de Aang completo español",
    "Coraje el Perro Cobarde episodios completos",
    "Dexter laboratorio completo español",
    "Johnny Bravo episodios completos español",
    "Kim Possible completo español latino",
    "Jimmy Neutron episodios completos",
]

def buscar_playlist(query, max_results=3):
    """Busca en YouTube y devuelve las mejores playlists encontradas."""
    opts = {
        "extract_flat": True,
        "quiet": True,
        "default_search": "ytsearch5",
    }
    results = []
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(f"ytsearch5:{query} playlist completa", download=False)
            entries = info.get("entries", [])
            for e in entries[:max_results]:
                url = e.get("url") or e.get("webpage_url","")
                if "list=" in url or "playlist" in url.lower():
                    results.append({
                        "titulo": e.get("title",""),
                        "playlist": url,
                        "views": e.get("view_count", 0),
                        "activo": True
                    })
    except Exception as ex:
        print(f"  ⚠ Error buscando '{query}': {ex}")
    return results

def actualizar_catalogo():
    catalog = {}
    if CATALOG_DYNAMIC.exists():
        catalog = json.loads(CATALOG_DYNAMIC.read_text(encoding="utf-8"))

    print(f"\n🔍 Buscando series virales ({len(QUERIES)} queries)...\n")
    nuevas = 0
    for q in QUERIES:
        time.sleep(2)  # respetar rate limit de YouTube
        playlists = buscar_playlist(q)
        for pl in playlists:
            key = pl["titulo"][:60]
            if key not in catalog:
                catalog[key] = pl
                nuevas += 1
                print(f"  ✅ Nueva serie encontrada: {pl['titulo'][:55]}")

    CATALOG_DYNAMIC.write_text(json.dumps(catalog, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n📋 Catálogo actualizado: {len(catalog)} series totales ({nuevas} nuevas)")
    return catalog

if __name__ == "__main__":
    print("╔════════════════════════════════════════╗")
    print("║  🔭 KABALION - Buscador de Series 24/7  ║")
    print("╚════════════════════════════════════════╝")
    while True:
        actualizar_catalogo()
        horas = 2
        print(f"\n⏰ Próxima búsqueda en {horas} horas...")
        time.sleep(horas * 3600)
