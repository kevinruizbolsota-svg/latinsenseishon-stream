
const fs = require('fs');
const dirs = {
  output: 'C:/Users/kevin/Desktop/VIDEOS LARGOS PARA STREAMING',
  norm: 'C:/Users/kevin/StudioProdigio/episodes_norm',
  raw: 'C:/Users/kevin/StudioProdigio/episodes_raw'
};
Object.entries(dirs).forEach(([k,d]) => {
  const files = fs.existsSync(d) ? fs.readdirSync(d).map(n => n + ':' + Math.round(fs.statSync(d+'/'+n).size/1024/1024)+'MB') : [];
  console.log(k + ':', files.join(' | '));
});
