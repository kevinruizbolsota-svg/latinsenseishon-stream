import os
import sys
import subprocess
from pathlib import Path

BASE_DIR = Path(r"C:\Users\kevin\StudioProdigio")
INPUT_DIR = BASE_DIR / "input"
OUTPUT_DIR = BASE_DIR / "output_shorts"
DESKTOP_DIR = Path(r"C:\Users\kevin\Desktop\SHORTS_PRODIGIO_LISTOS")
ASSETS_DIR = BASE_DIR / "assets"
INTRO_FILE = ASSETS_DIR / "intro" / "intro_oficial.mp4"
OUTRO_FILE = ASSETS_DIR / "outro" / "outro_oficial.mp4"
LOGO_FILE = ASSETS_DIR / "logo" / "logo_krc_transparent.png"

FFMPEG = r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe"

def renderizar_video_transparente(video_raw: Path, output_name: str):
    print(f"\n[1/3] Procesando video con LOGO TRANSPARENTE, corrección cinematográfica y audio HD...")
    temp_clip = BASE_DIR / "temp_core.mp4"
    
    # Filtro completo:
    # 1. Escalar y recortar al centro 1080x1920 (9:16 vertical)
    # 2. Grado cinematográfico (contraste 1.12, saturación viva 1.20, nitidez ultra fina)
    # 3. Superponer Logo KRC TRANSPARENTE en esquina inferior derecha con fundido elegante (fade in y fade out)
    # Sin recuadro negro ni fondo oscuro: canal alfa 100% puro
    vf = (
        "[0:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,"
        "eq=contrast=1.12:brightness=0.01:saturation=1.20,unsharp=3:3:0.9:3:3:0.0[base];"
        "[1:v]scale=210:210,format=rgba,fade=t=in:st=2:d=1:alpha=1,fade=t=out:st=30:d=1:alpha=1[logo];"
        "[base][logo]overlay=W-w-35:H-h-55[v]"
    )
    
    # Audio HD: normalización estéreo a -16 LUFS
    af = "loudnorm=I=-16:TP=-1.5:LRA=11,volume=1.15"
    
    cmd_clip = [
        FFMPEG, "-y",
        "-i", str(video_raw),
        "-loop", "1", "-i", str(LOGO_FILE),
        "-filter_complex", vf,
        "-map", "[v]",
        "-map", "0:a",
        "-af", af,
        "-shortest",
        "-r", "30",
        "-c:v", "libx264", "-preset", "fast", "-crf", "19",
        "-c:a", "aac", "-ar", "44100", "-b:a", "192k",
        str(temp_clip)
    ]
    subprocess.run(cmd_clip)
    
    print("[2/3] Normalizando Intro y Outro oficiales...")
    temp_intro = BASE_DIR / "norm_intro.mp4"
    temp_outro = BASE_DIR / "norm_outro.mp4"
    
    subprocess.run([
        FFMPEG, "-y", "-i", str(INTRO_FILE),
        "-r", "30", "-c:v", "libx264", "-c:a", "aac", "-ar", "44100", "-b:a", "192k",
        str(temp_intro)
    ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    subprocess.run([
        FFMPEG, "-y", "-i", str(OUTRO_FILE),
        "-r", "30", "-c:v", "libx264", "-c:a", "aac", "-ar", "44100", "-b:a", "192k",
        str(temp_outro)
    ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    print("[3/3] Ensamblado final con Logo Transparente...")
    lista_txt = BASE_DIR / "concat_full.txt"
    with open(lista_txt, "w", encoding="utf-8") as f:
        f.write(f"file '{temp_intro.resolve()}'\n")
        f.write(f"file '{temp_clip.resolve()}'\n")
        f.write(f"file '{temp_outro.resolve()}'\n")
        
    out_desktop = DESKTOP_DIR / f"{output_name}.mp4"
    out_studio = OUTPUT_DIR / f"{output_name}.mp4"
    
    cmd_concat = [
        FFMPEG, "-y",
        "-f", "concat", "-safe", "0",
        "-i", str(lista_txt),
        "-c", "copy",
        str(out_desktop)
    ]
    subprocess.run(cmd_concat)
    
    import shutil
    if out_desktop.exists():
        shutil.copy2(out_desktop, out_studio)
        print(f"\n[★] ¡FINALIZADO AL 100%! Video con LOGO TRANSPARENTE listo en:")
        print(f"    🖥️ ESCRITORIO: {out_desktop}")

if __name__ == "__main__":
    chavo = INPUT_DIR / "chavo_clip.mp4"
    if chavo.exists():
        renderizar_video_transparente(chavo, "Short_Chavo_Del_8_Logo_Transparente_KRC")
