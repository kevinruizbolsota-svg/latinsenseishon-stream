﻿import re
from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.tscn")
t = p.read_text(encoding="utf-8")

# Add fallback albedo colors to textured materials so they aren't pure white if texture fails
t = t.replace('albedo_texture = ExtResource("7")\nuv1_scale = Vector3(4, 4, 1)\nroughness = 0.9',
              'albedo_texture = ExtResource("7")\nalbedo_color = Color(0.55, 0.5, 0.45, 1)\nuv1_scale = Vector3(4, 4, 1)\nroughness = 0.9')
t = t.replace('albedo_texture = ExtResource("8")\nuv1_scale = Vector3(3, 2, 1)\nroughness = 0.85',
              'albedo_texture = ExtResource("8")\nalbedo_color = Color(0.6, 0.57, 0.52, 1)\nuv1_scale = Vector3(3, 2, 1)\nroughness = 0.85')
t = t.replace('albedo_texture = ExtResource("8")\nalbedo_color = Color(0.7, 0.68, 0.64, 1)\nuv1_scale = Vector3(4, 4, 1)\nroughness = 0.94',
              'albedo_texture = ExtResource("8")\nalbedo_color = Color(0.5, 0.48, 0.45, 1)\nuv1_scale = Vector3(4, 4, 1)\nroughness = 0.94')
t = t.replace('albedo_texture = ExtResource("9")\nuv1_scale = Vector3(20, 20, 1)\nroughness = 1.0',
              'albedo_texture = ExtResource("9")\nalbedo_color = Color(0.3, 0.35, 0.28, 1)\nuv1_scale = Vector3(20, 20, 1)\nroughness = 1.0')

# Replace weapon nodes with visible CSG + GLB attempt
old_weapons = r'''[node name="WeaponHolder" type="Node3D" parent="Player/Camera3D"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0.22, -0.22, -0.5)

[node name="W1" parent="Player/Camera3D/WeaponHolder" instance=ExtResource("4")]
transform = Transform3D(-0.015, 0, 0, 0, 0.015, 0, 0, 0, -0.015, 0, 0, 0)

[node name="W2" parent="Player/Camera3D/WeaponHolder" instance=ExtResource("4")]
transform = Transform3D(-0.013, 0, 0, 0, 0.013, 0, 0, 0, -0.013, 0.02, -0.01, 0.02)
visible = false

[node name="W3" parent="Player/Camera3D/WeaponHolder" instance=ExtResource("4")]
transform = Transform3D(-0.014, 0, 0, 0, 0.014, 0, 0, 0, -0.014, 0.01, -0.015, 0.01)
visible = false'''

new_weapons = r'''[node name="WeaponHolder" type="Node3D" parent="Player/Camera3D"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0.25, -0.25, -0.55)

[node name="W1" type="Node3D" parent="Player/Camera3D/WeaponHolder"]

[node name="Modelo" parent="Player/Camera3D/WeaponHolder/W1" instance=ExtResource("4")]
transform = Transform3D(-1, 0, 0, 0, 1, 0, 0, 0, -1, 0, -0.05, 0.1)

[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.02, -0.15)
size = Vector3(0.08, 0.1, 0.55)
material = SubResource("MatTecho")

[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, -0.48)
size = Vector3(0.04, 0.04, 0.25)
material = SubResource("MatPared")

[node name="W2" type="Node3D" parent="Player/Camera3D/WeaponHolder"]
visible = false

[node name="Modelo" parent="Player/Camera3D/WeaponHolder/W2" instance=ExtResource("4")]
transform = Transform3D(-1, 0, 0, 0, 1, 0, 0, 0, -1, 0, -0.05, 0.1)

[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.02, -0.12)
size = Vector3(0.07, 0.09, 0.45)
material = SubResource("MatPiso")

[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, -0.4)
size = Vector3(0.035, 0.035, 0.22)
material = SubResource("MatPared")

[node name="W3" type="Node3D" parent="Player/Camera3D/WeaponHolder"]
visible = false

[node name="Modelo" parent="Player/Camera3D/WeaponHolder/W3" instance=ExtResource("4")]
transform = Transform3D(-1.1, 0, 0, 0, 1.1, 0, 0, 0, -1.1, 0, -0.06, 0.12)

[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.03, -0.18)
size = Vector3(0.09, 0.11, 0.6)
material = SubResource("MatMadera")

[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, -0.55)
size = Vector3(0.045, 0.045, 0.28)
material = SubResource("MatPared")'''
t = t.replace(old_weapons, new_weapons)

# Make zombies always visible: add CSG fallback body + head in each zombie, keep Modelo
# For each ZombieN, after CollisionShape3D block add Cuerpo/Cabeza if not present
for n in range(1, 11):
    marker = f'[node name="Modelo" parent="Zombie{n}" instance=ExtResource('
    idx = t.find(marker)
    if idx == -1:
        continue
    # check if Cuerpo already exists for this zombie (before Modelo)
    # insert fallback visuals before Modelo
    # determine which ext resource (5 or 10) - keep as is
    # extract the line
    line_end = t.find('\n', idx)
    modelo_line = t[idx:line_end]
    transform_line_start = line_end + 1
    transform_line_end = t.find('\n', transform_line_start)
    transform_line = t[transform_line_start:transform_line_end]
    # build fallback
    fallback = f'''[node name="Cuerpo" type="CSGCylinder3D" parent="Zombie{n}"]
radius = 0.4
height = 1.5
material = SubResource("MatExterior")

[node name="Cabeza" type="CSGSphere3D" parent="Zombie{n}"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.0, 0)
radius = 0.28
material = SubResource("MatExterior")

'''
    # only insert if no Cuerpo exists
    if f'[node name="Cuerpo" type="CSGCylinder3D" parent="Zombie{n}"]' not in t:
        t = t[:idx] + fallback + t[idx:]

p.write_text(t, encoding="utf-8", newline="\n")
print("ok")
