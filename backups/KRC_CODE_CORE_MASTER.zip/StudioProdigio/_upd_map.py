﻿import math
from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.tscn")
t = p.read_text(encoding="utf-8")

# improve environment: slightly better exposure/fog
t = t.replace('tonemap_exposure = 1.1\n', 'tonemap_exposure = 1.15\nssao_enabled = false\n')
t = t.replace('fog_density = 0.008\n', 'fog_density = 0.0075\nfog_aerial_perspective = 0.3\n')

# add extra ambient light
old_luz = r'''[node name="LuzCentro" type="OmniLight3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 3.5, 0)
light_color = Color(1, 0.94, 0.8, 1)
light_energy = 1.8
omni_range = 22.0
omni_attenuation = 1.1
shadow_enabled = false'''
new_luz = old_luz + r'''

[node name="LuzRincon1" type="OmniLight3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -6, 2.5, -4)
light_color = Color(1, 0.9, 0.75, 1)
light_energy = 0.9
omni_range = 12.0
shadow_enabled = false

[node name="LuzRincon2" type="OmniLight3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 6, 2.5, 4)
light_color = Color(1, 0.9, 0.75, 1)
light_energy = 0.9
omni_range = 12.0
shadow_enabled = false'''
if old_luz in t: t = t.replace(old_luz, new_luz)

# add extra barricades (9,10) before Player node
def ry_tf(x,y,z,ry_deg=0):
    ry = math.radians(ry_deg); c = math.cos(ry); s = math.sin(ry)
    return f"Transform3D({c:.6f}, 0, {s:.6f}, 0, 1, 0, {-s:.6f}, 0, {c:.6f}, {x}, {y}, {z})"

def barricade_node(name, parent_path, x,y,z, ry_deg=0):
    tf = ry_tf(x,y,z,ry_deg); p = parent_path
    lines = [f'[node name="{name}" type="Node3D" parent="{p}"]', f'transform = {tf}', 'script = ExtResource("3")',
             f'[node name="Blocker" type="StaticBody3D" parent="{p}/{name}"]',
             f'[node name="CollisionShape3D" type="CollisionShape3D" parent="{p}/{name}/Blocker"]',
             'shape = SubResource("BarricadeShape")']
    for i in range(1,7):
        by = 0.25 + (i-1)*0.28
        lines += [f'[node name="Board{i}" type="CSGBox3D" parent="{p}/{name}"]',
                  f'transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, {by:.3f}, 0)',
                  'size = Vector3(1.8, 0.18, 0.08)', 'material = SubResource("MatMadera")']
    return "\n".join(lines)

extra = "\n" + barricade_node("Barricada9","Barricadas",-12,0.9,-4,90) + "\n" + barricade_node("Barricada10","Barricadas",12,0.9,4,90) + "\n"

marker = '\n[node name="Player" type="CharacterBody3D" parent="." groups=["player"]]'
if marker in t and 'Barricada9' not in t:
    t = t.replace(marker, extra + marker)

# add some cover props (crates) inside area before Player
props = r'''
[node name="Props" type="Node3D" parent="."]

[node name="Caja1" type="CSGBox3D" parent="Props"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -3, 0.5, -2)
use_collision = true
size = Vector3(1.0, 1.0, 1.0)
material = SubResource("MatMadera")

[node name="Caja2" type="CSGBox3D" parent="Props"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 3.5, 0.5, 2.5)
use_collision = true
size = Vector3(1.1, 1.0, 0.9)
material = SubResource("MatMadera")

[node name="Caja3" type="CSGBox3D" parent="Props"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -2.5, 0.5, 3)
use_collision = true
size = Vector3(0.9, 1.0, 1.0)
material = SubResource("MatTecho")

[node name="Barril1" type="CSGCylinder3D" parent="Props"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 4, 0.45, -3)
use_collision = true
radius = 0.35
height = 0.9
material = SubResource("MatPared")
'''
if marker in t and 'node name="Props"' not in t:
    t = t.replace(marker, props + marker)

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
