"""
SUBIDOR AUTOMÁTICO A GOOGLE DRIVE VÍA N8N / BROWSER
Toma los videos de 'Videos para tiktok' y los sube a la carpeta compartida:
Folder ID: 1pXKrhA-Gzr6aE7siOUxokqVmrxAv5olv
"""
import sys, os, time
from pathlib import Path

FOLDER_ID = "1pXKrhA-Gzr6aE7siOUxokqVmrxAv5olv"
SHORTS_DIR = Path(r"C:\Users\kevin\Desktop\Videos para tiktok")

print(f"[*] Carpeta destino en Google Drive: {FOLDER_ID}")
print(f"[*] Videos listos para sincronizar:")
for f in SHORTS_DIR.glob("*.mp4"):
    mb = f.stat().st_size / (1024 * 1024)
    print(f"  - {f.name} ({mb:.1f} MB)")

print("\n[+] Enlace directo a tu carpeta en la nube:")
print(f"https://drive.google.com/drive/folders/{FOLDER_ID}")
