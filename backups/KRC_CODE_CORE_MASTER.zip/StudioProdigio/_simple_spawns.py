﻿from pathlib import Path
# Simple zombie spawn template without heavy creature GLBs
code = r'''[gd_scene load_steps=4 format=3]

[ext_resource type="Script" path="res://zombie.gd" id="1"]

[sub_resource type="CapsuleShape3D" id="ZombieShape"]
radius = 0.45
height = 1.8

[sub_resource type="StandardMaterial3D" id="MatZombie"]
albedo_color = Color(0.25, 0.42, 0.22, 1)
roughness = 0.85

[node name="Zombie" type="CharacterBody3D"]
script = ExtResource("1")

[node name="CollisionShape3D" type="CollisionShape3D" parent="."]
shape = SubResource("ZombieShape")

[node name="Cuerpo" type="CSGCylinder3D" parent="."]
radius = 0.35
height = 1.3
material = SubResource("MatZombie")

[node name="Cabeza" type="CSGSphere3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.95, 0)
radius = 0.26
material = SubResource("MatZombie")
'''
base = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO")
for name in ["zombie_spawn.tscn", "zombie_spawn_dragon.tscn", "zombie_spawn_dark.tscn"]:
    (base/name).write_text(code, encoding='utf-8', newline='\n')
print('ok')
