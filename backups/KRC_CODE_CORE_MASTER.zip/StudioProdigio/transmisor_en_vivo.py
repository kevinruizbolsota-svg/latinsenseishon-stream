"""
Emisor Automático de Streaming Multi-Plataforma (YouTube / Kick / Twitch / Facebook)
Motor: FFmpeg Nativo con aceleración por hardware o CPU H264
Studio Prodigio - Kevin Esteban Ruiz Calle
"""

import sys
import subprocess
from pathlib import Path

FFMPEG = r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe"

# URLs de ingesta RTMP estándar
PLATAFORMAS_RTMP = {
    "youtube": "rtmp://a.rtmp.youtube.com/live2/",
    "twitch": "rtmp://live.twitch.tv/app/",
    "kick": "rtmps://fa723794a661.global-contribute.live-video.net:443/app/",
    "facebook": "rtmps://live-api-s.facebook.com:443/rtmp/"
}

def iniciar_transmision_directo(video_path, plataforma="youtube", stream_key=""):
    video = Path(video_path)
    if not video.exists():
        print(f"Error: El video no existe en {video}")
        return False
    
    rtmp_base = PLATAFORMAS_RTMP.get(plataforma.lower())
    if not rtmp_base:
        print(f"Plataforma {plataforma} no reconocida.")
        return False
        
    rtmp_url = f"{rtmp_base}{stream_key}"
    print(f"Iniciando emision en vivo hacia {plataforma.upper()}...")
    print(f"Video fuente: {video.name}")
    
    # Comando FFmpeg optimizado para streaming en vivo constante (CBR 4500k, audio AAC 160k, keyframe cada 2s)
    cmd = [
        FFMPEG,
        "-re",  # Lee el archivo a velocidad de reproducción en tiempo real
        "-stream_loop", "-1",  # Repite en bucle si es transmisión 24/7
        "-i", str(video),
        "-c:v", "libx264",
        "-preset", "veryfast",
        "-b:v", "4500k",
        "-maxrate", "4500k",
        "-bufsize", "9000k",
        "-pix_fmt", "yuv420p",
        "-g", "60",  # Keyframe cada 2 segundos a 30fps
        "-c:a", "aac",
        "-b:a", "160k",
        "-ar", "44100",
        "-f", "flv",
        rtmp_url
    ]
    
    try:
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        print(f"Transmision en vivo arrancada con PID: {process.pid}")
        return process
    except Exception as e:
        print(f"Error al arrancar FFmpeg: {e}")
        return None

if __name__ == "__main__":
    print("Modulo de transmision automatica cargado.")
