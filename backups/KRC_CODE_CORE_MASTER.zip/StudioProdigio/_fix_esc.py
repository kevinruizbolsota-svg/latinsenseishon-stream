﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\player.gd")
t = p.read_text(encoding="utf-8")

# remove ESC mouse release from player (main handles pause)
old = r'''	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE'''
if old in t:
    t = t.replace(old, '\t# ESC manejado por pausa en main.gd')

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
