import os
root = r"C:\Users\kevin\Documents\GodotFPS-Zombies-Template"
out = os.path.join(root, "colwar", "COLWAR_main.tscn")
base = os.path.join(root, "colwar_assets")

def to_res(p):
    rel = os.path.relpath(p, root).replace('\\','/')
    return 'res://' + rel

glbs = []
for dp,_,fns in os.walk(base):
    for f in fns:
        if f.lower().endswith('.glb'):
            full=os.path.join(dp,f)
            if os.sep + 'scene' + os.sep + 'source' + os.sep in full and 'scene_Untitled' not in full:
                continue
            glbs.append(full)
def cat(p):
    rp=p.replace('\\','/').lower()
    if '/mapas_bosque/' in rp: return 'Mapas'
    if '/personajes_criaturas/' in rp: return 'Criaturas'
    if '/armas/' in rp: return 'Armas'
    if '/props_vehiculos/' in rp: return 'Props'
    return 'Otros'

groups={}
for g in glbs:
    groups.setdefault(cat(g),[]).append(g)
for k in groups: groups[k].sort()

fixed=[
 ('Script','res://common/managers/input_manager.gd',1),
 ('Script','res://colwar/colwar_main.gd',2),
 ('PackedScene','res://player/player.tscn',3),
 ('PackedScene','res://common/hud/gameplay_hud.tscn',4),
 ('PackedScene','res://common/spawner/spawner.tscn',5),
 ('PackedScene','res://enemies/undead.tscn',6),
 ('Script','res://common/managers/round_manager.gd',7),
]
ext=[]
for t,p,i in fixed:
    ext.append(f'[ext_resource type="{t}" path="{p}" id="{i}"]')
resmap={}; nid=8
for k in ['Mapas','Criaturas','Armas','Props','Otros']:
    for p in groups.get(k,[]):
        rp=to_res(p); ext.append(f'[ext_resource type="PackedScene" path="{rp}" id="{nid}"]'); resmap[p]=nid; nid+=1

# default scales (starting point; GLB units vary - easy to tweak in editor)
scales = {'Mapas': 1.0, 'Criaturas': 1.0, 'Armas': 1.0, 'Props': 1.0, 'Otros': 1.0}

L=[]
L.append('[gd_scene load_steps=8 format=3]\n')
L.extend(e+'\n' for e in ext)
L.append(r'''
[sub_resource type="ProceduralSkyMaterial" id="SkyMat"]
sky_top_color = Color(0.28, 0.42, 0.72, 1)
sky_horizon_color = Color(0.62, 0.72, 0.82, 1)
ground_bottom_color = Color(0.12, 0.16, 0.1, 1)
ground_horizon_color = Color(0.45, 0.5, 0.42, 1)
sun_angle_max = 30.0

[sub_resource type="Sky" id="Sky1"]
sky_material = SubResource("SkyMat")

[sub_resource type="Environment" id="Env1"]
background_mode = 2
sky = SubResource("Sky1")
ambient_light_source = 2
ambient_light_color = Color(0.55, 0.6, 0.72, 1)
ambient_light_energy = 0.65
tonemap_mode = 3
tonemap_exposure = 1.05
ssao_enabled = true
ssao_radius = 1.5
ssao_intensity = 2.0
glow_enabled = true
glow_intensity = 0.35
glow_bloom = 0.05
fog_enabled = true
fog_light_color = Color(0.62, 0.68, 0.78, 1)
fog_density = 0.0015
fog_aerial_perspective = 0.35
volumetric_fog_enabled = false

[sub_resource type="NavigationMesh" id="Nav1"]
geometry_parsed_geometry_type = 1
cell_height = 0.2
agent_radius = 0.45

[sub_resource type="BoxShape3D" id="FloorShape"]
size = Vector3(1200, 2, 1200)

[sub_resource type="StandardMaterial3D" id="MatFloor"]
albedo_color = Color(0.18, 0.26, 0.15, 1)
roughness = 0.95

[sub_resource type="StandardMaterial3D" id="MatPath"]
albedo_color = Color(0.28, 0.24, 0.2, 1)
roughness = 0.9

[node name="COLWAR_Main" type="Node3D"]
script = ExtResource("2")

[node name="InputManager" type="Node" parent="."]
script = ExtResource("1")

[node name="RoundManager" type="Node" parent="."]
script = ExtResource("7")

[node name="WorldEnvironment" type="WorldEnvironment" parent="."]
environment = SubResource("Env1")

[node name="Sol" type="DirectionalLight3D" parent="."]
transform = Transform3D(0.866025, -0.383022, 0.321394, 0, 0.642788, 0.766044, -0.5, -0.663414, 0.55667, 0, 60, 0)
light_color = Color(1, 0.97, 0.9, 1)
light_energy = 2.2
shadow_enabled = true
shadow_blur = 1.5
directional_shadow_max_distance = 250.0

[node name="RellenoLuz" type="DirectionalLight3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 0.3, 0.953939, 0, -0.953939, 0.3, 0, 30, 0)
light_color = Color(0.75, 0.82, 1, 1)
light_energy = 0.45
shadow_enabled = false

[node name="Player" parent="." instance=ExtResource("3")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 2.5, 80)

[node name="HUD" type="CanvasLayer" parent="."]

[node name="Control" parent="HUD" instance=ExtResource("4")]

[node name="NavigationRegion3D" type="NavigationRegion3D" parent="."]
navigation_mesh = SubResource("Nav1")

[node name="SueloColision" type="StaticBody3D" parent="NavigationRegion3D"]
collision_layer = 5
collision_mask = 5
[node name="CollisionShape3D" type="CollisionShape3D" parent="NavigationRegion3D/SueloColision"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -1, 0)
shape = SubResource("FloorShape")

[node name="SueloVerde" type="CSGBox3D" parent="NavigationRegion3D"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -1.05, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(1200, 0.1, 1200)
material = SubResource("MatFloor")

[node name="Caminos" type="Node3D" parent="NavigationRegion3D"]
[node name="Camino1" type="CSGBox3D" parent="NavigationRegion3D/Caminos"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.98, 0)
size = Vector3(12, 0.12, 900)
material = SubResource("MatPath")
[node name="Camino2" type="CSGBox3D" parent="NavigationRegion3D/Caminos"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.98, 0)
size = Vector3(900, 0.12, 12)
material = SubResource("MatPath")

[node name="TodoElContenido" type="Node3D" parent="NavigationRegion3D"]

[node name="Enemies" type="Node3D" parent="."]

[node name="Spawner1" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 20, 0.5, 20)
item = ExtResource("6")
spawn_time = 3.5
max_items = 2
[node name="Spawner2" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -20, 0.5, 20)
item = ExtResource("6")
spawn_time = 3.5
max_items = 2
[node name="Spawner3" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.5, -20)
item = ExtResource("6")
spawn_time = 4.0
max_items = 2
''')

# zones: mapas spread wide, criaturas in a row, armas/props grouped
zones = {
 'Mapas':    {'x': -220, 'z0': -120, 'sp': 120, 'cols': 3},
 'Criaturas':{'x':  0,   'z0': -60,  'sp': 22,  'cols': 6},
 'Armas':    {'x':  180, 'z0': -20,  'sp': 12,  'cols': 4},
 'Props':    {'x':  260, 'z0': -20,  'sp': 20,  'cols': 3},
 'Otros':    {'x': -320, 'z0': -20,  'sp': 20,  'cols': 2},
}
for k in ['Mapas','Criaturas','Armas','Props','Otros']:
    items=groups.get(k,[]); zc=zones[k]; s=scales[k]
    L.append(f'\n[node name="Zona_{k}" type="Node3D" parent="NavigationRegion3D/TodoElContenido"]\n')
    for i,p in enumerate(items):
        col=i%zc['cols']; row=i//zc['cols']
        x=zc['x'] + col*zc['sp']; z=zc['z0'] + row*zc['sp']
        nm=os.path.splitext(os.path.basename(p))[0][:38]
        for ch in ' -./\\()\'"': nm=nm.replace(ch,'_')
        rid=resmap[p]
        L.append(f'[node name="{nm}_{i}" parent="NavigationRegion3D/TodoElContenido/Zona_{k}" instance=ExtResource("{rid}")]\n')
        L.append(f'transform = Transform3D({s}, 0, 0, 0, {s}, 0, 0, 0, {s}, {x}, 0, {z})\n')

open(out,'w',encoding='utf-8').write(''.join(L))
print('ok', len(glbs))
