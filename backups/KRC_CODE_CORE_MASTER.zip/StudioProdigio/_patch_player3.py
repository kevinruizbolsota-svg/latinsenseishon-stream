﻿import re
from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\player.gd")
t = p.read_text(encoding="utf-8")

# weapons array - add 3rd
old_w = r'''var weapons = [
	{"name": "Gewehr 41", "rate": 0.42, "damage": 40},
	{"name": "Rifle Rápido", "rate": 0.13, "damage": 18},
]'''
new_w = r'''var weapons = [
	{"name": "Gewehr 41", "rate": 0.42, "damage": 40},
	{"name": "Rifle Rápido", "rate": 0.13, "damage": 18},
	{"name": "Ametralladora", "rate": 0.08, "damage": 14},
]'''
t = t.replace(old_w, new_w)

# input for weapon_3
old_in = r'''	if event.is_action_pressed("weapon_1"):
		_set_weapon(0)
	if event.is_action_pressed("weapon_2"):
		_set_weapon(1)'''
new_in = r'''	if event.is_action_pressed("weapon_1"):
		_set_weapon(0)
	if event.is_action_pressed("weapon_2"):
		_set_weapon(1)
	if event.is_action_pressed("weapon_3"):
		_set_weapon(2)'''
t = t.replace(old_in, new_in)

# visual: handle W3
old_vis = r'''func _update_weapon_visual():
	if not weapon_holder:
		return
	for i in range(weapon_holder.get_child_count()):
		var c = weapon_holder.get_child(i)
		c.visible = (c.name == "W1" and current_weapon == 0) or (c.name == "W2" and current_weapon == 1)'''
new_vis = r'''func _update_weapon_visual():
	if not weapon_holder:
		return
	for i in range(weapon_holder.get_child_count()):
		var c = weapon_holder.get_child(i)
		c.visible = (c.name == "W1" and current_weapon == 0) or (c.name == "W2" and current_weapon == 1) or (c.name == "W3" and current_weapon == 2)'''
t = t.replace(old_vis, new_vis)

# UI text
old_ui = r'		label.text = "COLWAR | Puntos: %d | Arma [1/2]: %s (cadencia %.2fs, daño %d) | E reparar | Click disparar | ESC mouse" % [points, w.name, w.rate, w.damage]'
new_ui = r'		label.text = "COLWAR | Puntos: %d | Arma [1/2/3]: %s (cadencia %.2fs, daño %d) | E/F reparar | Click disparar | ESC mouse" % [points, w.name, w.rate, w.damage]'
t = t.replace(old_ui, new_ui)

p.write_text(t, encoding="utf-8", newline="\n")
print("ok")
