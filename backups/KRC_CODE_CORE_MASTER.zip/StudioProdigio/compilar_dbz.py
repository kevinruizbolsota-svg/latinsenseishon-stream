"""
Compilar Dragon Ball Z para streaming
"""
import sys
sys.path.insert(0, r"C:\Users\kevin\StudioProdigio")
from catalogo_tv import CATALOGO_SERIES
from kabalion_tv_engine import compilar_programa_tv

# Dragon Ball Z es el tercero de cartoon_network
dbz = [CATALOGO_SERIES["cartoon_network"][2]]  # Dragon Ball Z
print(f"Compilando: {dbz[0]['titulo']}")
print(f"Playlist: {dbz[0]['playlist']}")

out = compilar_programa_tv(dbz, "MARATON_DragonBallZ_KRC", ep_por_serie=3)
if out:
    print(f"\nVideo compilado: {out}")
else:
    print("\nCompilacion fallida")
