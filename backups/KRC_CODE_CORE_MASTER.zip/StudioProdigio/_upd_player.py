﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\player.gd")
code = r'''extends CharacterBody3D

@export var speed := 5.5
@export var mouse_sensitivity := 0.0022
@export var gravity := 18.0

@onready var camera: Camera3D = $Camera3D
@onready var ray: RayCast3D = $Camera3D/RayCast3D
@onready var weapon_holder: Node3D = $Camera3D/WeaponHolder
@onready var label: Label = get_node_or_null("../UI/Label")
@onready var hint: Label = get_node_or_null("../UI/Hint")
@onready var status_label: Label = get_node_or_null("../UI/Status")
@onready var msg_label: Label = get_node_or_null("../UI/Msg")

var points := 0
var kills := 0
var current_weapon := 0
var shoot_cd := 0.0
var reload_cd := 0.0
var max_health := 100
var health := 100
var dead := false
var _msg_timer := 0.0

# [name, fire_interval, damage, mag_size, reserve]
var weapons = [
	{"name": "Gewehr 41", "rate": 0.42, "damage": 40, "mag": 10, "mag_max": 10, "reserve": 80},
	{"name": "Rifle Rápido", "rate": 0.13, "damage": 18, "mag": 30, "mag_max": 30, "reserve": 180},
	{"name": "Ametralladora", "rate": 0.08, "damage": 14, "mag": 60, "mag_max": 60, "reserve": 300},
]

func _ready():
	add_to_group("player")
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	_update_weapon_visual()
	_update_ui()

func _unhandled_input(event):
	if dead:
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * mouse_sensitivity)
		camera.rotate_x(-event.relative.y * mouse_sensitivity)
		camera.rotation.x = clamp(camera.rotation.x, -1.45, 1.45)
	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	if event.is_action_pressed("weapon_1"):
		_set_weapon(0)
	if event.is_action_pressed("weapon_2"):
		_set_weapon(1)
	if event.is_action_pressed("weapon_3"):
		_set_weapon(2)
	if event.is_action_pressed("reload"):
		_start_reload()

func _physics_process(delta):
	if dead:
		return
	shoot_cd = max(shoot_cd - delta, 0.0)
	if reload_cd > 0.0:
		reload_cd -= delta
		if reload_cd <= 0.0:
			_finish_reload()
	if _msg_timer > 0.0:
		_msg_timer -= delta
		if _msg_timer <= 0.0 and msg_label:
			msg_label.text = ""

	if not is_on_floor():
		velocity.y -= gravity * delta
	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var dir := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	if dir:
		velocity.x = dir.x * speed
		velocity.z = dir.z * speed
	else:
		velocity.x = move_toward(velocity.x, 0, speed)
		velocity.z = move_toward(velocity.z, 0, speed)
	move_and_slide()

	# shoot
	if Input.is_action_pressed("shoot") and shoot_cd <= 0.0 and reload_cd <= 0.0:
		_shoot()

	# interact / build barricade
	var near_b = _nearest_barricade(3.5)
	if hint:
		if near_b and not near_b.is_complete():
			hint.text = "[E / F] MANTENER: reparar tabla (%d/%d)" % [near_b.boards_up, near_b.boards_total]
		elif near_b and near_b.is_complete():
			hint.text = "Barrera completa (%d/%d)" % [near_b.boards_up, near_b.boards_total]
		else:
			hint.text = ""
	if near_b and Input.is_action_pressed("interact"):
		near_b.player_try_build(delta)
	_update_ui()

func _shoot():
	var w = weapons[current_weapon]
	if w.mag <= 0:
		_start_reload()
		return
	w.mag -= 1
	shoot_cd = w.rate
	camera.rotation.x = clamp(camera.rotation.x + 0.012, -1.45, 1.45)
	if ray and ray.is_colliding():
		var c = ray.get_collider()
		if c and c.has_method("take_damage") and c.is_in_group("zombie"):
			c.take_damage(w.damage)
		elif c and c.has_method("take_damage"):
			c.take_damage(w.damage)
	_update_ui()

func _start_reload():
	var w = weapons[current_weapon]
	if reload_cd > 0.0 or w.mag >= w.mag_max or w.reserve <= 0:
		return
	reload_cd = 1.6
	_show_msg("Recargando...")
	_update_ui()

func _finish_reload():
	var w = weapons[current_weapon]
	var need = w.mag_max - w.mag
	var take = min(need, w.reserve)
	w.mag += take
	w.reserve -= take
	_update_ui()

func _set_weapon(idx: int):
	if idx == current_weapon or idx < 0 or idx >= weapons.size():
		return
	current_weapon = idx
	shoot_cd = 0.0
	reload_cd = 0.0
	_update_weapon_visual()
	_update_ui()

func _update_weapon_visual():
	if not weapon_holder:
		return
	for i in range(weapon_holder.get_child_count()):
		var c = weapon_holder.get_child(i)
		c.visible = (c.name == "W1" and current_weapon == 0) or (c.name == "W2" and current_weapon == 1) or (c.name == "W3" and current_weapon == 2)

func _nearest_barricade(max_dist: float):
	var best = null
	var best_d = max_dist
	for b in get_tree().get_nodes_in_group("barricade"):
		if not is_instance_valid(b):
			continue
		var d = global_position.distance_to(b.global_position)
		if d < best_d:
			best_d = d
			best = b
	return best

func take_damage(amount: int):
	if dead:
		return
	health = max(health - amount, 0)
	_show_msg("¡Te golpearon! -%d" % amount)
	if health <= 0:
		dead = true
		_show_msg("HAS CAÍDO - reinicia para intentar de nuevo", 9999.0)
	_update_ui()

func add_kill_reward(pts: int = 10):
	points += pts
	kills += 1
	_update_ui()

func _show_msg(text: String, t: float = 1.2):
	if msg_label:
		msg_label.text = text
	_msg_timer = t

func _update_ui():
	var w = weapons[current_weapon]
	if status_label:
		status_label.text = "Vida: %d/%d | Puntos: %d | Bajas: %d" % [health, max_health, points, kills]
	if label:
		var rel = " (RECARGANDO)" if reload_cd > 0.0 else ""
		label.text = "Arma [1/2/3]: %s | %d/%d (%d) | Cadencia %.2fs Daño %d%s | R recargar" % [w.name, w.mag, w.mag_max, w.reserve, w.rate, w.damage, rel]
'''
p.write_text(code, encoding="utf-8", newline="\n")
print("ok")
