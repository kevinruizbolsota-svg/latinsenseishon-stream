const fs = require('fs');
const html = fs.readFileSync('C:/Users/kevin/StudioProdigio/moltbot.html', 'utf8');

const regexes = [
  /npm install[^\n<"]+/gi,
  /pip install[^\n<"]+/gi,
  /docker run[^\n<"]+/gi,
  /git clone[^\n<"]+/gi,
  /https?:\/\/github\.com\/[^\s"']+/gi
];

regexes.forEach(r => {
  const m = html.match(r);
  if (m) console.log(m.slice(0, 5));
});
