﻿import re
from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.tscn")
t = p.read_text(encoding="utf-8")
# bump load_steps
t = re.sub(r'\[gd_scene load_steps=(\d+) format=3\]', lambda m: f'[gd_scene load_steps={int(m.group(1))+1} format=3]', t, count=1)
# add ext_resource after id=2
t = t.replace('[ext_resource type="Script" path="res://zombie.gd" id="2"]',
              '[ext_resource type="Script" path="res://zombie.gd" id="2"]\n[ext_resource type="PackedScene" path="res://forest.glb" id="3"]')
# add forest instance after Suelo
t = t.replace('[node name="Arboles" type="Node3D" parent="."]',
              '[node name="Bosque" parent="." instance=ExtResource("3")]\n\n[node name="Arboles" type="Node3D" parent="."]')
p.write_text(t, encoding="utf-8", newline="\n")
print("ok")
