﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.tscn")
t = p.read_text(encoding="utf-8")

# Add perimeter collision walls to prevent walking through (Military_Post has no collision)
# Place invisible-ish boundary walls
walls = r'''
[node name="Limites" type="Node3D" parent="."]

[node name="LimiteN" type="CSGBox3D" parent="Limites"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 2, -18)
use_collision = true
visible = false
size = Vector3(40, 6, 1)

[node name="LimiteS" type="CSGBox3D" parent="Limites"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 2, 18)
use_collision = true
visible = false
size = Vector3(40, 6, 1)

[node name="LimiteO" type="CSGBox3D" parent="Limites"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -18, 2, 0)
use_collision = true
visible = false
size = Vector3(1, 6, 40)

[node name="LimiteE" type="CSGBox3D" parent="Limites"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 18, 2, 0)
use_collision = true
visible = false
size = Vector3(1, 6, 40)
'''
if 'node name="Limites"' not in t:
    marker = '\n[node name="Barricadas" type="Node3D" parent="."]'
    if marker in t:
        t = t.replace(marker, walls + marker)

# Make weapon CSG parts look better (darker, slimmer, more gun-like) and less obtrusive
# Add a MatArma metal material
old_mat_zombie = r'''[sub_resource type="StandardMaterial3D" id="MatZombieFallback"]
albedo_color = Color(0.22, 0.38, 0.2, 1)
roughness = 0.9'''
new_mat_zombie = old_mat_zombie + r'''

[sub_resource type="StandardMaterial3D" id="MatArma"]
albedo_color = Color(0.18, 0.18, 0.2, 1)
metallic = 0.3
roughness = 0.45'''
if old_mat_zombie in t and 'id="MatArma"' not in t:
    t = t.replace(old_mat_zombie, new_mat_zombie)
    # bump load_steps
    import re
    t = re.sub(r'\[gd_scene load_steps=(\d+) format=3\]', lambda m: f'[gd_scene load_steps={int(m.group(1))+1} format=3]', t, count=1)

# W1: refine
repls = [
(r'''[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.03, -0.18)
size = Vector3(0.07, 0.09, 0.5)
material = SubResource("MatMadera")''',
 r'''[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.03, -0.2)
size = Vector3(0.055, 0.07, 0.45)
material = SubResource("MatArma")'''),
(r'''[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.0, -0.52)
size = Vector3(0.03, 0.03, 0.35)
material = SubResource("MatTecho")''',
 r'''[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.0, -0.5)
size = Vector3(0.025, 0.025, 0.3)
material = SubResource("MatArma")'''),
(r'''[node name="Culata" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.04, 0.08)
size = Vector3(0.06, 0.1, 0.18)
material = SubResource("MatMadera")''',
 r'''[node name="Culata" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.04, 0.06)
size = Vector3(0.05, 0.08, 0.14)
material = SubResource("MatMadera")'''),
# W2
(r'''[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.02, -0.14)
size = Vector3(0.065, 0.085, 0.42)
material = SubResource("MatExterior")''',
 r'''[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.02, -0.16)
size = Vector3(0.05, 0.065, 0.38)
material = SubResource("MatArma")'''),
(r'''[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.0, -0.43)
size = Vector3(0.028, 0.028, 0.3)
material = SubResource("MatPared")''',
 r'''[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.0, -0.42)
size = Vector3(0.022, 0.022, 0.26)
material = SubResource("MatArma")'''),
(r'''[node name="Culata" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.03, 0.07)
size = Vector3(0.055, 0.09, 0.15)
material = SubResource("MatMadera")''',
 r'''[node name="Culata" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.03, 0.05)
size = Vector3(0.045, 0.07, 0.12)
material = SubResource("MatMadera")'''),
# W3
(r'''[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.03, -0.2)
size = Vector3(0.085, 0.1, 0.58)
material = SubResource("MatExterior")''',
 r'''[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.03, -0.22)
size = Vector3(0.06, 0.075, 0.5)
material = SubResource("MatArma")'''),
(r'''[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.0, -0.58)
size = Vector3(0.035, 0.035, 0.38)
material = SubResource("MatTecho")''',
 r'''[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.0, -0.56)
size = Vector3(0.028, 0.028, 0.32)
material = SubResource("MatArma")'''),
(r'''[node name="Culata" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.04, 0.1)
size = Vector3(0.065, 0.1, 0.2)
material = SubResource("MatMadera")''',
 r'''[node name="Culata" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.04, 0.06)
size = Vector3(0.05, 0.08, 0.15)
material = SubResource("MatMadera")'''),
(r'''[node name="Cargador" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.12, -0.12)
size = Vector3(0.04, 0.16, 0.08)
material = SubResource("MatTecho")''',
 r'''[node name="Cargador" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.1, -0.14)
size = Vector3(0.03, 0.13, 0.07)
material = SubResource("MatArma")'''),
]
for a,b in repls:
    if a in t: t = t.replace(a,b)

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
