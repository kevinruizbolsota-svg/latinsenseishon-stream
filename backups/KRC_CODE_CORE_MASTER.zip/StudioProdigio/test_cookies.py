import yt_dlp
for browser in ['edge', 'firefox', 'brave', 'opera']:
    opts = {'cookiesfrombrowser': (browser,), 'quiet': True, 'no_warnings': True}
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info('https://www.youtube.com/watch?v=wkb7n2q6p9g', download=False)
        print(f'{browser}: OK - {info.get("title","")[:50]}')
        break
    except Exception as e:
        print(f'{browser}: {str(e)[:60]}')
