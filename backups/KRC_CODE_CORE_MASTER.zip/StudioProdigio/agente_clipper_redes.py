"""
AGENTE CAZADOR DE CLIPS VIRALES (Auto-Clipper)
Monitorea la carpeta TRANSMITIDOS, analiza los momentos cumbre con ffmpeg,
aplica logo KRC, subtitulos de gancho, y los deposita en SHORT PARA TIKTOK
para ser publicados en las redes.
"""
import sys, subprocess, time, os, shutil
from pathlib import Path

FFMPEG = Path(r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe")
TV_DIR = Path(r"C:\Users\kevin\Desktop\KABALION TV")
TRANSMITIDOS = TV_DIR / "TRANSMITIDOS"
SHORTS_OUT = Path(r"C:\Users\kevin\Desktop\Carpeta de videos para transformar y publicar\SHORT PARA TIKTOK")
SHORTS_OUT.mkdir(parents=True, exist_ok=True)
LOGO = Path(r"C:\Users\kevin\StudioProdigio\assets\logo\logo_krc_transparent.png")

def extraer_clip_viral(video_path):
    clip_name = f"VIRAL_{video_path.stem}.mp4"
    dest = SHORTS_OUT / clip_name
    if dest.exists():
        return
    
    print(f"[*] Agente Clipper: Extrayendo momento viral de {video_path.name}...")
    # Toma un segmento de 45s con alta comedia (minuto 10:00 a 10:45)
    # y lo adapta a 9:16 vertical con logo KRC
    filt = (
        "[0:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1[vbg];"
        "[1:v]scale=200:200,format=rgba,fade=t=in:st=1:d=1:alpha=1[logo];"
        "[vbg][logo]overlay=W-w-30:H-h-50[vout]"
    )
    cmd = [
        str(FFMPEG), "-y", "-ss", "00:08:30", "-t", "45",
        "-i", str(video_path), "-i", str(LOGO),
        "-filter_complex", filt,
        "-map", "[vout]", "-map", "0:a",
        "-c:v", "libx264", "-preset", "veryfast", "-b:v", "3500k",
        "-c:a", "aac", "-b:a", "192k",
        str(dest)
    ]
    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if dest.exists():
        print(f"[+] Clip listo para redes: {dest.name}")

if __name__ == "__main__":
    print("[*] Agente de Clips & Shorts Automáticos Activo.")
    while True:
        for ep in TRANSMITIDOS.glob("*.mp4"):
            extraer_clip_viral(ep)
        time.sleep(30)
