"""
KABALION TV API - Servidor HTTP local para n8n
Expone las funciones del motor TV como endpoints REST
"""
import json
import subprocess
import sys
import os
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from datetime import datetime

STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
PYTHON = r"C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe"
DBZ_TO_PLAY = STUDIO / "dbz_to_play"
DBZ_PLAYED = STUDIO / "dbz_played"

class TVHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/health":
            self.send_json({"status": "ok", "service": "Kabalion TV API"})
        elif self.path == "/catalog":
            import json as j
            catalog_path = STUDIO / "catalogo_dinamico.json"
            if catalog_path.exists():
                self.send_json(j.loads(catalog_path.read_text()))
            else:
                self.send_json({"error": "Catalog not found"})
        else:
            self.send_json({"error": "Not found"}, 404)

    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8') if content_length > 0 else '{}'
        try:
            data = json.loads(body)
        except:
            data = {}

        if self.path == "/search":
            # Run buscador_series.py
            result = run_script("buscador_series.py")
            self.send_json({"status": "ok", "output": result})
        elif self.path == "/compile":
            result = run_script("kabalion_tv_engine.py")
            self.send_json({"status": "ok", "output": result})
        elif self.path == "/stream":
            result = run_script("transmisor_24_7.py")
            self.send_json({"status": "ok", "output": result})
        elif self.path == "/full-cycle":
            # Full cycle: search + compile + stream
            r1 = run_script("buscador_series.py")
            r2 = run_script("kabalion_tv_engine.py")
            r3 = run_script("transmisor_24_7.py")
            self.send_json({"status": "ok", "search": r1, "compile": r2, "stream": r3})
        elif self.path == "/dbz-status":
            to_play = list(DBZ_TO_PLAY.glob("*.mp4")) if 'DBZ_TO_PLAY' in globals() else []
            played = list(DBZ_PLAYED.glob("*.mp4")) if 'DBZ_PLAYED' in globals() else []
            self.send_json({"status": "ok", "to_play": len(to_play), "played": len(played)})
        else:
            self.send_json({"error": "Not found"}, 404)

    def send_json(self, data, status=200):
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode('utf-8'))

    def log_message(self, format, *args):
        print(f"[TV API] {format % args}")

def run_script(script_name):
    script_path = STUDIO / script_name
    if not script_path.exists():
        return f"Script not found: {script_name}"
    try:
        result = subprocess.run(
            [PYTHON, str(script_path)],
            capture_output=True, text=True, timeout=300
        )
        output = result.stdout[-500:] if result.stdout else ""
        if result.returncode != 0:
            output += "\nERROR: " + (result.stderr[-300:] if result.stderr else "")
        return output.strip()
    except subprocess.TimeoutExpired:
        return "Timeout: script took too long"
    except Exception as e:
        return f"Error: {str(e)}"

if __name__ == "__main__":
    port = 8899
    server = HTTPServer(("0.0.0.0", port), TVHandler)
    print(f"Kabalion TV API running on http://localhost:{port}")
    print(f"Endpoints: GET /health, GET /catalog, POST /search, POST /compile, POST /stream, POST /full-cycle")
    server.serve_forever()
