const fs = require('fs');
const p = 'C:/Users/kevin/StudioProdigio/kabalion_tv_live.py';

if (fs.existsSync(p)) {
  let code = fs.readFileSync(p, 'utf8');
  
  const helper = `
def safe_move(src, dst, max_retries=6, delay=1.5):
    for i in range(max_retries):
        try:
            shutil.move(str(src), str(dst))
            return True
        except PermissionError:
            time.sleep(delay)
        except Exception:
            break
    try:
        shutil.copyfile(str(src), str(dst))
        time.sleep(0.5)
        os.unlink(str(src))
        return True
    except Exception as e:
        log(f"Aviso al mover {Path(src).name}: {e}")
        return False
`;
  
  code = helper + '\n' + code;
  code = code.split('shutil.move(str(ep), str(dest))').join('safe_move(ep, dest)');
  code = code.split('shutil.move(str(dest), str(arch))').join('safe_move(dest, arch)');
  
  fs.writeFileSync(p, code, 'utf8');
  console.log('Parche safe_move aplicado con exito');
}
