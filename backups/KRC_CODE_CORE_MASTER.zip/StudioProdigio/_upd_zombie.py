﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\zombie.gd")
code = r'''extends CharacterBody3D

@export var speed := 2.6
@export var hp := 80
@export var damage := 10
@export var attack_interval := 1.1

var player: Node3D
var _attack_cd := 0.0
var _dead := false

func _ready():
	add_to_group("zombie")
	player = get_tree().get_first_node_in_group("player")

func _physics_process(delta):
	if _dead:
		return
	_attack_cd = max(_attack_cd - delta, 0.0)
	if not player or not is_instance_valid(player):
		player = get_tree().get_first_node_in_group("player")
	if not is_on_floor():
		velocity.y -= 18.0 * delta
	if not player:
		return

	var target_pos: Vector3 = player.global_position
	var target_barricade = _choose_barricade()
	if target_barricade and not target_barricade.is_passable():
		target_pos = target_barricade.global_position
		var dist_b = Vector2(global_position.x - target_pos.x, global_position.z - target_pos.z).length()
		if dist_b < 1.4:
			velocity.x = 0
			velocity.z = 0
			if _attack_cd <= 0.0:
				target_barricade.zombie_try_break(delta)
				_attack_cd = 0.9
			move_and_slide()
			return
	elif target_barricade and target_barricade.is_passable():
		# path through open barricade toward player
		target_pos = player.global_position

	var dir = target_pos - global_position
	dir.y = 0
	var dist_p = Vector2(global_position.x - player.global_position.x, global_position.z - player.global_position.z).length()
	if dir.length() > 1.15:
		dir = dir.normalized()
		velocity.x = dir.x * speed
		velocity.z = dir.z * speed
		var look_t = global_position + dir
		if global_position.distance_to(look_t) > 0.01:
			look_at(look_t, Vector3.UP)
	else:
		velocity.x = move_toward(velocity.x, 0, speed)
		velocity.z = move_toward(velocity.z, 0, speed)

	# attack player if close
	if dist_p < 1.5 and _attack_cd <= 0.0 and player.has_method("take_damage"):
		player.take_damage(damage)
		_attack_cd = attack_interval

	move_and_slide()

func _choose_barricade():
	var barricades = get_tree().get_nodes_in_group("barricade")
	if barricades.is_empty():
		return null
	var passable_best = null
	var passable_d = 99999.0
	var block_best = null
	var block_d = 99999.0
	for b in barricades:
		if not is_instance_valid(b):
			continue
		var d = global_position.distance_to(b.global_position)
		if b.is_passable():
			if d < passable_d:
				passable_d = d
				passable_best = b
		else:
			if d < block_d:
				block_d = d
				block_best = b
	if passable_best and passable_d < 45.0:
		return passable_best
	return block_best

func take_damage(amount: int):
	if _dead:
		return
	hp -= amount
	scale = Vector3(1.08, 0.92, 1.08)
	var t = get_tree().create_timer(0.05)
	await t.timeout
	if is_instance_valid(self):
		scale = Vector3.ONE
	if hp <= 0 and not _dead:
		_dead = true
		var p = get_tree().get_first_node_in_group("player")
		if p and p.has_method("add_kill_reward"):
			p.add_kill_reward(10)
		queue_free()
'''
p.write_text(code, encoding="utf-8", newline="\n")
print("ok")
