﻿from pathlib import Path
# zombie template for spawning
zt = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\zombie_spawn.tscn")
zcode = r'''[gd_scene load_steps=5 format=3]

[ext_resource type="Script" path="res://zombie.gd" id="1"]
[ext_resource type="PackedScene" path="res://demonio_pintado.glb" id="2"]

[sub_resource type="CapsuleShape3D" id="ZombieShape"]
radius = 0.45
height = 1.8

[sub_resource type="StandardMaterial3D" id="MatZombieFallback"]
albedo_color = Color(0.22, 0.38, 0.2, 1)
roughness = 0.9

[node name="Zombie" type="CharacterBody3D"]
script = ExtResource("1")

[node name="CollisionShape3D" type="CollisionShape3D" parent="."]
shape = SubResource("ZombieShape")

[node name="Cuerpo" type="CSGCylinder3D" parent="."]
radius = 0.4
height = 1.5
material = SubResource("MatZombieFallback")

[node name="Cabeza" type="CSGSphere3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.0, 0)
radius = 0.28
material = SubResource("MatZombieFallback")

[node name="Modelo" parent="." instance=ExtResource("2")]
transform = Transform3D(0.012, 0, 0, 0, 0.012, 0, 0, 0, 0.012, 0, -0.9, 0)
'''
zt.write_text(zcode, encoding='utf-8', newline='\n')

# main.gd round manager
mg = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.gd")
mcode = r'''extends Node3D

@export var base_zombies := 6
@export var zombies_per_round := 2
@export var spawn_delay := 1.2

var round_num := 1
var to_spawn := 0
var spawned_this_round := 0
var _spawn_timer := 0.0
var _between_rounds := 4.0
var _in_round := true
var _zombie_scene: PackedScene

var _spawn_points: Array[Vector3] = [
	Vector3(0, 1.5, -20), Vector3(0, 1.5, 20),
	Vector3(-20, 1.5, 0), Vector3(20, 1.5, 0),
	Vector3(-15, 1.5, -15), Vector3(15, 1.5, -15),
	Vector3(-15, 1.5, 15), Vector3(15, 1.5, 15),
	Vector3(0, 1.5, -28), Vector3(0, 1.5, 28),
]

func _ready():
	_zombie_scene = load("res://zombie_spawn.tscn")
	# account for pre-placed zombies as round 1 in progress
	to_spawn = 0
	_update_round_ui()

func _process(delta):
	_update_round_ui()
	var alive = get_tree().get_nodes_in_group("zombie").size()

	if _in_round:
		if to_spawn > 0:
			_spawn_timer -= delta
			if _spawn_timer <= 0.0:
				_spawn_one()
				_spawn_timer = spawn_delay
		# round ends when no more to spawn and all dead
		if to_spawn <= 0 and alive <= 0:
			_in_round = false
			_between_rounds = 5.0
			var p = get_tree().get_first_node_in_group("player")
			if p and p.has_method("_show_msg"):
				p._show_msg("¡Ronda %d completada!" % round_num, 3.0)
	else:
		_between_rounds -= delta
		if _between_rounds <= 0.0:
			_start_next_round()

func _start_next_round():
	round_num += 1
	_in_round = true
	spawned_this_round = 0
	to_spawn = base_zombies + zombies_per_round * (round_num - 1)
	_spawn_timer = 0.5
	var p = get_tree().get_first_node_in_group("player")
	if p and p.has_method("_show_msg"):
		p._show_msg("RONDA %d - %d zombis" % [round_num, to_spawn], 3.0)

func _spawn_one():
	if to_spawn <= 0 or not _zombie_scene:
		to_spawn = 0
		return
	var z = _zombie_scene.instantiate()
	var idx = randi() % _spawn_points.size()
	z.global_position = _spawn_points[idx]
	# scale difficulty a bit by round
	z.hp = 80 + (round_num - 1) * 10
	z.speed = min(2.6 + (round_num - 1) * 0.08, 4.2)
	z.damage = 10 + int((round_num - 1) / 2)
	add_child(z)
	to_spawn -= 1
	spawned_this_round += 1

func _update_round_ui():
	var p = get_tree().get_first_node_in_group("player")
	if p and p.has_node("../UI/Status"):
		var status: Label = p.get_node("../UI/Status")
		var alive = get_tree().get_nodes_in_group("zombie").size()
		status.text = "Vida: %d/%d | Puntos: %d | Bajas: %d | Ronda: %d | Zombis: %d" % [p.health, p.max_health, p.points, p.kills, round_num, alive]
'''
mg.write_text(mcode, encoding='utf-8', newline='\n')
print("ok")
