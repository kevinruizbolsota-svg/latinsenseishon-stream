from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\GodotFPS-Zombies-Template\player\player.tscn")
t = p.read_text(encoding='utf-8')
# nocturnal body
t = t.replace('albedo_color = Color(0.2, 0.25, 0.3, 1)\nroughness = 0.8', 'albedo_color = Color(0.12, 0.14, 0.18, 1)\nroughness = 0.85')
# add Gewehr as slung prop in CuerpoVisible (3rd person)
if 'gewehr_41_w_low-poly.glb' not in t:
    t = t.replace('[ext_resource type="Texture2D" path="res://textures_hd/cara_personaje.jpg" id="22_face"]',
                  '[ext_resource type="Texture2D" path="res://textures_hd/cara_personaje.jpg" id="22_face"]\n[ext_resource type="PackedScene" path="res://colwar_assets/armas/gewehr_41_w_low-poly.glb" id="23_gewehr"]')
    marker = '[node name="CameraPivot" type="Node3D"'
    insert = '''[node name="ArmaEspalda" parent="CuerpoVisible" instance=ExtResource("23_gewehr")]
transform = Transform3D(0, -0.15, -0.989, 0.989, 0.022, -0.003, 0.022, -0.988, 0.15, -0.18, 1.15, 0.12)

'''
    t = t.replace(marker, insert + marker)
p.write_text(t, encoding='utf-8')
print('ok')
