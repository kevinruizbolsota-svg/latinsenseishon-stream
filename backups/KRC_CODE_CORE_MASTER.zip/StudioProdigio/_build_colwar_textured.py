﻿import os
root = r"C:\Users\kevin\Documents\GodotFPS-Zombies-Template"
out = os.path.join(root, "colwar", "COLWAR_main.tscn")

scene = r'''[gd_scene load_steps=22 format=3]

[ext_resource type="Script" path="res://common/managers/input_manager.gd" id="1"]
[ext_resource type="Script" path="res://colwar/colwar_main.gd" id="2"]
[ext_resource type="PackedScene" path="res://player/player.tscn" id="3"]
[ext_resource type="PackedScene" path="res://common/hud/gameplay_hud.tscn" id="4"]
[ext_resource type="PackedScene" path="res://common/spawner/spawner.tscn" id="5"]
[ext_resource type="PackedScene" path="res://enemies/undead.tscn" id="6"]
[ext_resource type="Script" path="res://common/managers/round_manager.gd" id="7"]
[ext_resource type="Texture2D" path="res://textures_hd/dry_river_pebbles_diff_4k.jpg" id="8"]
[ext_resource type="Texture2D" path="res://textures_hd/patterned_cobblestone_02_diff_4k.jpg" id="9"]
[ext_resource type="Texture2D" path="res://textures_hd/pavement_02_diff_4k.jpg" id="10"]

[sub_resource type="ProceduralSkyMaterial" id="SkyMat"]
sky_top_color = Color(0.05, 0.09, 0.18, 1)
sky_horizon_color = Color(0.18, 0.22, 0.34, 1)
ground_bottom_color = Color(0.04, 0.06, 0.05, 1)
ground_horizon_color = Color(0.14, 0.17, 0.18, 1)

[sub_resource type="Sky" id="Sky1"]
sky_material = SubResource("SkyMat")

[sub_resource type="Environment" id="EnvNoche"]
background_mode = 2
sky = SubResource("Sky1")
ambient_light_source = 2
ambient_light_color = Color(0.5, 0.58, 0.72, 1)
ambient_light_energy = 1.4
tonemap_mode = 3
tonemap_exposure = 1.15
ssao_enabled = false
glow_enabled = true
glow_levels/2 = 0.4
glow_intensity = 0.35
glow_strength = 0.9
glow_bloom = 0.03
fog_enabled = true
fog_light_color = Color(0.18, 0.22, 0.34, 1)
fog_light_energy = 1.0
fog_density = 0.006
fog_aerial_perspective = 0.45
fog_sky_affect = 0.35
volumetric_fog_enabled = false
adjustment_enabled = true
adjustment_brightness = 1.08
adjustment_contrast = 1.06
adjustment_saturation = 0.95

[sub_resource type="NavigationMesh" id="Nav1"]
geometry_parsed_geometry_type = 1
geometry_source_geometry_mode = 1
cell_size = 0.3
cell_height = 0.2
agent_height = 1.8
agent_radius = 0.45
agent_max_climb = 0.45
agent_max_slope = 46.0

[sub_resource type="StandardMaterial3D" id="MatSuelo"]
albedo_texture = ExtResource("8")
uv1_scale = Vector3(18, 18, 1)
roughness = 1.0

[sub_resource type="StandardMaterial3D" id="MatCamino"]
albedo_texture = ExtResource("9")
uv1_scale = Vector3(6, 12, 1)
roughness = 0.95

[sub_resource type="StandardMaterial3D" id="MatPlaza"]
albedo_texture = ExtResource("10")
uv1_scale = Vector3(4, 4, 1)
roughness = 0.9

[sub_resource type="StandardMaterial3D" id="MatMadera"]
albedo_color = Color(0.36, 0.26, 0.15, 1)
roughness = 0.9

[sub_resource type="StandardMaterial3D" id="MatMaderaOscura"]
albedo_color = Color(0.22, 0.16, 0.1, 1)
roughness = 0.94

[sub_resource type="StandardMaterial3D" id="MatPiedra"]
albedo_color = Color(0.38, 0.38, 0.36, 1)
roughness = 0.96

[sub_resource type="StandardMaterial3D" id="MatMuro"]
albedo_color = Color(0.28, 0.3, 0.28, 1)
roughness = 0.98

[node name="COLWAR_Main" type="Node3D"]
script = ExtResource("2")

[node name="InputManager" type="Node" parent="."]
script = ExtResource("1")

[node name="RoundManager" type="Node" parent="."]
script = ExtResource("7")

[node name="WorldEnvironment" type="WorldEnvironment" parent="."]
environment = SubResource("EnvNoche")

[node name="Luna" type="DirectionalLight3D" parent="."]
transform = Transform3D(0.939693, -0.17101, 0.296198, 0, 0.866025, 0.5, -0.34202, -0.469846, 0.813798, 0, 60, 0)
light_color = Color(0.82, 0.89, 1, 1)
light_energy = 1.8
light_indirect_energy = 0.35
shadow_enabled = false

[node name="Relleno" type="DirectionalLight3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 0.35, 0.93675, 0, -0.93675, 0.35, 0, 25, 0)
light_color = Color(0.62, 0.68, 0.85, 1)
light_energy = 0.55
shadow_enabled = false

[node name="SolBajo" type="DirectionalLight3D" parent="."]
transform = Transform3D(0.866025, 0.25, -0.433013, 0, 0.866025, 0.5, 0.5, -0.433013, 0.75, 0, 18, 0)
light_color = Color(0.55, 0.6, 0.75, 1)
light_energy = 0.35
shadow_enabled = false

[node name="Player" parent="." instance=ExtResource("3")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.5, 8)

[node name="HUD" type="CanvasLayer" parent="."]

[node name="Control" parent="HUD" instance=ExtResource("4")]

[node name="NavigationRegion3D" type="NavigationRegion3D" parent="."]
navigation_mesh = SubResource("Nav1")

[node name="Suelo" type="CSGBox3D" parent="NavigationRegion3D"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -1, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(220, 2, 220)
material = SubResource("MatSuelo")

[node name="Zona" type="Node3D" parent="NavigationRegion3D"]

[node name="Plaza" type="CSGBox3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.03, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(16, 0.1, 14)
material = SubResource("MatPlaza")

[node name="CaminoN" type="CSGBox3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.03, -16)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(4.2, 0.1, 20)
material = SubResource("MatCamino")

[node name="CaminoS" type="CSGBox3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.03, 16)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(4.2, 0.1, 18)
material = SubResource("MatCamino")

[node name="CaminoE" type="CSGBox3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 16, 0.03, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(18, 0.1, 4)
material = SubResource("MatCamino")

[node name="CaminoO" type="CSGBox3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -16, 0.03, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(18, 0.1, 4)
material = SubResource("MatCamino")

[node name="RefugioA" type="Node3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -6, 0, -3)

[node name="Base" type="CSGBox3D" parent="NavigationRegion3D/Zona/RefugioA"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.4, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(4.5, 2.8, 3.8)
material = SubResource("MatMadera")

[node name="Techo" type="CSGBox3D" parent="NavigationRegion3D/Zona/RefugioA"]
transform = Transform3D(1, 0, 0, 0, 0.866025, -0.5, 0, 0.5, 0.866025, 0, 3.1, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(5.0, 0.25, 4.4)
material = SubResource("MatMaderaOscura")

[node name="RefugioB" type="Node3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(0.965926, 0, 0.258819, 0, 1, 0, -0.258819, 0, 0.965926, 6.2, 0, -3.5)

[node name="Base" type="CSGBox3D" parent="NavigationRegion3D/Zona/RefugioB"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.35, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(4.0, 2.7, 3.5)
material = SubResource("MatMadera")

[node name="Techo" type="CSGBox3D" parent="NavigationRegion3D/Zona/RefugioB"]
transform = Transform3D(1, 0, 0, 0, 0.866025, -0.5, 0, 0.5, 0.866025, 0, 3.0, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(4.6, 0.22, 4.0)
material = SubResource("MatMaderaOscura")

[node name="RefugioC" type="Node3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(0, 0, 1, 0, 1, 0, -1, 0, 0, -3, 0, 5.5)

[node name="Base" type="CSGBox3D" parent="NavigationRegion3D/Zona/RefugioC"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.25, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(3.4, 2.5, 3.0)
material = SubResource("MatMadera")

[node name="Techo" type="CSGBox3D" parent="NavigationRegion3D/Zona/RefugioC"]
transform = Transform3D(1, 0, 0, 0, 0.866025, -0.5, 0, 0.5, 0.866025, 0, 2.8, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(4.0, 0.2, 3.6)
material = SubResource("MatMaderaOscura")

[node name="Barricada1" type="CSGBox3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 2.5, 0.6, 6.5)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector2(2.6, 0.5) if False else Vector3(2.6, 1.2, 0.5)
material = SubResource("MatMaderaOscura")

[node name="Barricada2" type="CSGBox3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(0, 0, 1, 0, 1, 0, -1, 0, 0, 7.2, 0.6, 3.5)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(2.4, 1.2, 0.5)
material = SubResource("MatMaderaOscura")

[node name="Muro" type="CSGBox3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -7.5, 0.8, 4.5)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(5.0, 1.6, 0.6)
material = SubResource("MatPiedra")

[node name="Borde1" type="CSGBox3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.0, -28)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(40, 2.0, 1.0)
material = SubResource("MatMuro")

[node name="Borde2" type="CSGBox3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.0, 28)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(40, 2.0, 1.0)
material = SubResource("MatMuro")

[node name="Borde3" type="CSGBox3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -28, 1.0, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(1.0, 2.0, 40)
material = SubResource("MatMuro")

[node name="Borde4" type="CSGBox3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 28, 1.0, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(1.0, 2.0, 40)
material = SubResource("MatMuro")

[node name="LuzCentro" type="OmniLight3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 5.5, 0)
light_color = Color(1, 0.96, 0.84, 1)
light_energy = 2.0
omni_range = 38.0
omni_attenuation = 1.05
shadow_enabled = false

[node name="LuzFogata" type="OmniLight3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1.3, -1)
light_color = Color(1, 0.58, 0.22, 1)
light_energy = 2.2
omni_range = 22.0
omni_attenuation = 1.15
shadow_enabled = false

[node name="LuzN" type="OmniLight3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 4.0, -14)
light_color = Color(1, 0.95, 0.86, 1)
light_energy = 1.4
omni_range = 20.0
omni_attenuation = 1.2
shadow_enabled = false

[node name="LuzE" type="OmniLight3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 14, 4.0, 0)
light_color = Color(1, 0.95, 0.86, 1)
light_energy = 1.3
omni_range = 18.0
omni_attenuation = 1.2
shadow_enabled = false

[node name="LuzO" type="OmniLight3D" parent="NavigationRegion3D/Zona"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -14, 4.0, 0)
light_color = Color(1, 0.95, 0.86, 1)
light_energy = 1.3
omni_range = 18.0
omni_attenuation = 1.2
shadow_enabled = false

[node name="Enemies" type="Node3D" parent="."]

[node name="SpawnerN1" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 3, 0.5, -22)
item = ExtResource("6")
spawn_time = 2.6
max_items = 2

[node name="SpawnerN2" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -10, 0.5, -18)
item = ExtResource("6")
spawn_time = 3.0
max_items = 2

[node name="SpawnerE" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 22, 0.5, 2)
item = ExtResource("6")
spawn_time = 3.2
max_items = 2

[node name="SpawnerO" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -22, 0.5, 4)
item = ExtResource("6")
spawn_time = 3.6
max_items = 2
'''
open(out, 'w', encoding='utf-8', newline='\n').write(scene)
print('ok')
