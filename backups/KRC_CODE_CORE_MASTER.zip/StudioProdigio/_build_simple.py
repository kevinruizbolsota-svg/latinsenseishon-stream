﻿import os
root = r"C:\Users\kevin\Documents\GodotFPS-Zombies-Template"
out = os.path.join(root, "colwar", "COLWAR_simple.tscn")

scene = r'''[gd_scene load_steps=14 format=3]

[ext_resource type="Script" path="res://common/managers/input_manager.gd" id="1"]
[ext_resource type="Script" path="res://colwar/colwar_main.gd" id="2"]
[ext_resource type="PackedScene" path="res://player/player.tscn" id="3"]
[ext_resource type="PackedScene" path="res://common/hud/gameplay_hud.tscn" id="4"]
[ext_resource type="PackedScene" path="res://common/spawner/spawner.tscn" id="5"]
[ext_resource type="PackedScene" path="res://enemies/undead.tscn" id="6"]
[ext_resource type="Script" path="res://common/managers/round_manager.gd" id="7"]
[ext_resource type="PackedScene" path="res://colwar/forest.glb" id="8"]

[sub_resource type="ProceduralSkyMaterial" id="SkyMat"]
sky_top_color = Color(0.07, 0.12, 0.22, 1)
sky_horizon_color = Color(0.22, 0.28, 0.4, 1)
ground_bottom_color = Color(0.05, 0.08, 0.06, 1)
ground_horizon_color = Color(0.16, 0.2, 0.2, 1)

[sub_resource type="Sky" id="Sky1"]
sky_material = SubResource("SkyMat")

[sub_resource type="Environment" id="Env1"]
background_mode = 2
sky = SubResource("Sky1")
ambient_light_source = 2
ambient_light_color = Color(0.55, 0.62, 0.78, 1)
ambient_light_energy = 1.6
tonemap_mode = 3
tonemap_exposure = 1.15
ssao_enabled = false
glow_enabled = false
fog_enabled = true
fog_light_color = Color(0.2, 0.25, 0.38, 1)
fog_light_energy = 1.0
fog_density = 0.005
volumetric_fog_enabled = false

[sub_resource type="NavigationMesh" id="Nav1"]
geometry_parsed_geometry_type = 1
geometry_source_geometry_mode = 1
cell_size = 0.35
cell_height = 0.2
agent_height = 1.8
agent_radius = 0.45
agent_max_climb = 0.5
agent_max_slope = 50.0

[sub_resource type="StandardMaterial3D" id="MatSuelo"]
albedo_color = Color(0.22, 0.28, 0.18, 1)
roughness = 1.0

[node name="COLWAR_Simple" type="Node3D"]
script = ExtResource("2")

[node name="InputManager" type="Node" parent="."]
script = ExtResource("1")

[node name="RoundManager" type="Node" parent="."]
script = ExtResource("7")

[node name="WorldEnvironment" type="WorldEnvironment" parent="."]
environment = SubResource("Env1")

[node name="Sol" type="DirectionalLight3D" parent="."]
transform = Transform3D(0.866025, -0.353553, 0.353553, 0, 0.707107, 0.707107, -0.5, -0.612372, 0.612372, 0, 80, 0)
light_color = Color(0.85, 0.9, 1, 1)
light_energy = 2.0
shadow_enabled = false

[node name="Relleno" type="DirectionalLight3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 0.3, 0.953939, 0, -0.953939, 0.3, 0, 30, 0)
light_color = Color(0.65, 0.72, 0.9, 1)
light_energy = 0.6
shadow_enabled = false

[node name="Player" parent="." instance=ExtResource("3")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 2.0, 0)

[node name="HUD" type="CanvasLayer" parent="."]

[node name="Control" parent="HUD" instance=ExtResource("4")]

[node name="NavigationRegion3D" type="NavigationRegion3D" parent="."]
navigation_mesh = SubResource("Nav1")

[node name="SueloColision" type="CSGBox3D" parent="NavigationRegion3D"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -1, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(500, 2, 500)
material = SubResource("MatSuelo")

[node name="Bosque" parent="NavigationRegion3D" instance=ExtResource("8")]

[node name="Enemies" type="Node3D" parent="."]

[node name="Spawner1" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 18, 1.0, 0)
item = ExtResource("6")
spawn_time = 3.0
max_items = 2

[node name="Spawner2" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -18, 1.0, 0)
item = ExtResource("6")
spawn_time = 3.2
max_items = 2

[node name="Spawner3" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.0, 18)
item = ExtResource("6")
spawn_time = 3.4
max_items = 2

[node name="Spawner4" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.0, -18)
item = ExtResource("6")
spawn_time = 3.6
max_items = 2

[node name="Spawner5" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 14, 1.0, 14)
item = ExtResource("6")
spawn_time = 4.0
max_items = 1

[node name="Spawner6" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -14, 1.0, -14)
item = ExtResource("6")
spawn_time = 4.2
max_items = 1
'''
open(out, 'w', encoding='utf-8', newline='\n').write(scene)
print('ok')
