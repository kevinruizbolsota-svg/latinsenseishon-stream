﻿"""
CENTINELA INTELIGENTE 24/7 — LATINSENSEISHON
Supervisa Kick & Twitch vía API cada vez que se ejecuta,
analiza estado, sincroniza cartelera/título y reanima automáticamente.
"""
import subprocess, json, sys, os, time, urllib.request, urllib.error
from pathlib import Path
from datetime import datetime

STUDIO       = Path(r"C:\Users\kevin\StudioProdigio")
DESKTOP_LOG  = Path(r"C:\Users\kevin\Desktop\REGISTRO_CENTINELA_LATINSENSEISHON.txt")
PYTHON       = Path(r"C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe")
TO_PLAY      = STUDIO / "dbz_to_play"
PLAYED       = STUDIO / "dbz_played"
TITLES_FILE  = STUDIO / "titulos_programacion.json"
TICKER_FILE  = STUDIO / "TICKER_TEXTO.txt"
STATE_FILE   = STUDIO / "dbz_stream_state.json"

def log_bitacora(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        with open(DESKTOP_LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass

def consultar_api_kick():
    url = "https://kick.com/api/v1/channels/los-calle-tv"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 LATINSENSEISHON/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            live = data.get("livestream") is not None
            title = data.get("livestream", {}).get("session_title", "Sin Título") if live else "Apagado"
            viewers = data.get("livestream", {}).get("viewer_count", 0) if live else 0
            return live, title, viewers
    except Exception as e:
        return None, str(e), 0

def verificar_ffmpeg_local():
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-Command", "Get-Process -Name ffmpeg -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id"],
            capture_output=True, text=True, timeout=5
        )
        pids = [int(p.strip()) for p in r.stdout.splitlines() if p.strip().isdigit()]
        return len(pids) > 0, pids
    except Exception:
        return False, []

def sincronizar_cartelera():
    try:
        titles_map = json.loads(TITLES_FILE.read_text(encoding="utf-8-sig")) if TITLES_FILE.exists() else {}
        en_cola = sorted([f.name for f in TO_PLAY.glob("*.mp4") if not f.name.startswith("_")])
        if en_cola:
            curr_file = en_cola[0]
            next_file = en_cola[1] if len(en_cola) > 1 else "Saga Siguiente"
            curr_title = titles_map.get(curr_file, {}).get("kick_title", curr_file.replace(".mp4", "")).split("|")[0].replace("🔥 [24/7 SHONEN] ", "").strip()
            next_title = titles_map.get(next_file, {}).get("kick_title", next_file.replace(".mp4", "")).split("|")[0].replace("🔥 [24/7 SHONEN] ", "").strip()
            
            ticker = (
                f"🎉 ¡Bienvenido a LOS CALLE TV — LATINSENSEISHON!  •  "
                f"📺 AHORA EN VIVO: {curr_title}  •  "
                f"⏳ PRÓXIMAMENTE: {next_title}  •  "
                f"✨ ¡Gracias por revivir nuestra infancia en los barrios junto a nosotros! 🏘️"
            )
            TICKER_FILE.write_text(ticker, encoding="utf-8")
            return curr_title, next_title
    except Exception as e:
        log_bitacora(f"⚠️ Cartelera: {e}")
    return "Saga de Dragon Ball Z", "Saga de Cell"

def reanimar_directo():
    log_bitacora("🚨 CENTINELA: Canal Kick detectado APAGADO o sin emisión. Disparando motor de transmisión...")
    try:
        cmd = [
            "powershell", "-NoProfile", "-Command",
            f"Start-Process -FilePath '{PYTHON}' -ArgumentList '-u stream_eterno.py' -WorkingDirectory '{STUDIO}'"
        ]
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10)
        time.sleep(3)
        vivos, pids = verificar_ffmpeg_local()
        if vivos:
            log_bitacora(f"🚀 REANIMACIÓN EXITOSA: Directo transmitiendo de nuevo. PIDs: {pids}")
        else:
            log_bitacora("⚠️ Reanimación disparada, esperando establecimiento de enlace RTMP...")
    except Exception as e:
        log_bitacora(f"❌ Error al reanimar: {e}")

def auditar():
    curr_saga, prox_saga = sincronizar_cartelera()
    local_live, pids = verificar_ffmpeg_local()
    kick_live, kick_title, viewers = consultar_api_kick()

    # Si local está muerto o Kick reporta apagado
    if not local_live:
        log_bitacora(f"🔍 AUDITORÍA: Proceso FFmpeg local NO encontrado. Estado Kick API: {kick_live}")
        reanimar_directo()
    else:
        log_bitacora(f"🟢 ESTADO ÓPTIMO: FFmpeg transmitiendo (PIDs: {pids}). Al aire: '{curr_saga}'. Kick API: Live={kick_live} ({viewers} viewers).")

if __name__ == "__main__":
    auditar()
