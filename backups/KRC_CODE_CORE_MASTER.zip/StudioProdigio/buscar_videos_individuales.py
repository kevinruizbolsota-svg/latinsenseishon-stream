import sys, json, time
sys.path.insert(0, r"C:\Users\kevin\StudioProdigio")
import yt_dlp

# Test individual video search (not playlist)
series_to_test = [
    "El Chavo del 8 capitulo completo español",
    "Dragon Ball Z episodio completo español latino",
    "Los Simpsons episodio completo español",
    "Bob Esponja episodio completo español",
    "Naruto capitulo completo español latino",
]

working_videos = {}

for query in series_to_test:
    try:
        opts = {"extract_flat": True, "quiet": True, "default_search": "ytsearch5"}
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(f"ytsearch3:{query}", download=False)
            entries = info.get("entries", [])
            videos = []
            for e in entries:
                vid_id = e.get("id", "")
                title = e.get("title", "")
                if vid_id and "playlist" not in (e.get("url") or "").lower():
                    videos.append({"id": vid_id, "title": title})
                    print(f"  FOUND: {title[:60]} (id: {vid_id})")
            if videos:
                working_videos[query] = videos[:3]
            time.sleep(2)
    except Exception as e:
        print(f"  ERROR: {query}: {str(e)[:80]}")

print(f"\nTotal series with videos: {len(working_videos)}")
# Save working videos
import json
with open(r"C:\Users\kevin\StudioProdigio\videos_encontrados.json", "w", encoding="utf-8") as f:
    json.dump(working_videos, f, ensure_ascii=False, indent=2)
print("Saved to videos_encontrados.json")
