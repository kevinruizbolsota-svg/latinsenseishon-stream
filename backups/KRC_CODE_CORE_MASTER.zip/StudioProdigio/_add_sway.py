﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\player.gd")
t = p.read_text(encoding="utf-8")

# add bob/sway vars
old = r'''var _flash_timer := 0.0
var _hitmarker_timer := 0.0
var _recoil := 0.0'''
new = r'''var _flash_timer := 0.0
var _hitmarker_timer := 0.0
var _recoil := 0.0
var _bob_t := 0.0
var _sway_target := Vector2.ZERO
var _sway_cur := Vector2.ZERO'''
if old in t: t = t.replace(old, new)

# in unhandled_input, track mouse for sway
old_ui_input = r'''	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * mouse_sensitivity)
		camera.rotate_x(-event.relative.y * mouse_sensitivity)
		camera.rotation.x = clamp(camera.rotation.x, -1.45, 1.45)'''
new_ui_input = r'''	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * mouse_sensitivity)
		camera.rotate_x(-event.relative.y * mouse_sensitivity)
		camera.rotation.x = clamp(camera.rotation.x, -1.45, 1.45)
		_sway_target.x = clamp(-event.relative.x * 0.0008, -0.04, 0.04)
		_sway_target.y = clamp(-event.relative.y * 0.0006, -0.03, 0.03)'''
if old_ui_input in t: t = t.replace(old_ui_input, new_ui_input)

# in physics process, apply bob and sway to weapon holder
old_move_block = r'''	move_and_slide()

	# shoot'''
new_move_block = r'''	move_and_slide()

	# weapon bob/sway
	_sway_target = _sway_target.lerp(Vector2.ZERO, delta * 5.0)
	_sway_cur = _sway_cur.lerp(_sway_target, delta * 10.0)
	var moving = dir.length() > 0.1 and is_on_floor()
	if moving:
		_bob_t += delta * 10.0
	else:
		_bob_t += delta * 2.0
	var bob_y = sin(_bob_t) * (0.012 if moving else 0.003)
	var bob_x = cos(_bob_t * 0.5) * (0.008 if moving else 0.002)
	if weapon_holder:
		weapon_holder.position = Vector3(0.25 + bob_x + _sway_cur.x, -0.25 + bob_y + _sway_cur.y, -0.55)
		weapon_holder.rotation.z = lerp(weapon_holder.rotation.z, _sway_cur.x * 2.0, delta * 8.0)

	# shoot'''
if old_move_block in t: t = t.replace(old_move_block, new_move_block)

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
