﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\player.gd")
t = p.read_text(encoding="utf-8")

# health regen vars
if 'var _regen_timer := 0.0' not in t:
    t = t.replace('var _hitmarker_timer := 0.0', 'var _hitmarker_timer := 0.0\nvar _regen_timer := 0.0\nvar _time_since_hit := 0.0')

# track time since hit and regen
old_flash = r'''	if hit_flash and hit_flash.color.a > 0.0:
		hit_flash.color.a = max(hit_flash.color.a - delta * 1.5, 0.0)'''
new_flash = r'''	if hit_flash and hit_flash.color.a > 0.0:
		hit_flash.color.a = max(hit_flash.color.a - delta * 1.5, 0.0)
	_time_since_hit += delta
	if health < max_health and health > 0 and _time_since_hit > 5.0:
		_regen_timer += delta
		if _regen_timer >= 1.0:
			health = min(health + 5, max_health)
			_regen_timer = 0.0'''
if old_flash in t:
    t = t.replace(old_flash, new_flash)

# reset on damage
old_dmg_time = r'''	health = max(health - amount, 0)
	_show_msg("¡Te golpearon! -%d" % amount)
	if sfx_hurt: sfx_hurt.play()'''
new_dmg_time = r'''	health = max(health - amount, 0)
	_time_since_hit = 0.0
	_regen_timer = 0.0
	_show_msg("¡Te golpearon! -%d" % amount)
	if sfx_hurt: sfx_hurt.play()'''
if old_dmg_time in t:
    t = t.replace(old_dmg_time, new_dmg_time)

# points for building barricades
old_build = r'''	if near_b and Input.is_action_pressed("interact"):
		near_b.player_try_build(delta)'''
new_build = r'''	if near_b and Input.is_action_pressed("interact"):
		if near_b.player_try_build(delta):
			points += 5
			_update_ui()'''
if old_build in t:
    t = t.replace(old_build, new_build)

# weapon switch feedback: small sound/click via sfx_empty pitched or just feel - use sfx_reload play quietly? simpler: set shoot_cd small and no sound clutter; we can play sfx_empty with high pitch
old_set = r'''	current_weapon = idx
	shoot_cd = 0.0
	reload_cd = 0.0
	_update_weapon_visual()
	_update_ui()'''
new_set = r'''	current_weapon = idx
	shoot_cd = 0.15
	reload_cd = 0.0
	if sfx_empty:
		sfx_empty.pitch_scale = 1.6
		sfx_empty.play()
		sfx_empty.pitch_scale = 1.0
	_update_weapon_visual()
	_update_ui()'''
if old_set in t:
    t = t.replace(old_set, new_set)

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
