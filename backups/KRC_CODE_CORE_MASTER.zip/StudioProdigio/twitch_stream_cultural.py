"""
TWITCH BROADCAST 24/7 - TRANSMISOR CULTURAL RETRO CON BOTONES VISIBLES, TICKER SUPERIOR Y LOGO ABAJO DER
========================================================================================================
Transmite en exclusiva a Twitch la señal cultural (Superman 1941, Nezha 1979, Joyas Culturales):
- Marco Retro CRT 'Los Calle TV' ajustado para dejar 100% VISIBLES LOS BOTONES INFERIORES y la frase grabada.
- Marquesina Ticker dinámica en la parte SUPERIOR PEGADA AL TECHO (Y=6, font 32px Arial Bold).
- Emblema Neón Colombia Guitar en la ESQUINA INFERIOR DERECHA adentro del televisor.
- Título dinámico registrado en log y preparado para sincronización automática con API.
"""

import subprocess, time, json, shutil, sys, os, threading, ctypes
from pathlib import Path
from datetime import datetime

STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
FFMPEG = Path(r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe")
LOGO   = STUDIO / "assets" / "logo" / "Koyal-Photoroom.png"
FRAME  = STUDIO / "assets" / "frame" / "marco_tv_retro.png"
TICKER = STUDIO / "TICKER_TEXTO.txt"
BUMPER = STUDIO / "assets" / "transicion_cortinilla_90s.mp4"
ADS_DIR= STUDIO / "PUBLICIDAD_KRC"
CFG_FILE = STUDIO / "stream_config.json"
TITLES_FILE = STUDIO / "titulos_programacion.json"

TWITCH_TO_PLAY = STUDIO / "twitch_to_play"
TWITCH_PLAYED  = STUDIO / "twitch_played"
STATE_FILE     = STUDIO / "twitch_stream_state.json"
LOG_FILE       = STUDIO / "twitch_stream.log"

for d in [TWITCH_TO_PLAY, TWITCH_PLAYED, ADS_DIR]:
    d.mkdir(parents=True, exist_ok=True)

def prevent_sleep():
    try:
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | 0x00000001 | 0x00000040)
    except Exception:
        pass

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass

def load_twitch_key():
    try:
        cfg = json.loads(CFG_FILE.read_text(encoding="utf-8-sig"))
        return cfg.get("twitch", {}).get("key", "").strip()
    except Exception:
        return ""

def load_titles_map():
    try:
        if TITLES_FILE.exists():
            return json.loads(TITLES_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}

def load_state():
    try:
        if STATE_FILE.exists():
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}

def save_state(file_name, pos):
    try:
        STATE_FILE.write_text(json.dumps({"file": file_name, "pos": max(0, float(pos)), "updated": datetime.now().isoformat()}, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass

def build_twitch_cmd(video_path, stream_key, seek=0):
    cmd = [str(FFMPEG)]
    if seek > 0:
        cmd += ["-ss", str(seek)]
    cmd += ["-thread_queue_size", "1024", "-re", "-i", str(video_path)]

    frame_ok = FRAME.exists()
    logo_ok = LOGO.exists()

    if frame_ok:
        cmd += ["-thread_queue_size", "256", "-i", str(FRAME)]
    if logo_ok:
        cmd += ["-thread_queue_size", "256", "-i", str(LOGO)]

    ticker_file_esc = str(TICKER).replace("\\", "/").replace(":", "\\:")
    font_file_esc = "C\\:/Windows/Fonts/arialbd.ttf"

    filter_parts = [
        "[0:v]scale=1427:828:force_original_aspect_ratio=decrease[v_scaled];",
        "color=c=black:s=1427x828[v_pad_base];",
        "[v_pad_base][v_scaled]overlay=(W-w)/2:(H-h)/2[v_in];",
        "color=c=black:s=1920x1080[base];",
        "[base][v_in]overlay=239:51[screen_comp];",
        "[screen_comp][1:v]overlay=0:0[tv_comp];",
        f"[tv_comp]drawtext=textfile='{ticker_file_esc}':reload=1:fontfile='{font_file_esc}':fontsize=32:fontcolor=white:box=1:boxcolor=0x000000@0.85:boxborderw=8:y=6:x=w-mod(max(t*130\\,0)\\,w+text_w)[with_text];",
        "[2:v]scale=105:-1[logo_sc];",
        "[with_text][logo_sc]overlay=1540:755[outv]"
    ]
    vfilter = " ".join(filter_parts)

    cmd += ["-filter_complex", vfilter, "-map", "[outv]", "-map", "0:a:0?"]
    rtmp_url = f"rtmp://live.twitch.tv/app/{stream_key}"
    cmd += [
        "-af", "volume=2.2,alimiter=limit=0.95",
        "-c:v", "libx264", "-preset", "veryfast", "-b:v", "3500k",
        "-maxrate", "3500k", "-bufsize", "7000k", "-pix_fmt", "yuv420p",
        "-g", "60", "-c:a", "aac", "-b:a", "160k", "-ar", "44100", "-ac", "2",
        "-f", "flv", rtmp_url
    ]
    return cmd

def emit_file_direct(video_path, stream_key):
    rtmp_url = f"rtmp://live.twitch.tv/app/{stream_key}"
    cmd = [
        str(FFMPEG), "-re", "-i", str(video_path),
        "-c:v", "libx264", "-preset", "veryfast", "-b:v", "3500k",
        "-maxrate", "3500k", "-bufsize", "7000k", "-pix_fmt", "yuv420p",
        "-g", "60", "-c:a", "aac", "-b:a", "160k", "-ar", "44100", "-ac", "2",
        "-f", "flv", rtmp_url
    ]
    p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    p.wait()

def emit_commercial_break(stream_key):
    ads = sorted([p for p in ADS_DIR.glob("*.mp4") if p.stat().st_size > 100_000])
    if not ads:
        return
    log("📺 ENTRAN TANDAS COMERCIALES Y CORTINILLAS KRC...")
    if BUMPER.exists():
        emit_file_direct(BUMPER, stream_key)
    for ad in ads:
        log(f"📣 EMITIENDO PROPAGANDA KRC: {ad.name}")
        emit_file_direct(ad, stream_key)
    if BUMPER.exists():
        emit_file_direct(BUMPER, stream_key)

def stream_loop():
    prevent_sleep()
    log("=== INICIANDO SEÑAL TWITCH 24/7 RETRO BROADCAST CON BOTONES VISIBLES Y TICKER TOP ===")

    while True:
        prevent_sleep()
        key = load_twitch_key()
        if not key:
            log("Falta clave de Twitch en stream_config.json. Reintentando en 20s...")
            time.sleep(20)
            continue

        videos = sorted([p for p in TWITCH_TO_PLAY.glob("*.mp4") if p.stat().st_size > 1_000_000])
        if not videos:
            played = sorted([p for p in TWITCH_PLAYED.glob("*.mp4") if p.stat().st_size > 1_000_000])
            if played:
                log("Ciclo de videos completado. Reiniciando lista y lanzando tandas...")
                emit_commercial_break(key)
                for p in played:
                    shutil.move(str(p), str(TWITCH_TO_PLAY / p.name))
                continue
            time.sleep(10)
            continue

        current = videos[0]
        st = load_state()
        seek = st.get("pos", 0) if st.get("file") == current.name else 0

        # Cargar metadatos / título para el capítulo actual
        titles_map = load_titles_map()
        meta = titles_map.get(current.name, {})
        title_str = meta.get("twitch_title", f"🔴 [24/7 RETRO] {current.stem} | Los Calle TV")

        log(f"🎬 TITULO SINCRONIZADO: {title_str}")
        log(f"🔴 AL AIRE EN TWITCH (MARCO RETRO TV CON BOTONES): {current.name} (Reanudando en {int(seek)}s)")
        cmd = build_twitch_cmd(current, key, seek)

        try:
            p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            p.wait()
            if p.returncode == 0:
                log(f"Capítulo finalizado: {current.name}")
                shutil.move(str(current), str(TWITCH_PLAYED / current.name))
                STATE_FILE.unlink(missing_ok=True)
                emit_commercial_break(key)
            else:
                log("Micro-corte detectado en Twitch. Reanudando transmisión en 2s...")
                time.sleep(2)
        except Exception as e:
            log(f"Error en stream Twitch: {e}")
            time.sleep(2)

if __name__ == "__main__":
    stream_loop()
