"""
STREAM ETERNO 24/7 - SUPERVISOR INDESTRUCTIBLE
- Mantiene activo dbz_stream_all.py pase lo que pase.
- Si FFmpeg o Python caen por corte de red o error de socket, los revive en 2 segundos.
- Muestra telemetría clara en pantalla para que Kevin vea que está 100% activo.
"""
import subprocess, time, sys, os, ctypes
from pathlib import Path
from datetime import datetime

STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
PYTHON = Path(r"C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe")
SCRIPT = STUDIO / "dbz_stream_all.py"
LOG_FILE = STUDIO / "dbz_stream.log"
CONFIG_FILE = STUDIO / "stream_config.json"

def prevent_sleep():
    """Bloquea que Windows suspenda el PC, el disco o la red mientras transmite."""
    ES_CONTINUOUS = 0x80000000
    ES_SYSTEM_REQUIRED = 0x00000001
    ES_AWAYMODE_REQUIRED = 0x00000040
    try:
        ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_AWAYMODE_REQUIRED)
    except Exception:
        pass

def banner():
    pass

def toggle_cloud_stream(accion):
    try:
        import urllib.request, json
        url = "https://latinsenseishon-stream.onrender.com/api/control/toggle_stream"
        data = json.dumps({"accion": accion}).encode("utf-8")
        req = urllib.request.Request(url, data=data, method="POST", headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=6)
    except Exception:
        pass

def main():
    os.environ["PYTHONIOENCODING"] = "utf-8"
    prevent_sleep()
    # 1. Al iniciar el PC: Apaga la emision en Render para liberar el canal RTMP
    toggle_cloud_stream("stop")
    inicio_global = datetime.now()

    while True:
        prevent_sleep()

        try:
            # Ejecutar el script principal de stream en modo silencioso
            p = subprocess.Popen(
                [str(PYTHON), "-u", str(SCRIPT)],
                cwd=str(STUDIO)
            )
            p.wait()
        except KeyboardInterrupt:
            # 2. Al apagar o cerrar en el PC: Enciende la nube en Render 24/7 automáticamente
            toggle_cloud_stream("start")
            try:
                subprocess.run(["taskkill", "/IM", "ffmpeg.exe", "/F"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except:
                pass
            break
        except Exception as e:
            # Solo alarmas críticas urgentes
            print(f"[ALERTA CRITICA STREAM]: {e}", flush=True)

        time.sleep(2)

if __name__ == "__main__":
    main()

