﻿"""
DBZ STREAM 24/7 - Reproduce Dragon Ball Z en secuencia a todas las plataformas activas.
- Toma el siguiente episodio de dbz_to_play (orden alfabético)
- Lo transmite a Twitch, Kick y Facebook (según stream_config.json)
- Al terminar, mueve el episodio a dbz_played y sigue con el siguiente
- Si no hay episodios, recicla dbz_played -> dbz_to_play
"""
import subprocess, time, json, shutil, sys, os, threading, re, ctypes
from pathlib import Path
from datetime import datetime

def prevent_sleep():
    try:
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | 0x00000001 | 0x00000040)
    except Exception:
        pass

STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
FFMPEG = Path(r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe")
CONFIG_FILE = STUDIO / "stream_config.json"
LOG_FILE = STUDIO / "dbz_stream.log"
STATE_PATH = STUDIO / "dbz_stream_state.json"

DBZ_TO_PLAY = STUDIO / "dbz_to_play"
DBZ_PLAYED = STUDIO / "dbz_played"
DBZ_CURRENT = STUDIO / "dbz_current"

RTMP_BASES = {
    "kick": "rtmps://fa723fc1b171.global-contribute.live-video.net:443/app/",
    "twitch": "rtmp://live.twitch.tv/app/",
    "facebook": "rtmps://live-api-s.facebook.com:443/rtmp/",
    "youtube": "rtmp://a.rtmp.youtube.com/live2/",
}

for d in [DBZ_TO_PLAY, DBZ_PLAYED, DBZ_CURRENT]:
    d.mkdir(parents=True, exist_ok=True)


def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    # Solo mostrar en pantalla si es un error critico o falla grave
    if "ERROR" in msg.upper() or "CRITIC" in msg.upper() or "FALLO" in msg.upper():
        print(line, flush=True)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def load_config():
    if not CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8-sig"))
    except Exception as e:
        log(f"Error leyendo config: {e}")
        return {}


def load_state():
    try:
        if STATE_PATH.exists():
            return json.loads(STATE_PATH.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def save_state(file_name, pos_seconds):
    try:
        STATE_PATH.write_text(json.dumps({"file": file_name, "pos": max(0, float(pos_seconds)), "updated": datetime.now().isoformat()}, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


def clear_state(file_name=None):
    try:
        if not STATE_PATH.exists():
            return
        if file_name is None:
            STATE_PATH.unlink(missing_ok=True)
            return
        st = load_state()
        if st.get("file") == file_name:
            STATE_PATH.unlink(missing_ok=True)
    except Exception:
        pass


def active_platforms(config):
    plats = []
    for name, cfg in config.items():
        if not isinstance(cfg, dict):
            continue
        key = str(cfg.get("key", "")).strip()
        if cfg.get("activo") and key and "PEGA" not in key.upper() and name in RTMP_BASES:
            plats.append((name, RTMP_BASES[name] + key))
    return plats


import re

UPLOAD_DIR = STUDIO / "CAPITULOS_ESTRENADOS_PARA_SUBIR"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

def _valid_chapter(p):
    n = p.name.lower()
    if n.endswith('.part') or n.startswith('_ignore'): return False
    if '.temp.' in n or n.endswith('.temp.mp4') or n.endswith('.ytdl'): return False
    if re.search(r'\.f\d+\.', n): return False  # yt-dlp fragments like .f397.mp4
    try:
        return p.is_file() and p.stat().st_size > 5_000_000
    except Exception:
        return False

def _has_pending_downloads():
    try:
        for p in DBZ_TO_PLAY.iterdir():
            n = p.name.lower()
            if n.endswith('.part') or '.temp.' in n or n.endswith('.temp.mp4') or n.endswith('.ytdl') or re.search(r'\.f\d+\.(mp4|m4a|webm)$', n):
                return True
    except Exception:
        pass
    return False

def next_chapter():
    chapters = sorted([p for p in DBZ_TO_PLAY.glob("*.mp4") if _valid_chapter(p)])
    if not chapters:
        if _has_pending_downloads():
            log("Esperando capítulo en descarga/merge (cola llenándose)...")
            return None
        played = sorted([p for p in DBZ_PLAYED.glob("*.mp4") if _valid_chapter(p)])
        if played:
            log("Lista terminada. Reiniciando ciclo (dbz_played -> dbz_to_play)...")
            for f in played:
                try:
                    shutil.move(str(f), str(DBZ_TO_PLAY / f.name))
                except Exception as e:
                    log(f"Error moviendo {f.name}: {e}")
            chapters = sorted([p for p in DBZ_TO_PLAY.glob("*.mp4") if _valid_chapter(p)])
    return chapters[0] if chapters else None


def move_to_played(chapter):
    dest = DBZ_PLAYED / chapter.name
    # copia a carpeta visible para subir a otras plataformas (capitulos ya estrenados)
    try:
        up = UPLOAD_DIR / chapter.name
        if not up.exists():
            shutil.copy2(str(chapter), str(up))
            log(f"Copiado para subir: {up.name}")
    except Exception as e:
        log(f"No se pudo copiar a carpeta de subida: {e}")
    try:
        if dest.exists():
            dest.unlink()
        shutil.move(str(chapter), str(dest))
        log(f"Movido a dbz_played: {chapter.name}")
    except Exception as e:
        log(f"Error moviendo a played: {e}")


LOGO = STUDIO / "assets" / "logo" / "Koyal-Photoroom.png"
FRAME = STUDIO / "assets" / "frame" / "marco_tv_retro.png"
TICKER_BG = STUDIO / "assets" / "frame" / "ticker_dorado.png"
TICKER = STUDIO / "TICKER_TEXTO.txt"
HEADER = STUDIO / "HEADER_TEXTO.txt"
ADS_DIR = STUDIO / "PUBLICIDAD_KRC"
BUMPER = STUDIO / "assets" / "transicion_cortinilla_90s.mp4"

def has_audio(path):
    ffprobe = FFMPEG.parent / "ffprobe.exe"
    try:
        r = subprocess.run(
            [str(ffprobe), "-v", "error", "-select_streams", "a", "-show_entries", "stream=codec_type", "-of", "csv=p=0", str(path)],
            capture_output=True, text=True, timeout=15
        )
        return "audio" in (r.stdout or "").lower()
    except Exception:
        return False

def _parse_out_seconds(progress_path):
    try:
        txt = Path(progress_path).read_text(encoding="utf-8", errors="ignore")
        m = None
        for mm in re.finditer(r'out_time_us=(\d+)', txt):
            m = mm
        if m:
            return int(m.group(1)) / 1_000_000.0
        for mm in re.finditer(r'out_time_ms=(\d+)', txt):
            m = mm
        if m:
            v = int(m.group(1))
            return (v / 1_000_000.0) if v > 10_000_000 else (v / 1000.0)
        for mm in re.finditer(r'out_time=(\d+):(\d+):(\d+(?:\.\d+)?)', txt):
            m = mm
        if m:
            h, mi, s = int(m.group(1)), int(m.group(2)), float(m.group(3))
            return h * 3600 + mi * 60 + s
    except Exception:
        pass
    return None


def build_ffmpeg_cmd(chapter, outputs, seek_seconds=0, progress_path=None):
    # Overlays TV Retro, Ticker Marquesina, Logo KRC Neón, boost audio; soporta reanudar desde seek_seconds.
    logo_ok = LOGO.exists()
    frame_ok = FRAME.exists()
    audio_ok = has_audio(chapter)
    cmd = [str(FFMPEG)]
    if seek_seconds and seek_seconds > 0:
        cmd += ["-ss", str(max(0, float(seek_seconds)))]
    cmd += ["-thread_queue_size", "1024", "-threads", "4", "-re", "-i", str(chapter)]
    if progress_path:
        cmd += ["-progress", str(progress_path), "-nostats"]
    ticker_bg_ok = TICKER_BG.exists()
    
    # Inputs adicionales: Logo y Barra Dorada Real
    next_input_idx = 1
    logo_input_idx = None
    bg_input_idx = None

    if logo_ok:
        cmd += ["-thread_queue_size", "256", "-i", str(LOGO)]
        logo_input_idx = next_input_idx
        next_input_idx += 1

    if ticker_bg_ok:
        cmd += ["-thread_queue_size", "256", "-i", str(TICKER_BG)]
        bg_input_idx = next_input_idx
        next_input_idx += 1

    if not audio_ok:
        cmd += ["-f", "lavfi", "-i", "anullsrc=channel_layout=stereo:sample_rate=44100"]

    ticker_file_esc = str(TICKER).replace("\\", "/").replace(":", "\\:")
    font_file_esc = "C\\:/Windows/Fonts/arialbd.ttf"

    # Construccion limpia del pipeline de filtros:
    # 1. Video a pantalla completa escalado + mejora de imagen
    filters = [
        "[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2:black,"
        "hqdn3d=2:1:3:3,unsharp=3:3:0.5:3:3:0.0,"
        "eq=contrast=1.08:brightness=0.04:saturation=1.22[base_v]"
    ]
    current_stream = "[base_v]"

    # 2. Poner la barra dorada al piso (y = 1080 - 56 = 1024)
    if bg_input_idx is not None:
        filters.append(f"[{bg_input_idx}:v]scale=1920:56[bar_dorada]")
        filters.append(f"{current_stream}[bar_dorada]overlay=0:1024[with_bar]")
        current_stream = "[with_bar]"
    else:
        # Fallback si no estuviera la imagen
        filters.append(f"{current_stream}drawbox=x=0:y=1024:w=1920:h=56:color=0xD4A017@1:t=fill[with_bar]")
        current_stream = "[with_bar]"

    # 3. Texto negro elegante y nitido pasando centrado por la barra dorada
    # Alto barra: 1024 a 1080. Texto fontsize 28 centrado verticalmente: y=1036
    filters.append(
        f"{current_stream}drawtext=textfile='{ticker_file_esc}':reload=1:fontfile='{font_file_esc}':"
        f"fontsize=28:fontcolor=0x111111:shadowcolor=0xFFFFFF@0.35:shadowx=1:shadowy=1:"
        f"y=1036:x=w-mod(max(t*150\\,0)\\,w+text_w)[with_txt]"
    )
    current_stream = "[with_txt]"

    # 4. Logo en la esquina inferior derecha por ENCIMA de la barra dorada sin tocarse (separado y flotando)
    # Barra empieza en y=1024. Logo de 120px de alto -> colocado en y = 1024 - 120 - 15 = 889 (espacio perfecto)
    if logo_input_idx is not None:
        filters.append(f"[{logo_input_idx}:v]scale=120:-1,format=rgba,colorchannelmixer=aa=0.68[logo_subtle]")
        filters.append(f"{current_stream}[logo_subtle]overlay=W-w-35:30[v]")
    else:
        filters.append(f"{current_stream}null[v]")

    cmd += ["-filter_complex", ";".join(filters), "-map", "[v]"]

    if audio_ok:
        cmd += ["-map", "0:a:0?", "-af", "volume=2.8,alimiter=limit=0.95"]
    else:
        aidx = "2:a:0" if logo_ok else "1:a:0"
        cmd += ["-map", aidx, "-af", "volume=2.8,alimiter=limit=0.95"]

    cmd += [
        "-c:v", "libx264", "-preset", "veryfast", "-tune", "film", "-b:v", "4500k",
        "-maxrate", "4500k", "-bufsize", "9000k", "-pix_fmt", "yuv420p",
        "-g", "60", "-keyint_min", "60", "-sc_threshold", "0",
        "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-ac", "2",
        "-use_fifo", "1",
        "-fifo_options", "attempt_recovery=1:recover_any_error=1:drop_pkts_on_overflow=1",
        "-f", "tee",
    ]
    tee_parts = []
    for _, url in outputs:
        safe = url.replace("'", "'\\''")
        tee_parts.append(f"[f=flv:onfail=ignore]{safe}")
    cmd.append("|".join(tee_parts))
    return cmd


def _chapter_title(chapter_name):
    try:
        p = STUDIO / "dbz_titulos.json"
        if p.exists():
            data = json.loads(p.read_text(encoding="utf-8-sig"))
            return data.get(chapter_name) or data.get("_default") or ""
    except Exception:
        pass
    return ""


def stream_chapter(chapter, outputs):
    # Reanuda desde donde quedó este capítulo (si aplica)
    title = _chapter_title(chapter.name)
    if title:
        try:
            (STUDIO / "TITULO_DIRECTO_ACTUAL.txt").write_text(title, encoding="utf-8")
        except Exception:
            pass
        log(f"Titulo directo: {title}")
        try:
            tok_path = STUDIO / "twitch_oauth_tokens.json"
            if tok_path.exists():
                tok_data = json.loads(tok_path.read_text(encoding="utf-8"))
                t_token = tok_data.get("access_token")
                t_cid = tok_data.get("client_id")
                t_uid = tok_data.get("user_id")
                if t_token and t_cid and t_uid:
                    import urllib.request
                    t_url = f"https://api.twitch.tv/helix/channels?broadcaster_id={t_uid}"
                    t_body = json.dumps({"title": title}).encode("utf-8")
                    t_req = urllib.request.Request(t_url, data=t_body, method="PATCH", headers={
                        "Authorization": f"Bearer {t_token}",
                        "Client-Id": t_cid,
                        "Content-Type": "application/json"
                    })
                    with urllib.request.urlopen(t_req, timeout=5) as t_resp:
                        log(f"Titulo sincronizado en Twitch Helix API (Status {t_resp.status})")
        except Exception as e_tok:
            log(f"Aviso sync titulo Twitch: {e_tok}")
    st = load_state()
    seek = 0.0
    if st.get("file") == chapter.name:
        try:
            seek = max(0.0, float(st.get("pos", 0)) - 5.0)
        except Exception:
            seek = 0.0
    if seek > 1:
        m, s = divmod(int(seek), 60); h, m = divmod(m, 60)
        log(f"Reanudando {chapter.name} desde {h:02d}:{m:02d}:{s:02d}")
    else:
        log(f"=== Reproduciendo: {chapter.name} ===")
    log(f"Plataformas: {', '.join(p for p,_ in outputs)}")
    progress_path = STUDIO / "dbz_progress.txt"
    try:
        if progress_path.exists():
            progress_path.unlink()
    except Exception:
        pass
    cmd = build_ffmpeg_cmd(chapter, outputs, seek_seconds=seek, progress_path=progress_path)
    errlog = STUDIO / "dbz_ffmpeg_err.log"
    stop_evt = threading.Event()
    pos = {"v": seek}

    def watch_progress():
        while not stop_evt.is_set():
            out = _parse_out_seconds(progress_path)
            if out is not None:
                pos["v"] = seek + out
                save_state(chapter.name, pos["v"])
            stop_evt.wait(5)

    t = threading.Thread(target=watch_progress, daemon=True)
    try:
        with errlog.open("w", encoding="utf-8", errors="ignore") as ef:
            proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=ef)
            log(f"FFmpeg iniciado (PID {proc.pid})")
            t.start()
            proc.wait()
        stop_evt.set()
        t.join(timeout=2)
        out = _parse_out_seconds(progress_path)
        if out is not None:
            pos["v"] = seek + out
            save_state(chapter.name, pos["v"])
        log(f"Capítulo terminado (exit {proc.returncode}): {chapter.name} (pos ~{int(pos['v'])}s)")
        dur = get_video_duration(chapter)
        if proc.returncode == 0 or (dur and pos["v"] >= dur - 5):
            log(f"Fin de capitulo alcanzado (pos {pos['v']}s / dur {dur}s)")
            clear_state(chapter.name)
            return True
        try:
            tail = errlog.read_text(encoding="utf-8", errors="ignore").splitlines()[-6:]
            for ln in tail:
                if ln.strip():
                    log(f"  ffmpeg: {ln.strip()[:220]}")
        except Exception:
            pass
        log(f"Posición guardada para reanudar: {int(pos['v'])}s")
        return False
    except Exception as e:
        stop_evt.set()
        log(f"Error en stream: {e}")
        save_state(chapter.name, pos["v"])
        return False


def get_video_duration(file_path):
    try:
        cmd = [
            "ffprobe", "-v", "error", "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1", str(file_path)
        ]
        res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=10)
        return float(res.stdout.strip())
    except Exception:
        return None

def main():
    prevent_sleep()
    log("=== DBZ STREAM 24/7 INICIADO (Dragon Ball Z - Serie Principal) ===")
    log(f"dbz_to_play: {len(list(DBZ_TO_PLAY.glob('*.mp4')))} | dbz_played: {len(list(DBZ_PLAYED.glob('*.mp4')))}")

    while True:
        prevent_sleep()
        config = load_config()
        outputs = active_platforms(config)
        if not outputs:
            log("No hay plataformas activas con key válida en stream_config.json. Reintentando en 30s...")
            time.sleep(30)
            continue

        chapter = next_chapter()
        if not chapter:
            log("No hay episodios en dbz_to_play ni dbz_played. Reintentando en 60s...")
            time.sleep(60)
            continue

        ok = stream_chapter(chapter, outputs)
        if ok:
            move_to_played(chapter)
        else:
            log("Reconectando transmisión en 2s (reanudando al instante)...")
            time.sleep(2)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        log("DBZ STREAM detenido por el usuario.")
        sys.exit(0)



