﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\player.gd")
t = p.read_text(encoding="utf-8")

# add sfx_step ref and footstep timer
if '@onready var sfx_kill' in t and '@onready var sfx_step' not in t:
    t = t.replace('@onready var sfx_kill: AudioStreamPlayer = $SfxKill',
                  '@onready var sfx_kill: AudioStreamPlayer = $SfxKill\n@onready var sfx_step: AudioStreamPlayer = $SfxStep')

if 'var _step_timer := 0.0' not in t:
    t = t.replace('var _recoil := 0.0\nvar _bob_t := 0.0',
                  'var _recoil := 0.0\nvar _step_timer := 0.0\nvar _bob_t := 0.0')

# footstep logic after move_and_slide/bob block - insert before shoot
old_shoot_block = r'''	# shoot
	if Input.is_action_pressed("shoot") and shoot_cd <= 0.0 and reload_cd <= 0.0:
		_shoot()'''
new_shoot_block = r'''	# footsteps
	var moving_fs = dir.length() > 0.1 and is_on_floor()
	if moving_fs:
		_step_timer -= delta
		if _step_timer <= 0.0:
			if sfx_step:
				sfx_step.pitch_scale = randf_range(0.92, 1.08)
				sfx_step.play()
			_step_timer = 0.42
	else:
		_step_timer = 0.1

	# shoot
	if Input.is_action_pressed("shoot") and shoot_cd <= 0.0 and reload_cd <= 0.0:
		_shoot()'''
if old_shoot_block in t:
    t = t.replace(old_shoot_block, new_shoot_block)

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
