import json, shutil
from pathlib import Path

STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
RAW = STUDIO / "dbz_latino_playlist_raw.tsv"
OUT = STUDIO / "dbz_to_play"
PLAYED = STUDIO / "dbz_played"
ARCHIVE = STUDIO / "dbz_archive_old"
MANIFEST = STUDIO / "dbz_latino_manifest.json"
PLAYLIST = "https://www.youtube.com/playlist?list=PLpbdLXz_BiMWzc9ApK9qjf20xK7d6DO7W"

# archive old
ARCHIVE.mkdir(exist_ok=True)
for d in [OUT, PLAYED]:
    if d.exists():
        for f in d.glob("*.mp4"):
            try: shutil.move(str(f), str(ARCHIVE / f.name))
            except Exception: pass
OUT.mkdir(exist_ok=True)
PLAYED.mkdir(parents=True, exist_ok=True)

def read_text_any(p):
    b = p.read_bytes()
    if b.startswith(b'\xff\xfe') or b.startswith(b'\xfe\xff') or b'\x00' in b[:200]:
        try: return b.decode('utf-16')
        except: return b.decode('utf-16', errors='ignore')
    return b.decode('utf-8', errors='ignore')

items = []
for line in read_text_any(RAW).splitlines():
    line = line.replace("\\t", "\t")
    parts = line.split("\t")
    if len(parts) < 4: continue
    idx_s, vid, dur_s, title = parts[0], parts[1], parts[2], "\t".join(parts[3:])
    try: idx = int(idx_s.strip())
    except: continue
    try: dur = int(float(dur_s.strip())) if dur_s.strip() not in ("NA","None","") else 0
    except: dur = 0
    items.append({"index": idx, "id": vid.strip(), "duration": dur, "title": title.strip()})

# Main long-form episodes only (>= 15 min), keep playlist order
main = [it for it in items if it["duration"] >= 900]
MANIFEST.write_text(json.dumps({"playlist": PLAYLIST, "main": main, "all_count": len(items)}, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"all={len(items)} main_long={len(main)}")
for it in main[:25]:
    m, s = divmod(it["duration"], 60); h, m = divmod(m, 60)
    ds = f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"
    print(f"{it['index']:02d} {it['id']} {ds:>8} {it['title'][:70]}")
