﻿import math, os
root = r"C:\Users\kevin\Documents\COLWAR_NUEVO"
out = os.path.join(root, "main.tscn")

def ry_tf(x,y,z,ry_deg=0):
    ry = math.radians(ry_deg)
    c = math.cos(ry); s = math.sin(ry)
    return f"Transform3D({c:.6f}, 0, {s:.6f}, 0, 1, 0, {-s:.6f}, 0, {c:.6f}, {x}, {y}, {z})"

def barricade_node(name, parent_path, x,y,z, ry_deg=0):
    tf = ry_tf(x,y,z,ry_deg)
    p = parent_path
    lines = []
    lines.append(f'[node name="{name}" type="Node3D" parent="{p}"]')
    lines.append(f'transform = {tf}')
    lines.append('script = ExtResource("3")')
    lines.append(f'[node name="Blocker" type="StaticBody3D" parent="{p}/{name}"]')
    lines.append(f'[node name="CollisionShape3D" type="CollisionShape3D" parent="{p}/{name}/Blocker"]')
    lines.append('shape = SubResource("BarricadeShape")')
    for i in range(1,7):
        by = 0.25 + (i-1)*0.28
        lines.append(f'[node name="Board{i}" type="CSGBox3D" parent="{p}/{name}"]')
        lines.append(f'transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, {by:.3f}, 0)')
        lines.append('size = Vector3(1.8, 0.18, 0.08)')
        lines.append('material = SubResource("MatMadera")')
    return "\n".join(lines)

def zombie_block(name, x,y,z, model_ext="5", scale="0.012"):
    return f'''[node name="{name}" type="CharacterBody3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, {x}, {y}, {z})
script = ExtResource("2")

[node name="CollisionShape3D" type="CollisionShape3D" parent="{name}"]
shape = SubResource("ZombieShape")

[node name="Cuerpo" type="CSGCylinder3D" parent="{name}"]
radius = 0.4
height = 1.5
material = SubResource("MatZombieFallback")

[node name="Cabeza" type="CSGSphere3D" parent="{name}"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.0, 0)
radius = 0.28
material = SubResource("MatZombieFallback")

[node name="Modelo" parent="{name}" instance=ExtResource("{model_ext}")]
transform = Transform3D({scale}, 0, 0, 0, {scale}, 0, 0, 0, {scale}, 0, -0.9, 0)
'''

# Barricades placed around a perimeter (guesses for military post) - user can adjust
barricades = [
    ("Barricada1", 0, 0.9, -8, 0),
    ("Barricada2", 0, 0.9, 8, 0),
    ("Barricada3", -10, 0.9, 0, 90),
    ("Barricada4", 10, 0.9, 0, 90),
    ("Barricada5", -7, 0.9, -6, 45),
    ("Barricada6", 7, 0.9, -6, -45),
    ("Barricada7", -7, 0.9, 6, -45),
    ("Barricada8", 7, 0.9, 6, 45),
]

zombies = []
pos = [(0,1.5,-18),(18,1.5,0),(0,1.5,18),(-18,1.5,0),(14,1.5,-14),(-14,1.5,-14),(14,1.5,14),(-14,1.5,14),(22,1.5,6),(-22,1.5,-6),(6,1.5,-22),(-6,1.5,22)]
for i,(x,y,z) in enumerate(pos,1):
    ext = "5" if i%2==1 else "10" # alternate demonio/dragon
    zombies.append(zombie_block(f"Zombie{i}", x,y,z, ext))

# ext resources: 1 player.gd,2 zombie.gd,3 barricade.gd,4 gewehr.glb,5 demonio,6 madera,7 tex_piso,8 tex_pared,9 tex_exterior,10 dragon,11 Military_Post.glb
# sub resources: SkyMat,Sky,Env,MatPiso,MatPared,MatTecho,MatMadera,MatExterior,MatZombieFallback,PlayerShape,ZombieShape,BarricadeShape = 12
load_steps = 11 + 12 + 1  # +1 for format counting style
scene = r'''[gd_scene load_steps=24 format=3]

[ext_resource type="Script" path="res://player.gd" id="1"]
[ext_resource type="Script" path="res://zombie.gd" id="2"]
[ext_resource type="Script" path="res://barricade.gd" id="3"]
[ext_resource type="PackedScene" path="res://gewehr.glb" id="4"]
[ext_resource type="PackedScene" path="res://demonio_pintado.glb" id="5"]
[ext_resource type="Texture2D" path="res://madera.jpg" id="6"]
[ext_resource type="Texture2D" path="res://tex_piso.png" id="7"]
[ext_resource type="Texture2D" path="res://tex_pared.png" id="8"]
[ext_resource type="Texture2D" path="res://tex_exterior.png" id="9"]
[ext_resource type="PackedScene" path="res://dragon_nemesis.glb" id="10"]
[ext_resource type="PackedScene" path="res://Military_Post.glb" id="11"]

[sub_resource type="ProceduralSkyMaterial" id="SkyMat"]
sky_top_color = Color(0.03, 0.05, 0.12, 1)
sky_horizon_color = Color(0.12, 0.16, 0.28, 1)
ground_bottom_color = Color(0.02, 0.03, 0.03, 1)
ground_horizon_color = Color(0.08, 0.1, 0.14, 1)

[sub_resource type="Sky" id="Sky1"]
sky_material = SubResource("SkyMat")

[sub_resource type="Environment" id="Env1"]
background_mode = 2
sky = SubResource("Sky1")
ambient_light_source = 2
ambient_light_color = Color(0.45, 0.52, 0.7, 1)
ambient_light_energy = 1.25
tonemap_mode = 2
tonemap_exposure = 1.1
glow_enabled = false
fog_enabled = true
fog_light_color = Color(0.14, 0.18, 0.3, 1)
fog_light_energy = 0.85
fog_density = 0.008
volumetric_fog_enabled = false

[sub_resource type="StandardMaterial3D" id="MatPiso"]
albedo_texture = ExtResource("7")
albedo_color = Color(0.55, 0.5, 0.45, 1)
uv1_scale = Vector3(6, 6, 1)
roughness = 0.9

[sub_resource type="StandardMaterial3D" id="MatPared"]
albedo_texture = ExtResource("8")
albedo_color = Color(0.6, 0.57, 0.52, 1)
uv1_scale = Vector3(4, 2, 1)
roughness = 0.85

[sub_resource type="StandardMaterial3D" id="MatTecho"]
albedo_texture = ExtResource("8")
albedo_color = Color(0.5, 0.48, 0.45, 1)
uv1_scale = Vector3(6, 6, 1)
roughness = 0.94

[sub_resource type="StandardMaterial3D" id="MatMadera"]
albedo_texture = ExtResource("6")
albedo_color = Color(0.7, 0.55, 0.35, 1)
uv1_scale = Vector3(2, 2, 1)
roughness = 0.82

[sub_resource type="StandardMaterial3D" id="MatExterior"]
albedo_texture = ExtResource("9")
albedo_color = Color(0.3, 0.35, 0.28, 1)
uv1_scale = Vector3(30, 30, 1)
roughness = 1.0

[sub_resource type="StandardMaterial3D" id="MatZombieFallback"]
albedo_color = Color(0.22, 0.38, 0.2, 1)
roughness = 0.9

[sub_resource type="CapsuleShape3D" id="PlayerShape"]
radius = 0.4
height = 1.8

[sub_resource type="CapsuleShape3D" id="ZombieShape"]
radius = 0.45
height = 1.8

[sub_resource type="BoxShape3D" id="BarricadeShape"]
size = Vector3(1.9, 2.0, 0.25)

[node name="Main" type="Node3D"]

[node name="WorldEnvironment" type="WorldEnvironment" parent="."]
environment = SubResource("Env1")

[node name="Luna" type="DirectionalLight3D" parent="."]
transform = Transform3D(0.939693, -0.17101, 0.296198, 0, 0.866025, 0.5, -0.34202, -0.469846, 0.813798, 0, 40, 0)
light_color = Color(0.74, 0.82, 1, 1)
light_energy = 0.7
shadow_enabled = false

[node name="Relleno" type="DirectionalLight3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 0.4, 0.916515, 0, -0.916515, 0.4, 0, 20, 0)
light_color = Color(0.5, 0.56, 0.72, 1)
light_energy = 0.3
shadow_enabled = false

[node name="LuzCentro" type="OmniLight3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 3.5, 0)
light_color = Color(1, 0.94, 0.8, 1)
light_energy = 1.8
omni_range = 22.0
omni_attenuation = 1.1
shadow_enabled = false

[node name="SueloExterior" type="CSGBox3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.5, 0)
use_collision = true
size = Vector3(220, 1, 220)
material = SubResource("MatExterior")

[node name="BaseMilitar" parent="." instance=ExtResource("11")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0)

[node name="PisoColision" type="CSGBox3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.02, 0)
use_collision = true
size = Vector3(40, 0.1, 40)
material = SubResource("MatPiso")

[node name="Barricadas" type="Node3D" parent="."]

''' + "\n".join([barricade_node(n,"Barricadas",x,y,z,ry) for (n,x,y,z,ry) in barricades]) + r'''

[node name="Player" type="CharacterBody3D" parent="." groups=["player"]]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.2, 0)
script = ExtResource("1")

[node name="CollisionShape3D" type="CollisionShape3D" parent="Player"]
shape = SubResource("PlayerShape")

[node name="Camera3D" type="Camera3D" parent="Player"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.6, 0)
current = true
fov = 75.0

[node name="RayCast3D" type="RayCast3D" parent="Player/Camera3D"]
target_position = Vector3(0, 0, -80)
enabled = true

[node name="WeaponHolder" type="Node3D" parent="Player/Camera3D"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0.25, -0.25, -0.55)

[node name="W1" type="Node3D" parent="Player/Camera3D/WeaponHolder"]

[node name="Modelo" parent="Player/Camera3D/WeaponHolder/W1" instance=ExtResource("4")]
transform = Transform3D(-1, 0, 0, 0, 1, 0, 0, 0, -1, 0, -0.05, 0.1)

[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.02, -0.15)
size = Vector3(0.08, 0.1, 0.55)
material = SubResource("MatTecho")

[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, -0.48)
size = Vector3(0.04, 0.04, 0.25)
material = SubResource("MatPared")

[node name="W2" type="Node3D" parent="Player/Camera3D/WeaponHolder"]
visible = false

[node name="Modelo" parent="Player/Camera3D/WeaponHolder/W2" instance=ExtResource("4")]
transform = Transform3D(-1, 0, 0, 0, 1, 0, 0, 0, -1, 0, -0.05, 0.1)

[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.02, -0.12)
size = Vector3(0.07, 0.09, 0.45)
material = SubResource("MatPiso")

[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, -0.4)
size = Vector3(0.035, 0.035, 0.22)
material = SubResource("MatPared")

[node name="W3" type="Node3D" parent="Player/Camera3D/WeaponHolder"]
visible = false

[node name="Modelo" parent="Player/Camera3D/WeaponHolder/W3" instance=ExtResource("4")]
transform = Transform3D(-1.1, 0, 0, 0, 1.1, 0, 0, 0, -1.1, 0, -0.06, 0.12)

[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.03, -0.18)
size = Vector3(0.09, 0.11, 0.6)
material = SubResource("MatMadera")

[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, -0.55)
size = Vector3(0.045, 0.045, 0.28)
material = SubResource("MatPared")

[node name="UI" type="CanvasLayer" parent="."]

[node name="Label" type="Label" parent="UI"]
offset_left = 16.0
offset_top = 14.0
offset_right = 1100.0
offset_bottom = 44.0
text = "COLWAR"

[node name="Hint" type="Label" parent="UI"]
offset_left = 16.0
offset_top = 44.0
offset_right = 900.0
offset_bottom = 74.0
text = ""

[node name="Mira" type="Label" parent="UI"]
anchors_preset = 8
anchor_left = 0.5
anchor_top = 0.5
anchor_right = 0.5
anchor_bottom = 0.5
offset_left = -10.0
offset_top = -12.0
offset_right = 10.0
offset_bottom = 12.0
text = "+"
horizontal_alignment = 1
vertical_alignment = 1

''' + "\n".join(zombies)

open(out, 'w', encoding='utf-8', newline='\n').write(scene)
print('ok')
