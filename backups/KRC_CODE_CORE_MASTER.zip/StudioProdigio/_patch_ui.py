﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.tscn")
t = p.read_text(encoding="utf-8")

# add ext_resource for main.gd and zombie_template later? I'll add main.gd as id 12
# bump load_steps and add ext_resource
t = t.replace('[gd_scene load_steps=24 format=3]', '[gd_scene load_steps=25 format=3]', 1)
t = t.replace('[ext_resource type="PackedScene" path="res://Military_Post.glb" id="11"]',
              '[ext_resource type="PackedScene" path="res://Military_Post.glb" id="11"]\n[ext_resource type="Script" path="res://main.gd" id="12"]')

# attach script to Main
t = t.replace('[node name="Main" type="Node3D"]', '[node name="Main" type="Node3D"]\nscript = ExtResource("12")')

# update UI labels
old_ui = r'''[node name="UI" type="CanvasLayer" parent="."]

[node name="Label" type="Label" parent="UI"]
offset_left = 16.0
offset_top = 14.0
offset_right = 1100.0
offset_bottom = 44.0
text = "COLWAR"

[node name="Hint" type="Label" parent="UI"]
offset_left = 16.0
offset_top = 44.0
offset_right = 900.0
offset_bottom = 74.0
text = ""'''
new_ui = r'''[node name="UI" type="CanvasLayer" parent="."]

[node name="Status" type="Label" parent="UI"]
offset_left = 16.0
offset_top = 10.0
offset_right = 900.0
offset_bottom = 36.0
text = "Vida: 100/100 | Puntos: 0 | Bajas: 0"

[node name="Label" type="Label" parent="UI"]
offset_left = 16.0
offset_top = 36.0
offset_right = 1100.0
offset_bottom = 62.0
text = "Arma"

[node name="Hint" type="Label" parent="UI"]
offset_left = 16.0
offset_top = 62.0
offset_right = 900.0
offset_bottom = 88.0
text = ""

[node name="Msg" type="Label" parent="UI"]
offset_left = 16.0
offset_top = 92.0
offset_right = 900.0
offset_bottom = 120.0
text = ""'''
t = t.replace(old_ui, new_ui)

p.write_text(t, encoding="utf-8", newline="\n")
print("ok")
