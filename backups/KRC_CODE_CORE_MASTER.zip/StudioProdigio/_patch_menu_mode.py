﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.tscn")
t = p.read_text(encoding="utf-8")

# MenuInicio always process
t = t.replace('[node name="MenuInicio" type="ColorRect" parent="UI"]',
              '[node name="MenuInicio" type="ColorRect" parent="UI"]\nprocess_mode = 3')
t = t.replace('[node name="Pausa" type="ColorRect" parent="UI"]\nvisible = false',
              '[node name="Pausa" type="ColorRect" parent="UI"]\nprocess_mode = 3\nvisible = false')

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
