﻿import re
from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.tscn")
t = p.read_text(encoding="utf-8")

# bump load_steps for 4 new ext_resources
t = re.sub(r'\[gd_scene load_steps=(\d+) format=3\]', lambda m: f'[gd_scene load_steps={int(m.group(1))+4} format=3]', t, count=1)

# add ext resources after id 6
old_ext = '[ext_resource type="Texture2D" path="res://madera.jpg" id="6"]'
new_ext = '''[ext_resource type="Texture2D" path="res://madera.jpg" id="6"]
[ext_resource type="Texture2D" path="res://tex_piso.png" id="7"]
[ext_resource type="Texture2D" path="res://tex_pared.png" id="8"]
[ext_resource type="Texture2D" path="res://tex_exterior.png" id="9"]
[ext_resource type="PackedScene" path="res://dragon_nemesis.glb" id="10"]'''
t = t.replace(old_ext, new_ext)

# MatPiso
t = t.replace('''[sub_resource type="StandardMaterial3D" id="MatPiso"]
albedo_color = Color(0.32, 0.27, 0.22, 1)
roughness = 0.92''',
'''[sub_resource type="StandardMaterial3D" id="MatPiso"]
albedo_texture = ExtResource("7")
uv1_scale = Vector3(4, 4, 1)
roughness = 0.9''')

# MatPared
t = t.replace('''[sub_resource type="StandardMaterial3D" id="MatPared"]
albedo_color = Color(0.42, 0.39, 0.34, 1)
roughness = 0.88''',
'''[sub_resource type="StandardMaterial3D" id="MatPared"]
albedo_texture = ExtResource("8")
uv1_scale = Vector3(3, 2, 1)
roughness = 0.85''')

# MatTecho - give it wall texture darker feel or keep simple but nicer
t = t.replace('''[sub_resource type="StandardMaterial3D" id="MatTecho"]
albedo_color = Color(0.24, 0.22, 0.2, 1)
roughness = 0.96''',
'''[sub_resource type="StandardMaterial3D" id="MatTecho"]
albedo_texture = ExtResource("8")
albedo_color = Color(0.7, 0.68, 0.64, 1)
uv1_scale = Vector3(4, 4, 1)
roughness = 0.94''')

# MatExterior
t = t.replace('''[sub_resource type="StandardMaterial3D" id="MatExterior"]
albedo_color = Color(0.1, 0.14, 0.09, 1)
roughness = 1.0''',
'''[sub_resource type="StandardMaterial3D" id="MatExterior"]
albedo_texture = ExtResource("9")
uv1_scale = Vector3(20, 20, 1)
roughness = 1.0''')

# Variety: make even-numbered zombies use dragon_nemesis (id 10) for visual variety
# Replace Modelo instances for Zombie2,4,6,8,10
for name in ["Zombie2","Zombie4","Zombie6","Zombie8","Zombie10"]:
    old = f'[node name="Modelo" parent="{name}" instance=ExtResource("5")]'
    # dragon model may have different scale; try similar small scale
    if old in t:
        t = t.replace(old, f'[node name="Modelo" parent="{name}" instance=ExtResource("10")]')

p.write_text(t, encoding="utf-8", newline="\n")
print("ok")
