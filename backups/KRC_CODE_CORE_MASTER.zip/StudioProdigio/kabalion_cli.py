import sys
import subprocess
from pathlib import Path

PYTHON = r"C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe"

def menu_kabalion():
    print("""
===================================================================
      ★ KABALION AI - CENTRO DE COMANDO & CREACIÓN TOTAL ★
                El Prodigio - Kevin Esteban Ruiz Calle
===================================================================
 [1] Hablar con la IA Kabalion (Estrategia, Guiones y Negocios)
 [2] Procesar carpeta: "Carpeta de videos para transformar y publicar"
 [3] Descargar capítulo nuevo de la serie (Chavo / Animé / Series)
 [4] Ver estado de almacenamiento y limpiar espacio
 [5] Salir
===================================================================
    """)
    opc = input("Kabalion > Elige una opción: ").strip()
    if opc == "1":
        print("\n[★] Conectando con Cerebro Kabalion en n8n...")
        import urllib.request, json
        while True:
            msg = input("\nKevin > ").strip()
            if msg.lower() in ["salir", "exit", "volver"]:
                break
            data = json.dumps({"action": "sendMessage", "sessionId": "kabalion-cli", "chatInput": msg}).encode('utf-8')
            req = urllib.request.Request("http://localhost:5678/webhook/628fb0bb-dfb0-404b-a30b-188c8c04f643/chat", data=data, headers={'Content-Type': 'application/json'})
            try:
                with urllib.request.urlopen(req) as resp:
                    res = json.loads(resp.read().decode())
                    print(f"\nKabalion AI > {res.get('output', 'Listo, mi rey.')}")
            except Exception as e:
                print(f"Error de conexión: {e}")
    elif opc == "2":
        print("\n[*] Procesando videos en la carpeta del Escritorio...")
        creador = Path(r"C:\Users\kevin\StudioProdigio\crear_obra_maestra.py")
        subprocess.run([PYTHON, str(creador)])
    elif opc == "4":
        print("\n📊 Análisis de Almacenamiento:")
        print(" - Carpeta Downloads/Ecosistema: ~179 GB")
        print(" - Carpeta Downloads/COD-Black Ops 2: ~45.4 GB")
        print(" 👉 Tienes más de 224 GB ocupados en Downloads.")

if __name__ == "__main__":
    menu_kabalion()
