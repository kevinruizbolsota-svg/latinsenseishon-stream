"""
KABALION TV - Pantalla de Mantenimiento
Genera un video de pantalla retro estilo años 80 para cuando no hay contenido
"""
import subprocess
from pathlib import Path

FFMPEG = Path(r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe")
OUT = Path(r"C:\Users\kevin\Desktop\KABALION TV\MANTENIMIENTO\pantalla_mantenimiento.mp4")

# Genera una pantalla de barras de color SMPTE estilo retro TV años 80
# con texto "KABALION TV - Volvemos pronto" y tono suave
filter_complex = (
    "smptehdbars=size=1280x720:rate=30[bars];"
    "[bars]drawtext=fontfile='C\\:/Windows/Fonts/arial.ttf':"
    "text='📺 KABALION TV':"
    "fontsize=72:fontcolor=white:x=(w-text_w)/2:y=h/2-80:"
    "shadowcolor=black:shadowx=3:shadowy=3,"
    "drawtext=fontfile='C\\:/Windows/Fonts/arial.ttf':"
    "text='Volvemos en un momento...':"
    "fontsize=38:fontcolor=yellow:x=(w-text_w)/2:y=h/2+10:"
    "shadowcolor=black:shadowx=2:shadowy=2,"
    "drawtext=fontfile='C\\:/Windows/Fonts/arial.ttf':"
    "text='La Esquina de los Calle & Remember Luxury':"
    "fontsize=24:fontcolor=white:x=(w-text_w)/2:y=h-80:"
    "alpha=0.8[v]"
)

cmd = [
    str(FFMPEG), "-y",
    "-f", "lavfi", "-i", "smptehdbars=size=1280x720:rate=30",
    "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=44100:amplitude=0.05",
    "-filter_complex", filter_complex,
    "-map", "[v]", "-map", "1:a",
    "-c:v", "libx264", "-preset", "fast", "-b:v", "1500k",
    "-c:a", "aac", "-b:a", "64k", "-ar", "44100",
    "-t", "300",  # 5 minutos, se pone en loop
    str(OUT)
]

result = subprocess.run(cmd, capture_output=True, text=True)
if OUT.exists():
    print(f"Pantalla de mantenimiento OK: {OUT} ({OUT.stat().st_size//1024//1024}MB)")
else:
    print("Error:", result.stderr[-500:])
