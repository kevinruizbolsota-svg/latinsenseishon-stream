"""
DESCARGADOR RAPIDO - 30 CAPITULOS (3 de cada serie)
Descarga videos y los organiza en carpetas por serie
Sin normalizacion (para ahorrar tiempo)
"""
import sys, json, time, os
from pathlib import Path
sys.path.insert(0, r"C:\Users\kevin\StudioProdigio")

STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
EPISODES_DIR = STUDIO / "tv_episodes"
ORG_FILE = STUDIO / "video_organization.json"

EPISODES_DIR.mkdir(parents=True, exist_ok=True)

def download_video(video_id, title, out_dir):
    """Descarga un video de YouTube (formato 480p para velocidad)."""
    mp4 = out_dir / f"{video_id}.mp4"
    if mp4.exists() and mp4.stat().st_size > 100_000:
        print(f"  [SKIP] Ya existe: {title[:50]}")
        return mp4
    import yt_dlp
    opts = {
        "format": "best[height<=480]/best",
        "outtmpl": str(out_dir / f"{video_id}.%(ext)s"),
        "merge_output_format": "mp4",
        "quiet": True,
        "no_warnings": True,
    }
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.download([f"https://www.youtube.com/watch?v={video_id}"])
        if mp4.exists():
            size_mb = mp4.stat().st_size / (1024*1024)
            print(f"  [OK] {title[:50]} ({size_mb:.1f}MB)")
            return mp4
    except Exception as e:
        print(f"  [ERR] {title[:50]}: {str(e)[:60]}")
    return None

def main():
    videos_file = STUDIO / "videos_encontrados.json"
    if not videos_file.exists():
        print("ERROR: videos_encontrados.json no encontrado")
        return

    all_videos = json.loads(videos_file.read_text(encoding="utf-8"))

    # Select 10 series (3 videos each = 30 chapters)
    series_list = list(all_videos.keys())[:10]
    print(f"\n{'='*60}")
    print(f"  DESCARGA RAPIDA - 30 CAPITULOS")
    print(f"  {len(series_list)} series x 3 videos = {len(series_list)*3} capitulos")
    print(f"{'='*60}\n")

    total_downloaded = 0
    organization = {"total_series": len(series_list), "total_chapters": 0, "series": {}}

    for i, serie_name in enumerate(series_list, 1):
        videos = all_videos[serie_name][:3]
        safe_name = serie_name.replace(" ", "_").replace("/", "_").replace("ñ", "n")
        ep_dir = EPISODES_DIR / safe_name
        ep_dir.mkdir(parents=True, exist_ok=True)

        print(f"\n[{i}/{len(series_list)}] {serie_name} ({len(videos)} videos)")

        downloaded = []
        for j, vid in enumerate(videos, 1):
            vid_id = vid["id"]
            title = vid["title"]
            print(f"  [{j}/3] {title[:50]}")
            raw = download_video(vid_id, title, ep_dir)
            if raw and raw.exists():
                total_downloaded += 1
                downloaded.append({"id": vid_id, "title": title, "file": raw.name, "size": raw.stat().st_size})

        organization["series"][serie_name] = {
            "folder": safe_name,
            "chapters": downloaded,
            "count": len(downloaded)
        }
        organization["total_chapters"] = total_downloaded

        # Save progress after each series
        ORG_FILE.write_text(json.dumps(organization, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"\n{'='*60}")
    print(f"  RESUMEN FINAL")
    print(f"  Series: {len(series_list)}")
    print(f"  Capitulos descargados: {total_downloaded}/{len(series_list)*3}")
    print(f"  Carpeta: {EPISODES_DIR}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
