import os
root = r"C:\Users\kevin\Documents\GodotFPS-Zombies-Template"
out = os.path.join(root, "colwar", "COLWAR_main.tscn")

# Curated, coherent main scene: forest anchor + campamento CSG + atmosphere, perf-balanced
# (showcase keeps all assets: COLWAR_todo_showcase.tscn)
scene = r'''[gd_scene load_steps=22 format=3]

[ext_resource type="Script" path="res://common/managers/input_manager.gd" id="1"]
[ext_resource type="Script" path="res://colwar/colwar_main.gd" id="2"]
[ext_resource type="PackedScene" path="res://player/player.tscn" id="3"]
[ext_resource type="PackedScene" path="res://common/hud/gameplay_hud.tscn" id="4"]
[ext_resource type="PackedScene" path="res://common/spawner/spawner.tscn" id="5"]
[ext_resource type="PackedScene" path="res://enemies/undead.tscn" id="6"]
[ext_resource type="Script" path="res://common/managers/round_manager.gd" id="7"]
[ext_resource type="PackedScene" path="res://colwar_assets/mapas_bosque/forest.glb" id="8"]
[ext_resource type="PackedScene" path="res://colwar_assets/mapas_bosque/terrain_retextured.glb" id="9"]
[ext_resource type="PackedScene" path="res://colwar_assets/personajes_criaturas/demonio_pintado.glb" id="10"]
[ext_resource type="PackedScene" path="res://colwar_assets/personajes_criaturas/razghul__the_crimson_hornlord.glb" id="11"]
[ext_resource type="PackedScene" path="res://colwar_assets/props_vehiculos/2022_husqavarna_fs_450.glb" id="12"]
[ext_resource type="PackedScene" path="res://colwar_assets/props_vehiculos/2022_arash_imperium.glb" id="13"]

[sub_resource type="ProceduralSkyMaterial" id="SkyMat"]
sky_top_color = Color(0.005, 0.01, 0.03, 1)
sky_horizon_color = Color(0.03, 0.045, 0.085, 1)
ground_bottom_color = Color(0.002, 0.008, 0.004, 1)
ground_horizon_color = Color(0.02, 0.03, 0.045, 1)
sun_angle_max = 0.0

[sub_resource type="Sky" id="Sky1"]
sky_material = SubResource("SkyMat")

[sub_resource type="Environment" id="EnvNoche"]
background_mode = 2
sky = SubResource("Sky1")
ambient_light_source = 2
ambient_light_color = Color(0.09, 0.13, 0.22, 1)
ambient_light_energy = 0.24
reflected_light_source = 1
tonemap_mode = 3
tonemap_exposure = 0.92
tonemap_white = 1.0
ssao_enabled = true
ssao_radius = 1.0
ssao_intensity = 1.8
ssao_light_affect = 0.25
ssil_enabled = false
glow_enabled = true
glow_levels/1 = 0.2
glow_levels/2 = 0.55
glow_levels/3 = 0.45
glow_levels/4 = 0.2
glow_intensity = 0.5
glow_strength = 0.95
glow_bloom = 0.06
glow_hdr_threshold = 1.1
fog_enabled = true
fog_light_color = Color(0.055, 0.075, 0.13, 1)
fog_light_energy = 0.6
fog_density = 0.016
fog_aerial_perspective = 0.55
fog_sky_affect = 0.65
volumetric_fog_enabled = false
adjustment_enabled = true
adjustment_brightness = 1.0
adjustment_contrast = 1.1
adjustment_saturation = 0.88

[sub_resource type="NavigationMesh" id="Nav1"]
geometry_parsed_geometry_type = 1
geometry_source_geometry_mode = 1
cell_size = 0.25
cell_height = 0.2
agent_height = 1.8
agent_radius = 0.45
agent_max_climb = 0.45
agent_max_slope = 45.0

[sub_resource type="BoxShape3D" id="FloorShape"]
size = Vector3(600, 2, 600)

[sub_resource type="StandardMaterial3D" id="MatMadera"]
albedo_color = Color(0.22, 0.16, 0.1, 1)
roughness = 0.92
metallic = 0.0

[sub_resource type="StandardMaterial3D" id="MatMaderaOscura"]
albedo_color = Color(0.14, 0.1, 0.07, 1)
roughness = 0.95

[sub_resource type="StandardMaterial3D" id="MatPiedra"]
albedo_color = Color(0.28, 0.27, 0.25, 1)
roughness = 0.98

[sub_resource type="StandardMaterial3D" id="MatTierra"]
albedo_color = Color(0.16, 0.14, 0.1, 1)
roughness = 1.0

[node name="COLWAR_Main" type="Node3D"]
script = ExtResource("2")

[node name="InputManager" type="Node" parent="."]
script = ExtResource("1")

[node name="RoundManager" type="Node" parent="."]
script = ExtResource("7")

[node name="WorldEnvironment" type="WorldEnvironment" parent="."]
environment = SubResource("EnvNoche")

[node name="Luna" type="DirectionalLight3D" parent="."]
transform = Transform3D(0.939693, -0.17101, 0.296198, 0, 0.866025, 0.5, -0.34202, -0.469846, 0.813798, 0, 60, 0)
light_color = Color(0.58, 0.7, 1, 1)
light_energy = 0.5
light_indirect_energy = 0.35
shadow_enabled = true
shadow_bias = 0.035
shadow_normal_bias = 1.1
shadow_blur = 1.6
directional_shadow_mode = 1
directional_shadow_split_1 = 0.08
directional_shadow_max_distance = 160.0

[node name="ContraluzSuave" type="DirectionalLight3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 0.25, 0.968246, 0, -0.968246, 0.25, 0, 20, 0)
light_color = Color(0.35, 0.42, 0.65, 1)
light_energy = 0.08
shadow_enabled = false

[node name="Player" parent="." instance=ExtResource("3")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 2.5, 12)

[node name="HUD" type="CanvasLayer" parent="."]

[node name="Control" parent="HUD" instance=ExtResource("4")]

[node name="NavigationRegion3D" type="NavigationRegion3D" parent="."]
navigation_mesh = SubResource("Nav1")

[node name="SueloColisionBase" type="StaticBody3D" parent="NavigationRegion3D"]
collision_layer = 5
collision_mask = 5
[node name="CollisionShape3D" type="CollisionShape3D" parent="NavigationRegion3D/SueloColisionBase"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -1, 0)
shape = SubResource("FloorShape")

[node name="Mundo" type="Node3D" parent="NavigationRegion3D"]

[node name="BosquePrincipal" parent="NavigationRegion3D/Mundo" instance=ExtResource("8")]

[node name="TerrenoExtNorte" parent="NavigationRegion3D/Mundo" instance=ExtResource("9")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.2, -120)

[node name="TerrenoExtSur" parent="NavigationRegion3D/Mundo" instance=ExtResource("9")]
transform = Transform3D(-1, 0, 0, 0, 1, 0, 0, 0, -1, 0, -0.2, 140)

[node name="Campamento" type="Node3D" parent="NavigationRegion3D/Mundo"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 4)

[node name="PisoCampamento" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Campamento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.04, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(18, 0.08, 14)
material = SubResource("MatTierra")

[node name="CaminoNorte" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Campamento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.03, -18)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(4.5, 0.08, 24)
material = SubResource("MatTierra")

[node name="CaminoEste" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Campamento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 16, -0.03, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(20, 0.08, 4)
material = SubResource("MatTierra")

[node name="Cabana1" type="Node3D" parent="NavigationRegion3D/Mundo/Campamento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -6, 0, -2)

[node name="Base" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Campamento/Cabana1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.4, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(4.2, 2.8, 3.6)
material = SubResource("MatMadera")

[node name="Techo" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Campamento/Cabana1"]
transform = Transform3D(1, 0, 0, 0, 0.866025, -0.5, 0, 0.5, 0.866025, 0, 3.1, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(4.8, 0.25, 4.2)
material = SubResource("MatMaderaOscura")

[node name="Cabana2" type="Node3D" parent="NavigationRegion3D/Mundo/Campamento"]
transform = Transform3D(0.965926, 0, 0.258819, 0, 1, 0, -0.258819, 0, 0.965926, 6.5, 0, -1)

[node name="Base" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Campamento/Cabana2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.3, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(3.8, 2.6, 3.4)
material = SubResource("MatMadera")

[node name="Techo" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Campamento/Cabana2"]
transform = Transform3D(1, 0, 0, 0, 0.866025, -0.5, 0, 0.5, 0.866025, 0, 2.9, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(4.4, 0.22, 4.0)
material = SubResource("MatMaderaOscura")

[node name="MuroBajo1" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Campamento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.6, 6.5)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(10, 1.2, 0.6)
material = SubResource("MatPiedra")

[node name="MuroBajo2" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Campamento"]
transform = Transform3D(0, 0, 1, 0, 1, 0, -1, 0, 0, 8.5, 0.6, 2)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(8, 1.2, 0.6)
material = SubResource("MatPiedra")

[node name="LuzFogata" type="OmniLight3D" parent="NavigationRegion3D/Mundo/Campamento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0.5, 1.2, 1.5)
light_color = Color(1, 0.62, 0.28, 1)
light_energy = 1.1
omni_range = 14.0
omni_attenuation = 1.4
shadow_enabled = false

[node name="LuzCabana" type="OmniLight3D" parent="NavigationRegion3D/Mundo/Campamento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -5.5, 1.8, -2)
light_color = Color(1, 0.78, 0.45, 1)
light_energy = 0.55
omni_range = 7.0
omni_attenuation = 1.6
shadow_enabled = false

[node name="Ambientacion" type="Node3D" parent="NavigationRegion3D/Mundo"]

[node name="Moto" parent="NavigationRegion3D/Mundo/Ambientacion" instance=ExtResource("12")]
transform = Transform3D(1.3, 0, 0, 0, 1.3, 0, 0, 0, 1.3, 4.5, 0, 2.5)

[node name="Carro" parent="NavigationRegion3D/Mundo/Ambientacion" instance=ExtResource("13")]
transform = Transform3D(1.15, 0, 0.2, 0, 1.15, 0, -0.2, 0, 1.15, 10, 0, -3)

[node name="CriaturasLejanas" type="Node3D" parent="NavigationRegion3D/Mundo"]

[node name="Demonio" parent="NavigationRegion3D/Mundo/CriaturasLejanas" instance=ExtResource("10")]
transform = Transform3D(1.6, 0, 0, 0, 1.6, 0, 0, 0, 1.6, -22, 0, -28)

[node name="Razghul" parent="NavigationRegion3D/Mundo/CriaturasLejanas" instance=ExtResource("11")]
transform = Transform3D(1.7, 0, 0, 0, 1.7, 0, 0, 0, 1.7, 26, 0, -42)

[node name="Enemies" type="Node3D" parent="."]

[node name="Spawner1" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 12, 0.6, -6)
item = ExtResource("6")
spawn_time = 3.0
max_items = 2

[node name="Spawner2" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -12, 0.6, -6)
item = ExtResource("6")
spawn_time = 3.0
max_items = 2

[node name="Spawner3" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.6, -22)
item = ExtResource("6")
spawn_time = 3.5
max_items = 2

[node name="Spawner4" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 20, 0.6, -18)
item = ExtResource("6")
spawn_time = 4.0
max_items = 2
'''
open(out,'w',encoding='utf-8').write(scene)
print('ok', out)
