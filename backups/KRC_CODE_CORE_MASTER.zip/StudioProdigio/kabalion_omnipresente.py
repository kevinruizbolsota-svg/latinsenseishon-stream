"""
╔══════════════════════════════════════════════════════════════╗
║       KABALION TV OMNIPOTENTE v2.0 — KRC STUDIO PRODIGIO    ║
║   IA de Transmisión, Contenido y Estrategia 24/7            ║
╠══════════════════════════════════════════════════════════════╣
║  HABILIDADES ACTIVAS:                                        ║
║  1. Agente Explorador     → Series nostálgicas en YouTube    ║
║  2. Agente Descargador    → Búfer 30 caps, lotes de 10       ║
║  3. Agente Transmisor     → RTMP a Twitch + Kick simultáneo  ║
║  4. Agente Clipper Viral  → Shorts 9:16 auto (12PM y 7PM)    ║
║  5. Agente Guardián       → Auto-recuperación de caídas      ║
║  6. Agente Monitor        → Dashboard en tiempo real [NUEVO] ║
║  7. Agente Scheduler      → Programación de series [NUEVO]   ║
║  8. Agente Notificador    → Alertas de estado en consola     ║
╚══════════════════════════════════════════════════════════════╝
"""
import sys, subprocess, json, time, os, shutil, threading, signal
from pathlib import Path
from datetime import datetime, timedelta
import yt_dlp

FFMPEG   = Path(r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe")
STUDIO   = Path(r"C:\Users\kevin\StudioProdigio")
TV_DIR   = Path(r"C:\Users\kevin\Desktop\O\KABALION TV")
EN_COLA       = TV_DIR / "EN_COLA"
TRANSMITIENDO = TV_DIR / "TRANSMITIENDO"
TRANSMITIDOS  = TV_DIR / "TRANSMITIDOS"
MANT          = TV_DIR / "MANTENIMIENTO"
TEMP_DIR      = STUDIO / "tv_temp"
SHORTS_OUT    = Path(r"C:\Users\kevin\Desktop\O\SHORTS_PRODIGIO_LISTOS")
STATS_FILE    = STUDIO / "kabalion_stats.json"
LOG_FILE      = STUDIO / "kabalion_v2.log"

for d in [EN_COLA, TRANSMITIENDO, TRANSMITIDOS, MANT, TEMP_DIR, SHORTS_OUT]:
    d.mkdir(parents=True, exist_ok=True)

INTRO    = STUDIO / "assets/intro/intro_oficial.mp4"
OUTRO    = STUDIO / "assets/outro/outro_oficial.mp4"
LOGO     = STUDIO / "assets/logo/Koyal-Photoroom.png"
CFG_FILE = STUDIO / "stream_config.json"

# ══════════════════════════════════════════
# PROGRAMACIÓN DE SERIES (Scheduler)
# ══════════════════════════════════════════
SERIES_MAESTRAS = [
    {"nombre": "Dragon Ball Z",   "url": "https://www.youtube.com/playlist?list=PLxqR1nAef2BHfk0hCGdNFzBjhp6hm9M4v", "prioridad": 1},
    {"nombre": "El Chavo del 8",  "url": "https://www.youtube.com/playlist?list=PLuxcLq9n25BEINVPnsS419gD8E6WSeiS-", "prioridad": 2},
    {"nombre": "Bob Esponja",     "url": "https://www.youtube.com/playlist?list=PLuKg-WnCU1f_YX8R-3JD8g5mGdGl6BTWL", "prioridad": 3},
    {"nombre": "Dragon Ball Super","url": "https://www.youtube.com/playlist?list=PLxqR1nAef2BHfk0hCGdNFzBjhp6hm9M4v", "prioridad": 4},
]

CAPACIDAD_MAXIMA = 30
UMBRAL_RECARGA   = 20

# ══════════════════════════════════════════
# ESTADÍSTICAS GLOBALES
# ══════════════════════════════════════════
stats = {
    "inicio": datetime.now().isoformat(),
    "capitulos_transmitidos": 0,
    "shorts_generados": 0,
    "tiempo_en_aire_min": 0,
    "reconexiones": 0,
    "plataformas_activas": [],
    "ultimo_capitulo": "",
    "estado": "INICIANDO",
}

def guardar_stats():
    try:
        with open(STATS_FILE, "w", encoding="utf-8") as f:
            json.dump(stats, f, indent=2, ensure_ascii=False, default=str)
    except Exception:
        pass

# ══════════════════════════════════════════
# LOGGING CON COLORES
# ══════════════════════════════════════════
RESET  = "\033[0m"
VERDE  = "\033[92m"
AZUL   = "\033[94m"
AMARILLO = "\033[93m"
ROJO   = "\033[91m"
CYAN   = "\033[96m"
MAGENTA = "\033[95m"

def log(msg, color=RESET):
    ts = datetime.now().strftime("%H:%M:%S")
    linea = f"[{ts}] {msg}"
    print(f"{color}{linea}{RESET}", flush=True)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(linea + "\n")
    except Exception:
        pass

# ══════════════════════════════════════════
# HABILIDAD 6: DASHBOARD EN TIEMPO REAL
# ══════════════════════════════════════════
def hilo_dashboard():
    """Imprime un resumen de estado cada 5 minutos."""
    while True:
        time.sleep(300)
        cola  = len(list(EN_COLA.glob("*.mp4")))
        trans = len(list(TRANSMITIDOS.glob("*.mp4")))
        shorts = len(list(SHORTS_OUT.glob("*.mp4")))
        inicio = datetime.fromisoformat(stats["inicio"])
        mins   = int((datetime.now() - inicio).total_seconds() / 60)
        log("╔═══════════════ KABALION DASHBOARD ════════════════╗", CYAN)
        log(f"  📺 En cola:          {cola} episodios",           CYAN)
        log(f"  ✅ Transmitidos:     {stats['capitulos_transmitidos']} episodios", CYAN)
        log(f"  🎬 Shorts listos:    {shorts}",                   CYAN)
        log(f"  🔁 Reconexiones:     {stats['reconexiones']}",    CYAN)
        log(f"  ⏱  Tiempo en aire:   {mins} min",                CYAN)
        log(f"  🔴 Estado:           {stats['estado']}",          CYAN)
        log("╚════════════════════════════════════════════════════╝", CYAN)
        guardar_stats()

# ══════════════════════════════════════════
# HABILIDAD 7: SCHEDULER DE SERIES
# ══════════════════════════════════════════
def hilo_scheduler():
    """Rota la serie activa según prioridad y día de la semana."""
    while True:
        ahora = datetime.now()
        # Lunes-Miércoles: DBZ | Jueves-Viernes: Chavo | Finde: Bob Esponja
        dia = ahora.weekday()  # 0=Lunes
        if dia <= 2:
            serie_activa = "Dragon Ball Z"
        elif dia <= 4:
            serie_activa = "El Chavo del 8"
        else:
            serie_activa = "Bob Esponja"
        log(f"📅 Scheduler: serie activa hoy → {serie_activa}", MAGENTA)
        time.sleep(3600)  # Chequea cada hora

# ══════════════════════════════════════════
# HABILIDAD 5: GUARDIÁN DE CAÍDAS
# ══════════════════════════════════════════
proceso_actual = {"proc": None, "inicio": None}

def hilo_guardian():
    """Monitorea el proceso FFmpeg y lo reinicia si se cae."""
    while True:
        time.sleep(30)
        proc = proceso_actual.get("proc")
        if proc is not None and proc.poll() is not None:
            stats["reconexiones"] += 1
            log(f"🛡️  GUARDIÁN: FFmpeg caído (código {proc.returncode}). Reconectando... [{stats['reconexiones']}]", AMARILLO)
            stats["estado"] = "RECONECTANDO"
            guardar_stats()

# ══════════════════════════════════════════
# FFmpeg helpers
# ══════════════════════════════════════════
def ff(*args):
    r = subprocess.run([str(FFMPEG)] + list(args),
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return r.returncode == 0

def norm_asset(src):
    d = TEMP_DIR / f"_a_{src.stem}.mp4"
    if d.exists():
        return d
    ff("-y", "-i", str(src),
       "-vf", "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=30",
       "-c:v", "libx264", "-preset", "fast", "-c:a", "aac", "-ar", "44100", "-ac", "2", str(d))
    return d

def procesar_video_capitulo(raw_path, out_path):
    if out_path.exists() and out_path.stat().st_size > 100_000:
        return out_path

    norm_mid = TEMP_DIR / f"norm_{raw_path.stem}.mp4"
    logo_ok  = LOGO.exists()

    if logo_ok:
        logo_filter = (
            "[0:v]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=30[base];"
            "[1:v]scale=140:140,format=rgba,fade=t=in:st=2:d=1:alpha=1,fade=t=out:st=55:d=1:alpha=1[logo];"
            "[base][logo]overlay=W-w-20:H-h-30[v]"
        )
        ok = ff("-y", "-i", str(raw_path), "-i", str(LOGO),
                "-filter_complex", logo_filter, "-map", "[v]", "-map", "0:a",
                "-c:v", "libx264", "-preset", "fast", "-b:v", "2500k",
                "-c:a", "aac", "-ar", "44100", "-ac", "2", "-b:a", "160k", str(norm_mid))
    else:
        ok = ff("-y", "-i", str(raw_path),
                "-vf", "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=30",
                "-c:v", "libx264", "-preset", "fast", "-b:v", "2500k",
                "-c:a", "aac", "-ar", "44100", "-ac", "2", "-b:a", "160k", str(norm_mid))
    if not ok:
        return None

    intro_ok = INTRO.exists()
    outro_ok = OUTRO.exists()
    concat_txt = TEMP_DIR / f"c_{raw_path.stem}.txt"
    with open(concat_txt, "w", encoding="utf-8") as f:
        if intro_ok:
            intro_n = norm_asset(INTRO)
            f.write(f"file '{intro_n.as_posix()}'\n")
        f.write(f"file '{norm_mid.as_posix()}'\n")
        if outro_ok:
            outro_n = norm_asset(OUTRO)
            f.write(f"file '{outro_n.as_posix()}'\n")

    ok2 = ff("-y", "-f", "concat", "-safe", "0", "-i", str(concat_txt),
             "-c:v", "libx264", "-preset", "fast", "-b:v", "2500k",
             "-c:a", "aac", "-ar", "44100", "-ac", "2", "-b:a", "160k", str(out_path))
    try:
        norm_mid.unlink(missing_ok=True)
        concat_txt.unlink(missing_ok=True)
    except Exception:
        pass
    return out_path if ok2 and out_path.exists() else None

# ══════════════════════════════════════════
# HABILIDAD 2: DESCARGADOR AUTOMÁTICO
# ══════════════════════════════════════════
def hilo_descargador():
    log("⚙️  Agente Descargador & Compilador v2.0 Iniciado", VERDE)
    cursor_serie   = 0
    indices_serie  = {s["nombre"]: 0 for s in SERIES_MAESTRAS}
    num_global     = 1

    while True:
        cola_actual = len(list(EN_COLA.glob("*.mp4")))
        if cola_actual <= UMBRAL_RECARGA:
            faltan = CAPACIDAD_MAXIMA - cola_actual
            lote   = min(faltan, 10)
            log(f"📥 Cola baja ({cola_actual}/{CAPACIDAD_MAXIMA}). Descargando lote de {lote}...", AMARILLO)

            serie     = SERIES_MAESTRAS[cursor_serie % len(SERIES_MAESTRAS)]
            s_name    = serie["nombre"]
            s_url     = serie["url"]
            idx_start = indices_serie.get(s_name, 0)

            try:
                with yt_dlp.YoutubeDL({"quiet": True, "extract_flat": True}) as ydl:
                    info = ydl.extract_info(s_url, download=False)
                    entries = info.get("entries", []) if info else []
            except Exception as e:
                log(f"⚠️  Error obteniendo playlist {s_name}: {e}", ROJO)
                time.sleep(60)
                continue

            descargados = 0
            for entry in entries[idx_start:idx_start + lote * 2]:
                if descargados >= lote:
                    break
                vid_id = entry.get("id") or entry.get("url", "")
                if not vid_id:
                    continue

                ep_name  = f"{num_global:03d}_{s_name.replace(' ','_')}_{vid_id}.mp4"
                out_ep   = EN_COLA / ep_name
                raw      = TEMP_DIR / f"raw_{vid_id}.mp4"

                if out_ep.exists() and out_ep.stat().st_size > 5_000_000:
                    log(f"  ↩ Ya existe: {ep_name}", AZUL)
                    num_global += 1
                    descargados += 1
                    continue

                log(f"  ⬇ Descargando {s_name} - {entry.get('title','ep')[:40]}...", AZUL)
                dl_opts = {
                    "format": "bv[height<=720]+ba/best[height<=720]",
                    "outtmpl": str(raw.with_suffix('.%(ext)s')),
                    "ffmpeg_location": str(FFMPEG.parent),
                    "merge_output_format": "mp4",
                    "quiet": True,
                }
                try:
                    with yt_dlp.YoutubeDL(dl_opts) as ydl:
                        ydl.download([f"https://www.youtube.com/watch?v={vid_id}"])
                except Exception as e:
                    log(f"  ⚠ Error descargando {vid_id}: {e}", ROJO)
                    continue

                raw_real = next(TEMP_DIR.glob(f"raw_{vid_id}.*"), raw)
                if raw_real.exists():
                    log(f"  ✂  Montando intro + logo + outro → {ep_name}", VERDE)
                    procesar_video_capitulo(raw_real, out_ep)
                    try:
                        raw_real.unlink(missing_ok=True)
                    except Exception:
                        pass

                num_global += 1
                descargados += 1
                indices_serie[s_name] = idx_start + descargados
                time.sleep(2)

            cursor_serie += 1

        time.sleep(30)

# ══════════════════════════════════════════
# HABILIDAD 4: CLIPPER VIRAL AUTO
# ══════════════════════════════════════════
def hilo_clipper_viral():
    log("🤖 Agente Clipper Viral Activo (12PM y 7PM)", MAGENTA)
    while True:
        ahora_str = datetime.now().strftime("%H:%M")
        transmitidos = list(TRANSMITIDOS.glob("*.mp4"))
        if transmitidos:
            reciente  = sorted(transmitidos, key=lambda f: f.stat().st_mtime, reverse=True)[0]
            clip_name = f"VIRAL_{reciente.stem[:30]}.mp4"
            out_clip  = SHORTS_OUT / clip_name
            if not out_clip.exists():
                log(f"✨ Generando short vertical 9:16 de: {reciente.name[:50]}", MAGENTA)
                filt = (
                    "[0:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1[vbg];"
                    "[1:v]scale=200:200,format=rgba[logo];"
                    "[vbg][logo]overlay=W-w-30:H-h-50[vout]"
                ) if LOGO.exists() else "[0:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920[vout]"

                extra = ["-i", str(LOGO)] if LOGO.exists() else []
                ok = ff("-y", "-ss", "00:08:00", "-t", "58",
                        "-i", str(reciente), *extra,
                        "-filter_complex", filt, "-map", "[vout]", "-map", "0:a",
                        "-c:v", "libx264", "-preset", "veryfast", "-b:v", "3500k",
                        "-c:a", "aac", "-b:a", "192k", str(out_clip))
                if ok and out_clip.exists():
                    log(f"🎬 Short listo → {SHORTS_OUT / clip_name}", VERDE)
                    stats["shorts_generados"] += 1
                    guardar_stats()

        if ahora_str in ["12:00", "19:00"]:
            log(f"⏰ HORA DE PUBLICACIÓN ({ahora_str}) — Short listo en: {SHORTS_OUT}", AMARILLO)
            time.sleep(61)

        time.sleep(29)

# ══════════════════════════════════════════
# HABILIDAD 3: TRANSMISOR TWITCH + KICK
# ══════════════════════════════════════════
def emitir_rtmp_dual(video_path):
    """Transmite simultáneamente a Twitch + Kick usando tee."""
    try:
        cfg = json.loads(CFG_FILE.read_text(encoding="utf-8-sig")) if CFG_FILE.exists() else {}
    except Exception:
        cfg = {}

    tee_parts = []
    plats      = []
    tw = cfg.get("twitch", {})
    if tw.get("activo") and tw.get("key"):
        url = f"rtmp://live.twitch.tv/app/{tw['key']}"
        tee_parts.append(f"[f=flv:onfail=ignore]{url}")
        plats.append("Twitch")

    kk = cfg.get("kick", {})
    if kk.get("activo") and kk.get("key"):
        url = f"rtmps://fa723fc1b171.global-contribute.live-video.net:443/app/{kk['key']}"
        tee_parts.append(f"[f=flv:onfail=ignore]{url}")
        plats.append("Kick")

    if not tee_parts:
        log("⚠️  Sin plataformas activas con key válida.", ROJO)
        return None

    stats["plataformas_activas"] = plats
    log(f"🔴 TRANSMITIENDO a: {' + '.join(plats)}", VERDE)

    logo_input = ["-i", str(LOGO)] if LOGO.exists() else []
    vfilter    = (
        "[0:v]scale=1280:720:force_original_aspect_ratio=decrease,"
        "pad=1280:720:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30[bg];"
        "[1:v]scale=110:-1,format=rgba[lg];"
        "[bg][lg]overlay=12:H-h-12[v]"
    ) if LOGO.exists() else "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30"

    cmd = [str(FFMPEG), "-re", "-i", str(video_path)] + logo_input

    if LOGO.exists():
        cmd += ["-filter_complex", vfilter, "-map", "[v]"]
    else:
        cmd += ["-vf", vfilter, "-map", "0:v:0"]

    cmd += [
        "-map", "0:a:0?",
        "-c:v", "libx264", "-preset", "veryfast", "-b:v", "3000k",
        "-maxrate", "3000k", "-bufsize", "6000k", "-pix_fmt", "yuv420p",
        "-g", "60", "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-ac", "2",
        "-f", "tee", "|".join(tee_parts)
    ]

    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    proceso_actual["proc"]   = proc
    proceso_actual["inicio"] = datetime.now()
    return proc

# ══════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════
def main():
    log("╔══════════════════════════════════════════════════════╗", VERDE)
    log("║   🤖 KABALION TV OMNIPOTENTE v2.0 — KRC PRODIGIO   ║", VERDE)
    log("║      Twitch + Kick | Auto-Shorts | Dashboard 24/7   ║", VERDE)
    log("╚══════════════════════════════════════════════════════╝", VERDE)
    stats["estado"] = "ACTIVO"
    guardar_stats()

    pause_video = MANT / "pantalla_universo.mp4"

    # Lanzar todos los agentes en paralelo
    for target in [hilo_descargador, hilo_clipper_viral, hilo_dashboard,
                   hilo_scheduler, hilo_guardian]:
        threading.Thread(target=target, daemon=True).start()

    log("✅ Todos los agentes iniciados. Iniciando transmisión...", VERDE)

    while True:
        cola = sorted(EN_COLA.glob("*.mp4"))
        if not cola:
            log("🌌 Cola vacía → Pausa cósmica (Solfeggio 174 Hz)...", AMARILLO)
            stats["estado"] = "PAUSA_COSMICA"
            if pause_video.exists():
                proc = emitir_rtmp_dual(pause_video)
                if proc:
                    proc.wait()
            else:
                time.sleep(10)
            continue

        ep   = cola[0]
        dest = TRANSMITIENDO / ep.name
        try:
            shutil.move(str(ep), str(dest))
        except Exception as e:
            log(f"⚠️  Error moviendo {ep.name}: {e}", ROJO)
            time.sleep(5)
            continue

        log(f"🔴 AL AIRE → {dest.name}", VERDE)
        stats["estado"]          = f"TRANSMITIENDO: {dest.name[:40]}"
        stats["ultimo_capitulo"] = dest.name
        guardar_stats()

        proc = emitir_rtmp_dual(dest)
        if proc:
            proc.wait()

        final = TRANSMITIDOS / dest.name
        try:
            shutil.move(str(dest), str(final))
        except Exception as e:
            log(f"⚠️  Error archivando {dest.name}: {e}", ROJO)

        stats["capitulos_transmitidos"] += 1
        log(f"✅ Capítulo completado [{stats['capitulos_transmitidos']} total]: {final.name}", VERDE)
        guardar_stats()

        # Limpiar transmitidos si superan 10
        trans = sorted(TRANSMITIDOS.glob("*.mp4"), key=lambda f: f.stat().st_mtime)
        if len(trans) > 10:
            for antiguo in trans[:-10]:
                log(f"🗑  Purgando antiguo: {antiguo.name}", AMARILLO)
                try:
                    antiguo.unlink(missing_ok=True)
                except Exception:
                    pass

        time.sleep(1)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        log("⛔ KABALION detenido por el usuario.", ROJO)
        sys.exit(0)
