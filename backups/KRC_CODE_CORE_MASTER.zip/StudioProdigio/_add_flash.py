﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.tscn")
t = p.read_text(encoding="utf-8")

# add HitFlash ColorRect at start of UI (so it's behind text or overlay?) - full screen overlay
old_ui_start = r'''[node name="UI" type="CanvasLayer" parent="."]

[node name="Status" type="Label" parent="UI"]'''
new_ui_start = r'''[node name="UI" type="CanvasLayer" parent="."]

[node name="HitFlash" type="ColorRect" parent="UI"]
anchors_preset = 15
anchor_right = 1.0
anchor_bottom = 1.0
grow_horizontal = 2
grow_vertical = 2
color = Color(0.7, 0, 0, 0)
mouse_filter = 2

[node name="Status" type="Label" parent="UI"]'''
if old_ui_start in t:
    t = t.replace(old_ui_start, new_ui_start)

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
