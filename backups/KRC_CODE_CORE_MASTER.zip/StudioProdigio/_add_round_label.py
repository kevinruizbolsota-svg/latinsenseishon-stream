﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.tscn")
t = p.read_text(encoding="utf-8")

# add RondaAnuncio label in UI (before menus, after HitMarker)
old_hm = r'''[node name="HitMarker" type="Label" parent="UI"]
anchors_preset = 8
anchor_left = 0.5
anchor_top = 0.5
anchor_right = 0.5
anchor_bottom = 0.5
offset_left = -20.0
offset_top = -22.0
offset_right = 20.0
offset_bottom = 22.0
theme_override_colors/font_color = Color(1, 0.9, 0.9, 1)
text = ""
horizontal_alignment = 1
vertical_alignment = 1'''
new_hm = old_hm + r'''

[node name="RondaAnuncio" type="Label" parent="UI"]
anchors_preset = 5
anchor_left = 0.5
anchor_right = 0.5
offset_left = -300.0
offset_top = 140.0
offset_right = 300.0
offset_bottom = 190.0
theme_override_colors/font_color = Color(1, 0.92, 0.7, 1)
theme_override_colors/font_outline_color = Color(0, 0, 0, 1)
theme_override_constants/outline_size = 4
theme_override_font_sizes/font_size = 30
text = ""
horizontal_alignment = 1'''
if old_hm in t and 'RondaAnuncio' not in t:
    t = t.replace(old_hm, new_hm)

# style menu title a bit more
t = t.replace('theme_override_font_sizes/font_size = 42\ntext = "COLWAR - OPERACIÓN BASE"',
              'theme_override_font_sizes/font_size = 44\ntext = "COLWAR - OPERACIÓN BASE"')

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
