﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.tscn")
t = p.read_text(encoding="utf-8")

# W1: classic wood/metal look - keep MatMadera/MatTecho, make distinct
# W2: darker tactical - use MatTecho/MatPared, adjust
t = t.replace(r'''[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.02, -0.14)
size = Vector3(0.065, 0.085, 0.42)
material = SubResource("MatTecho")''',
r'''[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.02, -0.14)
size = Vector3(0.065, 0.085, 0.42)
material = SubResource("MatExterior")''')

# W3: heavier look - darker body
t = t.replace(r'''[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.03, -0.2)
size = Vector3(0.085, 0.1, 0.58)
material = SubResource("MatPared")''',
r'''[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.03, -0.2)
size = Vector3(0.085, 0.1, 0.58)
material = SubResource("MatExterior")''')

# position muzzle flash relative to weapon - move it a bit forward
t = t.replace(r'''[node name="MuzzleFlash" type="OmniLight3D" parent="Player/Camera3D"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0.2, -0.15, -0.9)
visible = false
light_color = Color(1, 0.85, 0.45, 1)
light_energy = 2.5
omni_range = 4.0''',
r'''[node name="MuzzleFlash" type="OmniLight3D" parent="Player/Camera3D"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0.22, -0.18, -1.05)
visible = false
light_color = Color(1, 0.85, 0.45, 1)
light_energy = 3.0
omni_range = 4.5''')

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
