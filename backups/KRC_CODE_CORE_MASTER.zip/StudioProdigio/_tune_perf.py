﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\project.godot")
t = p.read_text(encoding="utf-8")

# add/replace rendering settings for performance + decent quality
render_block = r'''
[rendering]
renderer/rendering_method="forward_plus"
textures/canvas_textures/default_texture_filter=2
scaling_3d/mode=1
scaling_3d/scale=0.85
anti_aliasing/quality/msaa_3d=0
anti_aliasing/quality/screen_space_aa=1
'''
# replace existing rendering section
import re
t = re.sub(r'\n\[rendering\][\s\S]*$', '\n' + render_block.strip() + '\n', t)
p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
