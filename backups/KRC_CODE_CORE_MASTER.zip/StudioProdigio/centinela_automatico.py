import os
import time
import subprocess
from pathlib import Path

BASE_DIR = Path(r"C:\Users\kevin\StudioProdigio")
WATCH_DIR = BASE_DIR / "cola_automatica"
WATCH_DIR.mkdir(parents=True, exist_ok=True)

PYTHON = r"C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe"
CREADOR = BASE_DIR / "crear_obra_maestra.py"

print("===================================================================")
print("     ★ CENTINELA AUTOMÁTICO 24/7 - STUDIO PRODIGIO AI ★            ")
print("===================================================================")
print(f"[*] Escaneando la carpeta cada 5 segundos:")
print(f"    📂 {WATCH_DIR}")
print("[-] Deja aquí cualquier video largo o descarga, y la IA lo tomará,")
print("    le pondrá la Intro oficial, grado de cine y Outro KRC automáticamente.")
print("===================================================================\n")

while True:
    videos = list(WATCH_DIR.glob("*.mp4")) + list(WATCH_DIR.glob("*.mkv"))
    for v in videos:
        print(f"\n[!] NUEVO VIDEO DETECTADO: {v.name}")
        out_name = f"Short_Auto_{v.stem[:20]}"
        cmd = [PYTHON, str(CREADOR)]
        # Procesar automáticamente
        print("[*] Lanzando motor cinematográfico...")
        # Simplemente mover a input y ejecutar
        dest = BASE_DIR / "input" / "chavo_clip.mp4"
        v.replace(dest)
        subprocess.run(cmd)
        print(f"[✓] Video procesado y dejado listo en el Escritorio.")
    time.sleep(5)
