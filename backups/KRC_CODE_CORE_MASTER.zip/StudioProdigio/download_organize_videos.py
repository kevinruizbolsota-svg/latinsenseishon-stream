"""
DESCARGADOR Y ORGANIZADOR DE VIDEOS - 30 CAPITULOS
Descarga 3 videos de cada serie, los normaliza con logo KRC, y los organiza
"""
import sys, json, time, subprocess, os
from pathlib import Path
sys.path.insert(0, r"C:\Users\kevin\StudioProdigio")

STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
FFMPEG = Path(r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe")
LOGO = STUDIO / "assets" / "logo" / "logo_krc_transparent.png"
EPISODES_DIR = STUDIO / "tv_episodes"
NORMALIZED_DIR = STUDIO / "tv_normalized"
OUTPUT_DIR = Path(r"C:\Users\kevin\Desktop\O\VIDEOS LARGOS PARA STREAMING")

EPISODES_DIR.mkdir(parents=True, exist_ok=True)
NORMALIZED_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

def download_video(video_id, title, out_dir):
    """Descarga un video de YouTube."""
    mp4 = out_dir / f"{video_id}.mp4"
    if mp4.exists() and mp4.stat().st_size > 100_000:
        print(f"  Ya existe: {title[:40]}")
        return mp4
    opts = {
        "format": "bv[height<=480]+ba/best[height<=480]",
        "outtmpl": str(out_dir / f"{video_id}.%(ext)s"),
        "ffmpeg_location": str(FFMPEG.parent),
        "merge_output_format": "mp4",
        "quiet": True,
        "no_warnings": True,
    }
    try:
        import yt_dlp
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.download([f"https://www.youtube.com/watch?v={video_id}"])
        if mp4.exists():
            print(f"  Descargado: {title[:40]} ({mp4.stat().st_size // 1024}KB)")
            return mp4
    except Exception as e:
        print(f"  Error descargando {title[:40]}: {str(e)[:60]}")
    return None

def normalize_video(src, dst):
    """Normaliza video a 1280x720 30fps con logo KRC."""
    if dst.exists() and dst.stat().st_size > 100_000:
        print(f"  Ya normalizado: {dst.name}")
        return dst
    if LOGO.exists():
        logo_filter = (
            "[0:v]scale=1280:720:force_original_aspect_ratio=decrease,"
            "pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=30[base];"
            "[1:v]scale=140:140,format=rgba,"
            "fade=t=in:st=2:d=1:alpha=1[logo];"
            "[base][logo]overlay=W-w-20:H-h-30[v]"
        )
        cmd = [str(FFMPEG), "-y", "-i", str(src), "-i", str(LOGO),
               "-filter_complex", logo_filter,
               "-map", "[v]", "-map", "0:a",
               "-c:v", "libx264", "-preset", "fast", "-b:v", "2000k",
               "-c:a", "aac", "-ar", "44100", "-ac", "2", "-b:a", "128k",
               str(dst)]
    else:
        cmd = [str(FFMPEG), "-y", "-i", str(src),
               "-vf", "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=30",
               "-c:v", "libx264", "-preset", "fast", "-b:v", "2000k",
               "-c:a", "aac", "-ar", "44100", "-ac", "2", "-b:a", "128k",
               str(dst)]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0 and dst.exists():
        print(f"  Normalizado: {dst.name}")
        return dst
    else:
        print(f"  Error normalizando: {result.stderr[-200:]}")
    return None

def main():
    # Load found videos
    videos_file = STUDIO / "videos_encontrados.json"
    if not videos_file.exists():
        print("ERROR: videos_encontrados.json no encontrado. Ejecuta buscar_videos_individuales.py primero.")
        return

    all_videos = json.loads(videos_file.read_text(encoding="utf-8"))

    # Select top 10 series (3 videos each = 30 chapters)
    series_list = list(all_videos.keys())[:10]
    print(f"\n{'='*60}")
    print(f"  DESCARGADOR DE 30 CAPITULOS")
    print(f"  {len(series_list)} series x 3 videos = {len(series_list)*3} capitulos")
    print(f"{'='*60}\n")

    total_downloaded = 0
    total_normalized = 0

    for i, serie_name in enumerate(series_list, 1):
        videos = all_videos[serie_name][:3]
        safe_name = serie_name.replace(" ", "_").replace("/", "_")
        ep_dir = EPISODES_DIR / safe_name
        norm_dir = NORMALIZED_DIR / safe_name
        ep_dir.mkdir(parents=True, exist_ok=True)
        norm_dir.mkdir(parents=True, exist_ok=True)

        print(f"\n[{i}/{len(series_list)}] {serie_name}")

        for j, vid in enumerate(videos, 1):
            vid_id = vid["id"]
            title = vid["title"]

            # Download
            raw = download_video(vid_id, title, ep_dir)
            if raw and raw.exists():
                total_downloaded += 1
                # Normalize
                norm = norm_dir / f"norm_{vid_id}.mp4"
                result = normalize_video(raw, norm)
                if result and result.exists():
                    total_normalized += 1

            time.sleep(1)  # Rate limit

    print(f"\n{'='*60}")
    print(f"  RESUMEN")
    print(f"  Descargados: {total_downloaded}")
    print(f"  Normalizados: {total_normalized}")
    print(f"  Total esperado: {len(series_list)*3}")
    print(f"{'='*60}")

    # Create organization file
    org = {
        "total_series": len(series_list),
        "total_chapters": total_normalized,
        "series": {}
    }
    for serie_name in series_list:
        safe_name = serie_name.replace(" ", "_").replace("/", "_")
        norm_dir = NORMALIZED_DIR / safe_name
        if norm_dir.exists():
            org["series"][serie_name] = {
                "chapters": [f.name for f in norm_dir.glob("*.mp4")],
                "count": len(list(norm_dir.glob("*.mp4")))
            }

    org_file = STUDIO / "video_organization.json"
    org_file.write_text(json.dumps(org, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nOrganizacion guardada en: {org_file}")

if __name__ == "__main__":
    main()
