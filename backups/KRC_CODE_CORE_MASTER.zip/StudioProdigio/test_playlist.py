import yt_dlp
import json

ydl_opts = {'extract_flat': True, 'quiet': True}
with yt_dlp.YoutubeDL(ydl_opts) as ydl:
    res = ydl.extract_info('https://www.youtube.com/playlist?list=PLuxcLq9n25BEINVPnsS419gD8E6WSeiS-', download=False)
    entries = res.get('entries', [])
    print(f"TOTAL_EPISODIOS={len(entries)}")
    for i, e in enumerate(entries[:6]):
        print(f"{i+1} | {e.get('id')} | {e.get('title')}")
