const fs = require('fs');
const p = 'C:/Users/kevin/StudioProdigio/elephant-goldfish-model/pyproject.toml';

let toml = fs.readFileSync(p, 'utf8');

// Agregar version = "0.1.0" en [project]
if (!toml.includes('version =')) {
  toml = toml.replace('[project]', '[project]\nversion = "0.1.0"');
}

fs.writeFileSync(p, toml, 'utf8');
console.log('Versión 0.1.0 agregada a [project]');
