﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\player.gd")
t = p.read_text(encoding="utf-8")

# add hit flash reference and logic
if '@onready var hit_flash' not in t:
    t = t.replace('@onready var msg_label: Label = get_node_or_null("../UI/Msg")',
                  '@onready var msg_label: Label = get_node_or_null("../UI/Msg")\n@onready var hit_flash: ColorRect = get_node_or_null("../UI/HitFlash")')

# in take_damage, flash
old_td = r'''func take_damage(amount: int):
	if dead:
		return
	health = max(health - amount, 0)
	_show_msg("¡Te golpearon! -%d" % amount)
	if health <= 0:
		dead = true
		_show_msg("HAS CAÍDO - Presiona ENTER para reiniciar", 9999.0)
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_update_ui()'''
new_td = r'''func take_damage(amount: int):
	if dead:
		return
	health = max(health - amount, 0)
	_show_msg("¡Te golpearon! -%d" % amount)
	if hit_flash:
		hit_flash.color = Color(0.7, 0, 0, 0.35)
	if health <= 0:
		dead = true
		_show_msg("HAS CAÍDO - Presiona ENTER para reiniciar", 9999.0)
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_update_ui()'''

if old_td in t:
    t = t.replace(old_td, new_td)

# fade out flash in physics process
old_phys = r'''	if _msg_timer > 0.0:
		_msg_timer -= delta
		if _msg_timer <= 0.0 and msg_label:
			msg_label.text = ""'''
new_phys = r'''	if _msg_timer > 0.0:
		_msg_timer -= delta
		if _msg_timer <= 0.0 and msg_label:
			msg_label.text = ""
	if hit_flash and hit_flash.color.a > 0.0:
		hit_flash.color.a = max(hit_flash.color.a - delta * 1.5, 0.0)'''
if old_phys in t:
    t = t.replace(old_phys, new_phys)

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
