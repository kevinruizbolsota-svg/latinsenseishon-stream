﻿from pathlib import Path
mg = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.gd")
mcode = r'''extends Node3D

@export var base_zombies := 6
@export var zombies_per_round := 2
@export var spawn_delay := 1.0

var round_num := 1
var to_spawn := 0
var spawned_this_round := 0
var _spawn_timer := 0.0
var _between_rounds := 4.0
var _in_round := true
var _scenes: Array[PackedScene] = []

var _spawn_points: Array[Vector3] = [
	Vector3(0, 1.5, -20), Vector3(0, 1.5, 20),
	Vector3(-20, 1.5, 0), Vector3(20, 1.5, 0),
	Vector3(-15, 1.5, -15), Vector3(15, 1.5, -15),
	Vector3(-15, 1.5, 15), Vector3(15, 1.5, 15),
	Vector3(0, 1.5, -28), Vector3(0, 1.5, 28),
	Vector3(25, 1.5, 10), Vector3(-25, 1.5, -10),
]

func _ready():
	_scenes = [
		load("res://zombie_spawn.tscn"),
		load("res://zombie_spawn_dragon.tscn"),
		load("res://zombie_spawn_dark.tscn"),
	]
	to_spawn = 0
	_update_round_ui()

func _process(delta):
	_update_round_ui()
	var alive = get_tree().get_nodes_in_group("zombie").size()

	if _in_round:
		if to_spawn > 0:
			_spawn_timer -= delta
			if _spawn_timer <= 0.0:
				_spawn_one()
				_spawn_timer = max(spawn_delay - round_num * 0.03, 0.4)
		if to_spawn <= 0 and alive <= 0:
			_in_round = false
			_between_rounds = 5.0
			var p = get_tree().get_first_node_in_group("player")
			if p and p.has_method("_show_msg"):
				p._show_msg("¡Ronda %d completada! Prepárate..." % round_num, 3.5)
	else:
		_between_rounds -= delta
		if _between_rounds <= 0.0:
			_start_next_round()

func _start_next_round():
	round_num += 1
	_in_round = true
	spawned_this_round = 0
	to_spawn = base_zombies + zombies_per_round * (round_num - 1)
	_spawn_timer = 0.6
	var p = get_tree().get_first_node_in_group("player")
	if p and p.has_method("_show_msg"):
		p._show_msg("RONDA %d  -  %d zombis" % [round_num, to_spawn], 3.0)

func _spawn_one():
	if to_spawn <= 0 or _scenes.is_empty():
		to_spawn = 0
		return
	# pick type: introduce stronger/different types in later rounds
	var idx_type = 0
	var r = randf()
	if round_num >= 3 and r > 0.6:
		idx_type = 2 if r > 0.8 else 1
	elif round_num >= 2 and r > 0.7:
		idx_type = 1
	idx_type = clamp(idx_type, 0, _scenes.size()-1)
	var sc = _scenes[idx_type]
	if sc == null:
		sc = _scenes[0]
	var z = sc.instantiate()
	var idx = randi() % _spawn_points.size()
	var sp = _spawn_points[idx]
	z.global_position = sp + Vector3(randf_range(-1.5,1.5), 0, randf_range(-1.5,1.5))
	# scale difficulty by round and type
	var hp_base = 80 + (round_num - 1) * 12
	var spd_base = 2.5 + (round_num - 1) * 0.07
	var dmg_base = 10 + int((round_num - 1) / 2)
	if idx_type == 1:
		hp_base = int(hp_base * 1.15); spd_base += 0.15
	elif idx_type == 2:
		hp_base = int(hp_base * 1.4); dmg_base += 3; spd_base -= 0.1
	z.hp = hp_base
	z.speed = clamp(spd_base, 2.0, 4.5)
	z.damage = dmg_base
	add_child(z)
	to_spawn -= 1
	spawned_this_round += 1

func _update_round_ui():
	var p = get_tree().get_first_node_in_group("player")
	if p and p.has_node("../UI/Status"):
		var status: Label = p.get_node("../UI/Status")
		var alive = get_tree().get_nodes_in_group("zombie").size()
		status.text = "Vida: %d/%d | Puntos: %d | Bajas: %d | Ronda: %d | Zombis: %d" % [p.health, p.max_health, p.points, p.kills, round_num, alive]
'''
mg.write_text(mcode, encoding='utf-8', newline='\n')
print("ok")
