import sys, json, time, os
from pathlib import Path
sys.path.insert(0, r"C:\Users\kevin\StudioProdigio")

STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
EPISODES_DIR = STUDIO / "tv_episodes"
ORG_FILE = STUDIO / "video_organization.json"

EPISODES_DIR.mkdir(parents=True, exist_ok=True)

def download_video(video_id, title, out_dir):
    """Descarga un video de YouTube con formato flexible."""
    mp4 = out_dir / f"{video_id}.mp4"
    if mp4.exists() and mp4.stat().st_size > 100_000:
        print(f"  [SKIP] Ya existe: {title[:50]}")
        return mp4
    import yt_dlp
    # Try multiple format strategies
    for fmt in ["best", "bestvideo+bestaudio/best", "worst", "18", "22"]:
        opts = {
            "format": fmt,
            "outtmpl": str(out_dir / f"{video_id}.%(ext)s"),
            "merge_output_format": "mp4",
            "quiet": True,
            "no_warnings": True,
            "socket_timeout": 30,
        }
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                ydl.download([f"https://www.youtube.com/watch?v={video_id}"])
            if mp4.exists() and mp4.stat().st_size > 100_000:
                size_mb = mp4.stat().st_size / (1024*1024)
                print(f"  [OK] {title[:50]} ({size_mb:.1f}MB) fmt={fmt}")
                return mp4
        except Exception as e:
            continue
    print(f"  [ERR] {title[:50]}: No se pudo descargar")
    return None

def main():
    videos_file = STUDIO / "videos_encontrados.json"
    if not videos_file.exists():
        print("ERROR: videos_encontrados.json no encontrado")
        return

    all_videos = json.loads(videos_file.read_text(encoding="utf-8"))
    series_list = list(all_videos.keys())[:10]

    print(f"\n{'='*60}")
    print(f"  DESCARGA v2 - 30 CAPITULOS ({len(series_list)} series x 3)")
    print(f"{'='*60}\n")

    total_downloaded = 0
    organization = {"total_series": len(series_list), "total_chapters": 0, "series": {}}

    for i, serie_name in enumerate(series_list, 1):
        videos = all_videos[serie_name][:3]
        safe_name = serie_name.replace(" ", "_").replace("/", "_").replace("ñ", "n")
        ep_dir = EPISODES_DIR / safe_name
        ep_dir.mkdir(parents=True, exist_ok=True)

        print(f"\n[{i}/{len(series_list)}] {serie_name}")

        downloaded = []
        for j, vid in enumerate(videos, 1):
            vid_id = vid["id"]
            title = vid["title"]
            print(f"  [{j}/3] {title[:50]}")
            raw = download_video(vid_id, title, ep_dir)
            if raw and raw.exists():
                total_downloaded += 1
                downloaded.append({"id": vid_id, "title": title, "file": raw.name, "size": raw.stat().st_size})

        organization["series"][serie_name] = {
            "folder": safe_name,
            "chapters": downloaded,
            "count": len(downloaded)
        }
        organization["total_chapters"] = total_downloaded
        ORG_FILE.write_text(json.dumps(organization, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"\n{'='*60}")
    print(f"  RESUMEN FINAL")
    print(f"  Series: {len(series_list)}")
    print(f"  Capitulos descargados: {total_downloaded}/{len(series_list)*3}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
