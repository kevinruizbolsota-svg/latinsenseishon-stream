const https = require('https');
https.get('https://moltbotai.chat/', (res) => {
  let d = '';
  res.on('data', c => d += c);
  res.on('end', () => {
    const links = d.match(/href="([^"]*)"/gi) || [];
    const interesting = links.filter(l => /github|download|\.exe|release|install/i.test(l));
    console.log('Interesting links:', interesting);
  });
});
