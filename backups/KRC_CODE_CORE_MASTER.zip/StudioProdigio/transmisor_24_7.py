"""
TRANSMISOR AUTOMÁTICO 24/7 - STUDIO PRODIGIO KRC
Lee stream keys de config.json y lanza ffmpeg -stream_loop -1 en cada horario.
"""
import subprocess, time, json, os, sys
from pathlib import Path
from datetime import datetime

FFMPEG = r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe"
CONFIG_FILE = Path(r"C:\Users\kevin\StudioProdigio\stream_config.json")
VIDEO_LARGO = Path(r"C:\Users\kevin\Desktop\O\VIDEOS LARGOS PARA STREAMING\MARATON_Chavo_del_8_KRC.mp4")

RTMP_BASES = {
    "youtube":  "rtmp://a.rtmp.youtube.com/live2/",
    "twitch":   "rtmp://live.twitch.tv/app/",
    "kick":     "rtmps://fa723794a661.global-contribute.live-video.net:443/app/",
    "facebook": "rtmps://live-api-s.facebook.com:443/rtmp/"
}

# Horarios de inicio del directo (HH:MM)
HORARIOS = ["06:00", "12:00", "19:00"]

def cargar_keys():
    if not CONFIG_FILE.exists():
        # Crea la plantilla vacía para que Kevin llene sus keys
        demo = {
            "youtube":  {"key": "PEGA_AQUI_TU_STREAM_KEY_YOUTUBE",  "activo": True},
            "twitch":   {"key": "PEGA_AQUI_TU_STREAM_KEY_TWITCH",   "activo": False},
            "kick":     {"key": "PEGA_AQUI_TU_STREAM_KEY_KICK",      "activo": False},
            "facebook": {"key": "PEGA_AQUI_TU_STREAM_KEY_FACEBOOK",  "activo": False}
        }
        CONFIG_FILE.write_text(json.dumps(demo, indent=2))
        print(f"[!] Plantilla de keys creada en:\n    {CONFIG_FILE}")
        print("[!] Abre ese archivo y pega tus Stream Keys reales, luego vuelve a ejecutar.")
        return {}
    return json.loads(CONFIG_FILE.read_text())

def stream_a_plataforma(plataforma, key, video):
    rtmp = RTMP_BASES[plataforma] + key
    cmd = [
        FFMPEG, "-re", "-stream_loop", "-1", "-i", str(video),
        "-c:v", "libx264", "-preset", "veryfast", "-b:v", "4500k",
        "-maxrate", "4500k", "-bufsize", "9000k", "-pix_fmt", "yuv420p",
        "-g", "60", "-c:a", "aac", "-b:a", "160k", "-ar", "44100",
        "-f", "flv", rtmp
    ]
    print(f"[►] Iniciando directo -> {plataforma.upper()}")
    return subprocess.Popen(cmd)

def wait_for_schedule():
    now_str = datetime.now().strftime("%H:%M")
    return now_str in HORARIOS

if __name__ == "__main__":
    print("\n╔══════════════════════════════════════════════╗")
    print("║  TRANSMISOR 24/7 KRC - Multi-Plataforma     ║")
    print(f"║  Horarios: {', '.join(HORARIOS)}                   ║")
    print("╚══════════════════════════════════════════════╝\n")

    keys = cargar_keys()
    if not keys:
        sys.exit(0)

    if not VIDEO_LARGO.exists():
        print(f"[!] Video largo no encontrado aún: {VIDEO_LARGO}")
        print("[!] Espera que termine compilar_maraton.py y vuelve a lanzar.")
        sys.exit(0)

    procesos = []
    print("[*] Esperando horario programado...")
    while True:
        if wait_for_schedule():
            # Matar procesos anteriores
            for p in procesos:
                try: p.terminate()
                except: pass
            procesos = []
            # Lanzar en todas las plataformas activas
            for plat, cfg in keys.items():
                if cfg.get("activo") and "PEGA" not in cfg["key"]:
                    p = stream_a_plataforma(plat, cfg["key"], VIDEO_LARGO)
                    procesos.append(p)
            time.sleep(61)  # evita doble disparo en el mismo minuto
        time.sleep(20)
