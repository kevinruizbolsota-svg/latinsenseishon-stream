import os
root = r"C:\Users\kevin\Documents\GodotFPS-Zombies-Template"
out = os.path.join(root, "colwar", "COLWAR_main.tscn")

# LEAN + MUY VISIBLE (nocturno pero sin pantalla negra) - seguro para Intel UHD
scene = r'''[gd_scene load_steps=19 format=3]

[ext_resource type="Script" path="res://common/managers/input_manager.gd" id="1"]
[ext_resource type="Script" path="res://colwar/colwar_main.gd" id="2"]
[ext_resource type="PackedScene" path="res://player/player.tscn" id="3"]
[ext_resource type="PackedScene" path="res://common/hud/gameplay_hud.tscn" id="4"]
[ext_resource type="PackedScene" path="res://common/spawner/spawner.tscn" id="5"]
[ext_resource type="PackedScene" path="res://enemies/undead.tscn" id="6"]
[ext_resource type="Script" path="res://common/managers/round_manager.gd" id="7"]
[ext_resource type="PackedScene" path="res://colwar_assets/mapas_bosque/forest.glb" id="8"]
[ext_resource type="PackedScene" path="res://colwar_assets/armas/gewehr_41_w_low-poly.glb" id="9"]

[sub_resource type="ProceduralSkyMaterial" id="SkyMat"]
sky_top_color = Color(0.05, 0.08, 0.16, 1)
sky_horizon_color = Color(0.12, 0.16, 0.26, 1)
ground_bottom_color = Color(0.04, 0.06, 0.05, 1)
ground_horizon_color = Color(0.1, 0.12, 0.14, 1)
sun_angle_max = 0.0

[sub_resource type="Sky" id="Sky1"]
sky_material = SubResource("SkyMat")

[sub_resource type="Environment" id="EnvNoche"]
background_mode = 2
sky = SubResource("Sky1")
ambient_light_source = 2
ambient_light_color = Color(0.38, 0.44, 0.58, 1)
ambient_light_energy = 1.1
reflected_light_source = 1
tonemap_mode = 3
tonemap_exposure = 1.18
tonemap_white = 1.0
ssao_enabled = false
ssil_enabled = false
glow_enabled = true
glow_levels/2 = 0.4
glow_levels/3 = 0.3
glow_intensity = 0.32
glow_strength = 0.85
glow_bloom = 0.02
glow_hdr_threshold = 1.2
fog_enabled = true
fog_light_color = Color(0.18, 0.22, 0.34, 1)
fog_light_energy = 1.0
fog_density = 0.007
fog_aerial_perspective = 0.35
fog_sky_affect = 0.35
volumetric_fog_enabled = false
adjustment_enabled = true
adjustment_brightness = 1.08
adjustment_contrast = 1.04
adjustment_saturation = 0.98

[sub_resource type="NavigationMesh" id="Nav1"]
geometry_parsed_geometry_type = 1
geometry_source_geometry_mode = 1
cell_size = 0.3
cell_height = 0.2
agent_height = 1.8
agent_radius = 0.45
agent_max_climb = 0.45
agent_max_slope = 46.0

[sub_resource type="BoxShape3D" id="FloorShape"]
size = Vector3(400, 2, 400)

[sub_resource type="StandardMaterial3D" id="MatMadera"]
albedo_color = Color(0.32, 0.24, 0.16, 1)
roughness = 0.9

[sub_resource type="StandardMaterial3D" id="MatMaderaOscura"]
albedo_color = Color(0.22, 0.16, 0.11, 1)
roughness = 0.94

[sub_resource type="StandardMaterial3D" id="MatPiedra"]
albedo_color = Color(0.38, 0.37, 0.35, 1)
roughness = 0.96

[sub_resource type="StandardMaterial3D" id="MatTierra"]
albedo_color = Color(0.26, 0.24, 0.18, 1)
roughness = 1.0

[node name="COLWAR_Main" type="Node3D"]
script = ExtResource("2")

[node name="InputManager" type="Node" parent="."]
script = ExtResource("1")

[node name="RoundManager" type="Node" parent="."]
script = ExtResource("7")

[node name="WorldEnvironment" type="WorldEnvironment" parent="."]
environment = SubResource("EnvNoche")

[node name="Luna" type="DirectionalLight3D" parent="."]
transform = Transform3D(0.939693, -0.17101, 0.296198, 0, 0.866025, 0.5, -0.34202, -0.469846, 0.813798, 0, 60, 0)
light_color = Color(0.78, 0.85, 1, 1)
light_energy = 1.35
light_indirect_energy = 0.35
shadow_enabled = false

[node name="Relleno" type="DirectionalLight3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 0.35, 0.936749, 0, -0.936749, 0.35, 0, 25, 0)
light_color = Color(0.55, 0.62, 0.82, 1)
light_energy = 0.35
shadow_enabled = false

[node name="Player" parent="." instance=ExtResource("3")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 2.5, 10)

[node name="HUD" type="CanvasLayer" parent="."]

[node name="Control" parent="HUD" instance=ExtResource("4")]

[node name="NavigationRegion3D" type="NavigationRegion3D" parent="."]
navigation_mesh = SubResource("Nav1")

[node name="SueloColisionBase" type="StaticBody3D" parent="NavigationRegion3D"]
collision_layer = 5
collision_mask = 5
[node name="CollisionShape3D" type="CollisionShape3D" parent="NavigationRegion3D/SueloColisionBase"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -1, 0)
shape = SubResource("FloorShape")

[node name="Mundo" type="Node3D" parent="NavigationRegion3D"]

[node name="BosquePrincipal" parent="NavigationRegion3D/Mundo" instance=ExtResource("8")]

[node name="Asentamiento" type="Node3D" parent="NavigationRegion3D/Mundo"]

[node name="Plaza" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Asentamiento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.04, 2)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(14, 0.08, 12)
material = SubResource("MatTierra")

[node name="CalleNorte" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Asentamiento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.03, -14)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(3.6, 0.08, 22)
material = SubResource("MatTierra")

[node name="CalleSur" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Asentamiento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.03, 18)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(3.6, 0.08, 18)
material = SubResource("MatTierra")

[node name="CalleEste" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Asentamiento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 15, -0.03, 2)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(18, 0.08, 3.2)
material = SubResource("MatTierra")

[node name="CalleOeste" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Asentamiento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -14, -0.03, 2)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(16, 0.08, 3.2)
material = SubResource("MatTierra")

[node name="CabanaA" type="Node3D" parent="NavigationRegion3D/Mundo/Asentamiento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -5.5, 0, -1.5)
[node name="Cuerpo" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Asentamiento/CabanaA"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.35, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(4.0, 2.7, 3.4)
material = SubResource("MatMadera")
[node name="Techo" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Asentamiento/CabanaA"]
transform = Transform3D(1, 0, 0, 0, 0.866025, -0.5, 0, 0.5, 0.866025, 0, 3.0, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(4.6, 0.22, 4.0)
material = SubResource("MatMaderaOscura")

[node name="CabanaB" type="Node3D" parent="NavigationRegion3D/Mundo/Asentamiento"]
transform = Transform3D(0.984808, 0, 0.173648, 0, 1, 0, -0.173648, 0, 0.984808, 5.8, 0, -2)
[node name="Cuerpo" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Asentamiento/CabanaB"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.3, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(3.6, 2.6, 3.2)
material = SubResource("MatMadera")
[node name="Techo" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Asentamiento/CabanaB"]
transform = Transform3D(1, 0, 0, 0, 0.866025, -0.5, 0, 0.5, 0.866025, 0, 2.9, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(4.2, 0.2, 3.8)
material = SubResource("MatMaderaOscura")

[node name="CabanaC" type="Node3D" parent="NavigationRegion3D/Mundo/Asentamiento"]
transform = Transform3D(0, 0, 1, 0, 1, 0, -1, 0, 0, -2, 0, 6)
[node name="Cuerpo" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Asentamiento/CabanaC"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.25, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(3.2, 2.5, 3.0)
material = SubResource("MatMadera")
[node name="Techo" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Asentamiento/CabanaC"]
transform = Transform3D(1, 0, 0, 0, 0.866025, -0.5, 0, 0.5, 0.866025, 0, 2.8, 0)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(3.8, 0.2, 3.6)
material = SubResource("MatMaderaOscura")

[node name="Barricada1" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Asentamiento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 2.2, 0.55, 7.2)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(2.4, 1.1, 0.45)
material = SubResource("MatMaderaOscura")

[node name="Barricada2" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Asentamiento"]
transform = Transform3D(0, 0, 1, 0, 1, 0, -1, 0, 0, 6.8, 0.55, 3.8)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(2.2, 1.1, 0.45)
material = SubResource("MatMaderaOscura")

[node name="MuroPiedra" type="CSGBox3D" parent="NavigationRegion3D/Mundo/Asentamiento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -6.8, 0.65, 4.8)
use_collision = true
collision_layer = 5
collision_mask = 5
size = Vector3(5.5, 1.3, 0.55)
material = SubResource("MatPiedra")

[node name="GewehrMesa" parent="NavigationRegion3D/Mundo/Asentamiento" instance=ExtResource("9")]
transform = Transform3D(0.012, 0, 0, 0, 0.012, 0, 0, 0, 0.012, -4.8, 0.55, -1.2)

[node name="LuzFogata" type="OmniLight3D" parent="NavigationRegion3D/Mundo/Asentamiento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0.8, 1.2, 0.8)
light_color = Color(1, 0.62, 0.28, 1)
light_energy = 1.8
omni_range = 18.0
omni_attenuation = 1.25
shadow_enabled = false

[node name="LuzCabanaA" type="OmniLight3D" parent="NavigationRegion3D/Mundo/Asentamiento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -5.2, 1.8, -1.5)
light_color = Color(1, 0.78, 0.45, 1)
light_energy = 1.1
omni_range = 10.0
omni_attenuation = 1.4
shadow_enabled = false

[node name="LuzCalleNorte" type="OmniLight3D" parent="NavigationRegion3D/Mundo/Asentamiento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 2.4, -10)
light_color = Color(1, 0.92, 0.75, 1)
light_energy = 1.0
omni_range = 14.0
omni_attenuation = 1.3
shadow_enabled = false

[node name="LuzCalleEste" type="OmniLight3D" parent="NavigationRegion3D/Mundo/Asentamiento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 10, 2.4, 2)
light_color = Color(1, 0.92, 0.76, 1)
light_energy = 0.95
omni_range = 13.0
omni_attenuation = 1.3
shadow_enabled = false

[node name="LuzSpawn" type="OmniLight3D" parent="NavigationRegion3D/Mundo/Asentamiento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 2.0, 8)
light_color = Color(0.9, 0.94, 1, 1)
light_energy = 0.9
omni_range = 14.0
omni_attenuation = 1.35
shadow_enabled = false

[node name="LuzPies" type="OmniLight3D" parent="NavigationRegion3D/Mundo/Asentamiento"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 3.5, 2)
light_color = Color(0.95, 0.97, 1, 1)
light_energy = 1.2
omni_range = 22.0
omni_attenuation = 1.2
shadow_enabled = false

[node name="Enemies" type="Node3D" parent="."]

[node name="SpawnerNorte1" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 2, 0.6, -18)
item = ExtResource("6")
spawn_time = 2.8
max_items = 2

[node name="SpawnerNorte2" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -8, 0.6, -12)
item = ExtResource("6")
spawn_time = 3.0
max_items = 2

[node name="SpawnerEste" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 18, 0.6, 2)
item = ExtResource("6")
spawn_time = 3.4
max_items = 2

[node name="SpawnerOeste" parent="Enemies" instance=ExtResource("5")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -17, 0.6, 4)
item = ExtResource("6")
spawn_time = 3.8
max_items = 2
'''
open(out,'w',encoding='utf-8').write(scene)
print('ok', out)
