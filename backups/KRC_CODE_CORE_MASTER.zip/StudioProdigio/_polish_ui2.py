﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.tscn")
t = p.read_text(encoding="utf-8")

# add footstep audio ext_resource
if 'id="20"' not in t:
    t = t.replace('[gd_scene load_steps=32 format=3]', '[gd_scene load_steps=33 format=3]', 1)
    t = t.replace('[ext_resource type="AudioStream" path="res://sfx_kill.wav" id="19"]',
                  '[ext_resource type="AudioStream" path="res://sfx_kill.wav" id="19"]\n[ext_resource type="AudioStream" path="res://sfx_step.wav" id="20"]')

# add SfxStep player after SfxKill
if 'SfxStep' not in t:
    old = '[node name="SfxKill" type="AudioStreamPlayer" parent="Player"]\nstream = ExtResource("19")\nvolume_db = -5.0\n'
    new = old + '\n[node name="SfxStep" type="AudioStreamPlayer" parent="Player"]\nstream = ExtResource("20")\nvolume_db = -14.0\n'
    if old in t:
        t = t.replace(old, new)

# HUD polish
repls = [
('[node name="Status" type="Label" parent="UI"]\noffset_left = 16.0\noffset_top = 10.0\noffset_right = 900.0\noffset_bottom = 36.0\ntext = "Vida: 100/100 | Puntos: 0 | Bajas: 0"',
 '[node name="Status" type="Label" parent="UI"]\noffset_left = 18.0\noffset_top = 12.0\noffset_right = 1000.0\noffset_bottom = 38.0\ntheme_override_colors/font_color = Color(1, 1, 1, 1)\ntheme_override_colors/font_outline_color = Color(0, 0, 0, 1)\ntheme_override_constants/outline_size = 3\ntext = "Vida: 100/100 | Puntos: 0 | Bajas: 0"'),
('[node name="Label" type="Label" parent="UI"]\noffset_left = 16.0\noffset_top = 36.0\noffset_right = 1100.0\noffset_bottom = 62.0\ntext = "Arma"',
 '[node name="Label" type="Label" parent="UI"]\noffset_left = 18.0\noffset_top = 38.0\noffset_right = 1100.0\noffset_bottom = 64.0\ntheme_override_colors/font_color = Color(0.95, 0.97, 1, 1)\ntheme_override_colors/font_outline_color = Color(0, 0, 0, 1)\ntheme_override_constants/outline_size = 3\ntext = "Arma"'),
('[node name="Msg" type="Label" parent="UI"]\noffset_left = 16.0\noffset_top = 92.0\noffset_right = 900.0\noffset_bottom = 120.0\ntext = ""',
 '[node name="Msg" type="Label" parent="UI"]\noffset_left = 18.0\noffset_top = 92.0\noffset_right = 900.0\noffset_bottom = 122.0\ntheme_override_colors/font_color = Color(1, 0.95, 0.7, 1)\ntheme_override_colors/font_outline_color = Color(0, 0, 0, 1)\ntheme_override_constants/outline_size = 3\ntext = ""'),
]
for a,b in repls:
    if a in t: t = t.replace(a,b)

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
