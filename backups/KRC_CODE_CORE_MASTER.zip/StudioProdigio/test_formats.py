import sys, json, time
from pathlib import Path
sys.path.insert(0, r"C:\Users\kevin\StudioProdigio")

STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
EPISODES_DIR = STUDIO / "tv_episodes" / "El_Chavo_del_8"
EPISODES_DIR.mkdir(parents=True, exist_ok=True)

import yt_dlp

PLAYLIST_URL = "https://www.youtube.com/playlist?list=PLuxcLq9n25BEINVPnsS419gD8E6WSeiS-"

opts = {"extract_flat": True, "quiet": True}
with yt_dlp.YoutubeDL(opts) as ydl:
    info = ydl.extract_info(PLAYLIST_URL, download=False)
entries = info.get("entries", [])
print(f"Playlist has {len(entries)} entries")

# Try to download first 5 with no format (default)
downloaded = 0
for i, entry in enumerate(entries[:5], 1):
    vid_id = entry.get("id", "")
    title = entry.get("title", f"Episodio {i}")
    if not vid_id:
        continue

    mp4 = EPISODES_DIR / f"{vid_id}.mp4"
    if mp4.exists() and mp4.stat().st_size > 100_000:
        print(f"[{i}/5] SKIP: {title[:50]}")
        downloaded += 1
        continue

    print(f"[{i}/5] Trying: {title[:50]}...")
    # Try with no format specified (default best)
    for fmt in [None, "best", "18", "22", "worst"]:
        dl_opts = {
            "outtmpl": str(EPISODES_DIR / f"{vid_id}.%(ext)s"),
            "merge_output_format": "mp4",
            "quiet": True,
            "no_warnings": True,
            "socket_timeout": 30,
        }
        if fmt:
            dl_opts["format"] = fmt
        try:
            with yt_dlp.YoutubeDL(dl_opts) as ydl:
                ydl.download([f"https://www.youtube.com/watch?v={vid_id}"])
            if mp4.exists() and mp4.stat().st_size > 100_000:
                size_mb = mp4.stat().st_size / (1024*1024)
                print(f"  OK ({size_mb:.1f}MB) fmt={fmt or 'default'}")
                downloaded += 1
                break
        except Exception as e:
            err = str(e)[:80]
            if "format" in err.lower():
                continue
            else:
                print(f"  ERR: {err}")
                break
    else:
        print(f"  FAILED all formats")

    time.sleep(1)

print(f"\nDescargados: {downloaded}/5")
# List formats for first video to debug
print("\n=== Listing formats for first video ===")
try:
    with yt_dlp.YoutubeDL({"quiet": True}) as ydl:
        info = ydl.extract_info(f"https://www.youtube.com/watch?v={entries[0]['id']}", download=False)
    formats = info.get("formats", [])
    print(f"Available formats: {len(formats)}")
    for f in formats[:10]:
        print(f"  {f.get('format_id','?')} - {f.get('ext','?')} - {f.get('resolution','?')} - {f.get('filesize',0)//1024 if f.get('filesize') else '?'}KB")
except Exception as e:
    print(f"Error: {e}")
