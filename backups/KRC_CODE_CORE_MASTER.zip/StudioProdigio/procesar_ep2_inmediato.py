import subprocess
from pathlib import Path

FFMPEG = r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe"
STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
RAW = STUDIO / "episodes_raw" / "ep02_ywuNZ6gpwsc.mp4"
TEMP = STUDIO / "tv_temp"
EN_COLA = Path(r"C:\Users\kevin\Desktop\KABALION TV\EN_COLA")
LOGO = STUDIO / "assets/logo/logo_krc_transparent.png"
INTRO = STUDIO / "assets/intro/intro_oficial.mp4"
OUTRO = STUDIO / "assets/outro/outro_oficial.mp4"

norm_ep2 = TEMP / "norm_ep02.mp4"
out_final = EN_COLA / "0002_Chavo_Del_8_Ep2_KRC.mp4"

print("1. Normalizando ep02 con Logo KRC...")
logo_filter = (
    "[0:v]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=30[base];"
    "[1:v]scale=140:140,format=rgba,fade=t=in:st=2:d=1:alpha=1,fade=t=out:st=55:d=1:alpha=1[logo];"
    "[base][logo]overlay=W-w-20:H-h-30[v]"
)

cmd1 = [
    FFMPEG, "-y", "-i", str(RAW), "-i", str(LOGO),
    "-filter_complex", logo_filter, "-map", "[v]", "-map", "0:a",
    "-c:v", "libx264", "-preset", "veryfast", "-b:v", "2000k",
    "-c:a", "aac", "-ar", "44100", "-ac", "2", "-b:a", "160k",
    str(norm_ep2)
]
subprocess.run(cmd1, check=True)

print("2. Ensamblando con Intro y Outro...")
intro_n = TEMP / "_a_intro_oficial.mp4"
outro_n = TEMP / "_a_outro_oficial.mp4"

c_file = TEMP / "concat_ep2.txt"
with open(c_file, "w", encoding="utf-8") as f:
    f.write(f"file '{intro_n.as_posix()}'\n")
    f.write(f"file '{norm_ep2.as_posix()}'\n")
    f.write(f"file '{outro_n.as_posix()}'\n")

cmd2 = [
    FFMPEG, "-y", "-f", "concat", "-safe", "0", "-i", str(c_file),
    "-c", "copy", str(out_final)
]
subprocess.run(cmd2, check=True)
print(f"EXITO: Episodio 2 listo en cola -> {out_final.name}")
