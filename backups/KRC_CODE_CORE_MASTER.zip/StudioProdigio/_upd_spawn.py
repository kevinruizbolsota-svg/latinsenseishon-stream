﻿from pathlib import Path
zt = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\zombie_spawn.tscn")
zcode = r'''[gd_scene load_steps=5 format=3]

[ext_resource type="Script" path="res://zombie.gd" id="1"]
[ext_resource type="PackedScene" path="res://demonio_pintado.glb" id="2"]

[sub_resource type="CapsuleShape3D" id="ZombieShape"]
radius = 0.45
height = 1.8

[sub_resource type="StandardMaterial3D" id="MatZombieFallback"]
albedo_color = Color(0.22, 0.38, 0.2, 1)
roughness = 0.9

[node name="Zombie" type="CharacterBody3D"]
script = ExtResource("1")

[node name="CollisionShape3D" type="CollisionShape3D" parent="."]
shape = SubResource("ZombieShape")

[node name="Cuerpo" type="CSGCylinder3D" parent="."]
visible = false
radius = 0.4
height = 1.5
material = SubResource("MatZombieFallback")

[node name="Cabeza" type="CSGSphere3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.0, 0)
visible = false
radius = 0.28
material = SubResource("MatZombieFallback")

[node name="Modelo" parent="." instance=ExtResource("2")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.9, 0)
'''
zt.write_text(zcode, encoding='utf-8', newline='\n')
print("ok")
