﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.tscn")
t = p.read_text(encoding="utf-8")

# add footstep audio ext_resource
t = t.replace('[gd_scene load_steps=32 format=3]', '[gd_scene load_steps=33 format=3]', 1)
t = t.replace('[ext_resource type="AudioStream" path="res://sfx_kill.wav" id="19"]',
              '[ext_resource type="AudioStream" path="res://sfx_kill.wav" id="19"]\n[ext_resource type="AudioStream" path="res://sfx_step.wav" id="20"]')

# add SfxStep player after SfxKill
t = t.replace(r'''[node name="SfxKill" type="AudioStreamPlayer" parent="Player"]
stream = ExtResource("19")
volume_db = -5.0
''',
r'''[node name="SfxKill" type="AudioStreamPlayer" parent="Player"]
stream = ExtResource("19")
volume_db = -5.0

[node name="SfxStep" type="AudioStreamPlayer" parent="Player"]
stream = ExtResource("20")
volume_db = -14.0
''')

# HUD polish: make status/labels more visible
t = t.replace(r'[node name="Status" type="Label" parent="UI"]
offset_left = 16.0
offset_top = 10.0
offset_right = 900.0
offset_bottom = 36.0
text = "Vida: 100/100 | Puntos: 0 | Bajas: 0"',
r'[node name="Status" type="Label" parent="UI"]
offset_left = 18.0
offset_top = 12.0
offset_right = 1000.0
offset_bottom = 38.0
theme_override_colors/font_color = Color(1, 1, 1, 1)
theme_override_colors/font_outline_color = Color(0, 0, 0, 1)
theme_override_constants/outline_size = 3
text = "Vida: 100/100 | Puntos: 0 | Bajas: 0"')

t = t.replace(r'[node name="Label" type="Label" parent="UI"]
offset_left = 16.0
offset_top = 36.0
offset_right = 1100.0
offset_bottom = 62.0
text = "Arma"',
r'[node name="Label" type="Label" parent="UI"]
offset_left = 18.0
offset_top = 38.0
offset_right = 1100.0
offset_bottom = 64.0
theme_override_colors/font_color = Color(0.95, 0.97, 1, 1)
theme_override_colors/font_outline_color = Color(0, 0, 0, 1)
theme_override_constants/outline_size = 3
text = "Arma"')

t = t.replace(r'[node name="Msg" type="Label" parent="UI"]
offset_left = 16.0
offset_top = 92.0
offset_right = 900.0
offset_bottom = 120.0
text = ""',
r'[node name="Msg" type="Label" parent="UI"]
offset_left = 18.0
offset_top = 92.0
offset_right = 900.0
offset_bottom = 122.0
theme_override_colors/font_color = Color(1, 0.95, 0.7, 1)
theme_override_colors/font_outline_color = Color(0, 0, 0, 1)
theme_override_constants/outline_size = 3
text = ""')

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
