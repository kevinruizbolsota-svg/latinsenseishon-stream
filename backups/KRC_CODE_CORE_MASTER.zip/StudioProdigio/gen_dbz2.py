import sys, os
sys.path.insert(0, r"C:\Users\kevin\StudioProdigio")
os.chdir(r"C:\Users\kevin\StudioProdigio")
exec(open('video_factory.py').read().split('if __name__')[0])

# Use Groq for guion (Gemini is rate-limited)
import urllib.request, json
def call_groq_local(prompt, system=None):
    url = "https://api.groq.com/openai/v1/chat/completions"
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    payload = {"model": "llama-3.3-70b-versatile", "messages": messages, "max_tokens": 1024}
    import os
    key = os.environ.get("GROQ_API_KEY", "")
    req = urllib.request.Request(url, data=json.dumps(payload).encode(),
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"})
    try:
        resp = urllib.request.urlopen(req, timeout=30)
        data = json.loads(resp.read())
        return data["choices"][0]["message"]["content"]
    except Exception as e:
        return f"Error: {e}"

# Temporarily replace call_gemini with call_groq_local
import video_factory as vf
vf.call_gemini = call_groq_local

# Generate DBZ episodes with MoviePy (no text rendering issues)
episodes = [
    "Dragon Ball Z Frieza Saga Episode 1: Goku arrives on Namek",
    "Dragon Ball Z Frieza Saga Episode 2: Battle with Frieza elite soldiers",
    "Dragon Ball Z Frieza Saga Episode 3: Goku vs Frieza begins",
]

for i, prompt in enumerate(episodes, 1):
    print(f"\n=== Generating DBZ Episode {i} ===")
    result = vf.generate_moviepy_video(prompt, 10, "anime")
    print(f"Result: {result}")
    if result:
        import shutil
        from pathlib import Path
        src = Path(result)
        dst = Path(r"C:\Users\kevin\StudioProdigio\dbz_to_play") / f"dbz_ep{i:02d}.mp4"
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(str(src), str(dst))
        print(f"Copied to: {dst}")
