﻿from pathlib import Path
# Build a clear, visible forest scene using downloaded forest.glb
out = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.tscn")
scene = r'''[gd_scene load_steps=30 format=3]

[ext_resource type="Script" path="res://player.gd" id="1"]
[ext_resource type="Script" path="res://zombie.gd" id="2"]
[ext_resource type="Script" path="res://barricade.gd" id="3"]
[ext_resource type="PackedScene" path="res://gewehr.glb" id="4"]
[ext_resource type="PackedScene" path="res://demonio_pintado.glb" id="5"]
[ext_resource type="Texture2D" path="res://madera.jpg" id="6"]
[ext_resource type="PackedScene" path="res://forest.glb" id="7"]
[ext_resource type="PackedScene" path="res://dragon_nemesis.glb" id="10"]
[ext_resource type="Script" path="res://main.gd" id="12"]
[ext_resource type="AudioStream" path="res://sfx_shot.wav" id="13"]
[ext_resource type="AudioStream" path="res://sfx_shot_fast.wav" id="14"]
[ext_resource type="AudioStream" path="res://sfx_reload.wav" id="15"]
[ext_resource type="AudioStream" path="res://sfx_hit.wav" id="16"]
[ext_resource type="AudioStream" path="res://sfx_empty.wav" id="17"]
[ext_resource type="AudioStream" path="res://sfx_hurt.wav" id="18"]
[ext_resource type="AudioStream" path="res://sfx_kill.wav" id="19"]
[ext_resource type="AudioStream" path="res://sfx_step.wav" id="20"]

[sub_resource type="ProceduralSkyMaterial" id="SkyMat"]
sky_top_color = Color(0.35, 0.55, 0.85, 1)
sky_horizon_color = Color(0.6, 0.72, 0.82, 1)
ground_bottom_color = Color(0.15, 0.2, 0.12, 1)
ground_horizon_color = Color(0.35, 0.42, 0.3, 1)

[sub_resource type="Sky" id="Sky1"]
sky_material = SubResource("SkyMat")

[sub_resource type="Environment" id="Env1"]
background_mode = 2
sky = SubResource("Sky1")
ambient_light_source = 2
ambient_light_color = Color(0.7, 0.78, 0.9, 1)
ambient_light_energy = 1.0
tonemap_mode = 2
tonemap_exposure = 1.05
glow_enabled = false
fog_enabled = true
fog_light_color = Color(0.55, 0.65, 0.7, 1)
fog_light_energy = 0.8
fog_density = 0.003
fog_aerial_perspective = 0.25
volumetric_fog_enabled = false

[sub_resource type="StandardMaterial3D" id="MatSuelo"]
albedo_color = Color(0.28, 0.35, 0.22, 1)
roughness = 1.0

[sub_resource type="StandardMaterial3D" id="MatMadera"]
albedo_texture = ExtResource("6")
albedo_color = Color(0.7, 0.55, 0.35, 1)
uv1_scale = Vector3(2, 2, 1)
roughness = 0.82

[sub_resource type="StandardMaterial3D" id="MatArma"]
albedo_color = Color(0.18, 0.18, 0.2, 1)
metallic = 0.3
roughness = 0.45

[sub_resource type="StandardMaterial3D" id="MatPared"]
albedo_color = Color(0.5, 0.48, 0.44, 1)
roughness = 0.85

[sub_resource type="StandardMaterial3D" id="MatZombieFallback"]
albedo_color = Color(0.22, 0.38, 0.2, 1)
roughness = 0.9

[sub_resource type="CapsuleShape3D" id="PlayerShape"]
radius = 0.4
height = 1.8

[sub_resource type="CapsuleShape3D" id="ZombieShape"]
radius = 0.45
height = 1.8

[sub_resource type="BoxShape3D" id="BarricadeShape"]
size = Vector3(1.9, 2.0, 0.25)

[node name="Main" type="Node3D"]
script = ExtResource("12")

[node name="WorldEnvironment" type="WorldEnvironment" parent="."]
environment = SubResource("Env1")

[node name="Sol" type="DirectionalLight3D" parent="."]
transform = Transform3D(0.866025, -0.353553, 0.353553, 0, 0.707107, 0.707107, -0.5, -0.612372, 0.612372, 0, 50, 0)
light_energy = 1.3
shadow_enabled = false

[node name="Relleno" type="DirectionalLight3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 0.4, 0.916515, 0, -0.916515, 0.4, 0, 20, 0)
light_color = Color(0.8, 0.85, 0.95, 1)
light_energy = 0.35
shadow_enabled = false

[node name="MapaBosque" parent="." instance=ExtResource("7")]

[node name="SueloColision" type="CSGBox3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.5, 0)
use_collision = true
size = Vector3(400, 1, 400)
material = SubResource("MatSuelo")

[node name="ZonaJuego" type="Node3D" parent="."]

[node name="Refugio" type="Node3D" parent="ZonaJuego"]

[node name="Piso" type="CSGBox3D" parent="ZonaJuego/Refugio"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.05, 0)
use_collision = true
size = Vector3(12, 0.1, 10)
material = SubResource("MatPared")

[node name="ParedN" type="CSGBox3D" parent="ZonaJuego/Refugio"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.5, -5)
use_collision = true
size = Vector3(12, 3, 0.3)
material = SubResource("MatPared")

[node name="ParedS" type="CSGBox3D" parent="ZonaJuego/Refugio"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.5, 5)
use_collision = true
size = Vector3(12, 3, 0.3)
material = SubResource("MatPared")

[node name="ParedO" type="CSGBox3D" parent="ZonaJuego/Refugio"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -6, 1.5, 0)
use_collision = true
size = Vector3(0.3, 3, 10)
material = SubResource("MatPared")

[node name="ParedE" type="CSGBox3D" parent="ZonaJuego/Refugio"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 6, 1.5, 0)
use_collision = true
size = Vector3(0.3, 3, 10)
material = SubResource("MatPared")

[node name="Barricadas" type="Node3D" parent="."]

[node name="Barricada1" type="Node3D" parent="Barricadas"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -2, 0.9, -5)
script = ExtResource("3")
[node name="Blocker" type="StaticBody3D" parent="Barricadas/Barricada1"]
[node name="CollisionShape3D" type="CollisionShape3D" parent="Barricadas/Barricada1/Blocker"]
shape = SubResource("BarricadeShape")
[node name="Board1" type="CSGBox3D" parent="Barricadas/Barricada1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.25, 0)
size = Vector3(1.8, 0.18, 0.08)
material = SubResource("MatMadera")
[node name="Board2" type="CSGBox3D" parent="Barricadas/Barricada1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.53, 0)
size = Vector3(1.8, 0.18, 0.08)
material = SubResource("MatMadera")
[node name="Board3" type="CSGBox3D" parent="Barricadas/Barricada1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.81, 0)
size = Vector3(1.8, 0.18, 0.08)
material = SubResource("MatMadera")
[node name="Board4" type="CSGBox3D" parent="Barricadas/Barricada1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.09, 0)
size = Vector3(1.8, 0.18, 0.08)
material = SubResource("MatMadera")
[node name="Board5" type="CSGBox3D" parent="Barricadas/Barricada1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.37, 0)
size = Vector3(1.8, 0.18, 0.08)
material = SubResource("MatMadera")
[node name="Board6" type="CSGBox3D" parent="Barricadas/Barricada1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.65, 0)
size = Vector3(1.8, 0.18, 0.08)
material = SubResource("MatMadera")

[node name="Barricada2" type="Node3D" parent="Barricadas"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 2, 0.9, 5)
script = ExtResource("3")
[node name="Blocker" type="StaticBody3D" parent="Barricadas/Barricada2"]
[node name="CollisionShape3D" type="CollisionShape3D" parent="Barricadas/Barricada2/Blocker"]
shape = SubResource("BarricadeShape")
[node name="Board1" type="CSGBox3D" parent="Barricadas/Barricada2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.25, 0)
size = Vector3(1.8, 0.18, 0.08)
material = SubResource("MatMadera")
[node name="Board2" type="CSGBox3D" parent="Barricadas/Barricada2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.53, 0)
size = Vector3(1.8, 0.18, 0.08)
material = SubResource("MatMadera")
[node name="Board3" type="CSGBox3D" parent="Barricadas/Barricada2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.81, 0)
size = Vector3(1.8, 0.18, 0.08)
material = SubResource("MatMadera")
[node name="Board4" type="CSGBox3D" parent="Barricadas/Barricada2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.09, 0)
size = Vector3(1.8, 0.18, 0.08)
material = SubResource("MatMadera")
[node name="Board5" type="CSGBox3D" parent="Barricadas/Barricada2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.37, 0)
size = Vector3(1.8, 0.18, 0.08)
material = SubResource("MatMadera")
[node name="Board6" type="CSGBox3D" parent="Barricadas/Barricada2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.65, 0)
size = Vector3(1.8, 0.18, 0.08)
material = SubResource("MatMadera")

[node name="Player" type="CharacterBody3D" parent="." groups=["player"]]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.2, 0)
script = ExtResource("1")

[node name="CollisionShape3D" type="CollisionShape3D" parent="Player"]
shape = SubResource("PlayerShape")

[node name="Camera3D" type="Camera3D" parent="Player"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.6, 0)
current = true
fov = 75.0

[node name="RayCast3D" type="RayCast3D" parent="Player/Camera3D"]
target_position = Vector3(0, 0, -80)
enabled = true

[node name="WeaponHolder" type="Node3D" parent="Player/Camera3D"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0.25, -0.25, -0.55)

[node name="W1" type="Node3D" parent="Player/Camera3D/WeaponHolder"]
[node name="Modelo" parent="Player/Camera3D/WeaponHolder/W1" instance=ExtResource("4")]
transform = Transform3D(0.9, 0, 0, 0, 0.9, 0, 0, 0, 0.9, 0, -0.08, -0.05)
[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.03, -0.2)
size = Vector3(0.055, 0.07, 0.45)
material = SubResource("MatArma")
[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.0, -0.5)
size = Vector3(0.025, 0.025, 0.3)
material = SubResource("MatArma")

[node name="W2" type="Node3D" parent="Player/Camera3D/WeaponHolder"]
visible = false
[node name="Modelo" parent="Player/Camera3D/WeaponHolder/W2" instance=ExtResource("4")]
transform = Transform3D(0.85, 0, 0, 0, 0.85, 0, 0, 0, 0.85, 0, -0.08, -0.05)
[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.02, -0.16)
size = Vector3(0.05, 0.065, 0.38)
material = SubResource("MatArma")
[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.0, -0.42)
size = Vector3(0.022, 0.022, 0.26)
material = SubResource("MatArma")

[node name="W3" type="Node3D" parent="Player/Camera3D/WeaponHolder"]
visible = false
[node name="Modelo" parent="Player/Camera3D/WeaponHolder/W3" instance=ExtResource("4")]
transform = Transform3D(1.0, 0, 0, 0, 1.0, 0, 0, 0, 1.0, 0, -0.09, -0.06)
[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.03, -0.22)
size = Vector3(0.06, 0.075, 0.5)
material = SubResource("MatArma")
[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.0, -0.56)
size = Vector3(0.028, 0.028, 0.32)
material = SubResource("MatArma")

[node name="MuzzleFlash" type="OmniLight3D" parent="Player/Camera3D"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0.22, -0.18, -1.05)
visible = false
light_color = Color(1, 0.85, 0.45, 1)
light_energy = 3.0
omni_range = 4.5

[node name="SfxShot" type="AudioStreamPlayer" parent="Player"]
stream = ExtResource("13")
volume_db = -6.0
[node name="SfxShotFast" type="AudioStreamPlayer" parent="Player"]
stream = ExtResource("14")
volume_db = -7.0
[node name="SfxReload" type="AudioStreamPlayer" parent="Player"]
stream = ExtResource("15")
volume_db = -4.0
[node name="SfxHit" type="AudioStreamPlayer" parent="Player"]
stream = ExtResource("16")
volume_db = -5.0
[node name="SfxEmpty" type="AudioStreamPlayer" parent="Player"]
stream = ExtResource("17")
volume_db = -6.0
[node name="SfxHurt" type="AudioStreamPlayer" parent="Player"]
stream = ExtResource("18")
volume_db = -4.0
[node name="SfxKill" type="AudioStreamPlayer" parent="Player"]
stream = ExtResource("19")
volume_db = -5.0
[node name="SfxStep" type="AudioStreamPlayer" parent="Player"]
stream = ExtResource("20")
volume_db = -14.0

[node name="UI" type="CanvasLayer" parent="."]
[node name="HitFlash" type="ColorRect" parent="UI"]
anchors_preset = 15
anchor_right = 1.0
anchor_bottom = 1.0
grow_horizontal = 2
grow_vertical = 2
color = Color(0.7, 0, 0, 0)
mouse_filter = 2
[node name="Status" type="Label" parent="UI"]
offset_left = 18.0
offset_top = 12.0
offset_right = 1000.0
offset_bottom = 38.0
theme_override_colors/font_color = Color(1, 1, 1, 1)
theme_override_colors/font_outline_color = Color(0, 0, 0, 1)
theme_override_constants/outline_size = 3
text = "Vida: 100/100 | Puntos: 0 | Bajas: 0"
[node name="Label" type="Label" parent="UI"]
offset_left = 18.0
offset_top = 38.0
offset_right = 1100.0
offset_bottom = 64.0
theme_override_colors/font_color = Color(0.95, 0.97, 1, 1)
theme_override_colors/font_outline_color = Color(0, 0, 0, 1)
theme_override_constants/outline_size = 3
text = "Arma"
[node name="Hint" type="Label" parent="UI"]
offset_left = 18.0
offset_top = 62.0
offset_right = 900.0
offset_bottom = 88.0
text = ""
[node name="Msg" type="Label" parent="UI"]
offset_left = 18.0
offset_top = 92.0
offset_right = 900.0
offset_bottom = 122.0
theme_override_colors/font_color = Color(1, 0.95, 0.7, 1)
theme_override_colors/font_outline_color = Color(0, 0, 0, 1)
theme_override_constants/outline_size = 3
text = ""
[node name="Mira" type="Label" parent="UI"]
anchors_preset = 8
anchor_left = 0.5
anchor_top = 0.5
anchor_right = 0.5
anchor_bottom = 0.5
offset_left = -10.0
offset_top = -12.0
offset_right = 10.0
offset_bottom = 12.0
text = "+"
horizontal_alignment = 1
vertical_alignment = 1
[node name="HitMarker" type="Label" parent="UI"]
anchors_preset = 8
anchor_left = 0.5
anchor_top = 0.5
anchor_right = 0.5
anchor_bottom = 0.5
offset_left = -20.0
offset_top = -22.0
offset_right = 20.0
offset_bottom = 22.0
theme_override_colors/font_color = Color(1, 0.9, 0.9, 1)
text = ""
horizontal_alignment = 1
vertical_alignment = 1
[node name="RondaAnuncio" type="Label" parent="UI"]
anchors_preset = 5
anchor_left = 0.5
anchor_right = 0.5
offset_left = -300.0
offset_top = 140.0
offset_right = 300.0
offset_bottom = 190.0
theme_override_colors/font_color = Color(1, 0.92, 0.7, 1)
theme_override_colors/font_outline_color = Color(0, 0, 0, 1)
theme_override_constants/outline_size = 4
theme_override_font_sizes/font_size = 30
text = ""
horizontal_alignment = 1
[node name="MenuInicio" type="ColorRect" parent="UI"]
process_mode = 3
anchors_preset = 15
anchor_right = 1.0
anchor_bottom = 1.0
grow_horizontal = 2
grow_vertical = 2
color = Color(0.02, 0.03, 0.05, 0.92)
[node name="Titulo" type="Label" parent="UI/MenuInicio"]
anchors_preset = 5
anchor_left = 0.5
anchor_right = 0.5
offset_left = -300.0
offset_top = 180.0
offset_right = 300.0
offset_bottom = 240.0
theme_override_font_sizes/font_size = 44
text = "COLWAR - BOSQUE"
horizontal_alignment = 1
[node name="Sub" type="Label" parent="UI/MenuInicio"]
anchors_preset = 5
anchor_left = 0.5
anchor_right = 0.5
offset_left = -320.0
offset_top = 250.0
offset_right = 320.0
offset_bottom = 320.0
text = "Mapa: forest.glb (descargado). Defiende, repara, sobrevive."
horizontal_alignment = 1
[node name="Iniciar" type="Label" parent="UI/MenuInicio"]
anchors_preset = 5
anchor_left = 0.5
anchor_right = 0.5
offset_left = -260.0
offset_top = 360.0
offset_right = 260.0
offset_bottom = 400.0
text = "Presiona ENTER para jugar"
horizontal_alignment = 1
[node name="Controles" type="Label" parent="UI/MenuInicio"]
anchors_preset = 5
anchor_left = 0.5
anchor_right = 0.5
offset_left = -360.0
offset_top = 430.0
offset_right = 360.0
offset_bottom = 520.0
text = "WASD mover | Mouse mirar | Click disparar | 1/2/3 armas | R recargar | E/F reparar | ESC pausa"
horizontal_alignment = 1
[node name="Pausa" type="ColorRect" parent="UI"]
process_mode = 3
visible = false
anchors_preset = 15
anchor_right = 1.0
anchor_bottom = 1.0
grow_horizontal = 2
grow_vertical = 2
color = Color(0, 0, 0, 0.55)
[node name="Txt" type="Label" parent="UI/Pausa"]
anchors_preset = 8
anchor_left = 0.5
anchor_top = 0.5
anchor_right = 0.5
anchor_bottom = 0.5
offset_left = -200.0
offset_top = -40.0
offset_right = 200.0
offset_bottom = 40.0
theme_override_font_sizes/font_size = 32
text = "PAUSA\nESC continuar | ENTER reiniciar"
horizontal_alignment = 1
vertical_alignment = 1

[node name="Zombie1" type="CharacterBody3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 12, 1.0, 10)
script = ExtResource("2")
[node name="CollisionShape3D" type="CollisionShape3D" parent="Zombie1"]
shape = SubResource("ZombieShape")
[node name="Cuerpo" type="CSGCylinder3D" parent="Zombie1"]
radius = 0.35
height = 1.3
material = SubResource("MatZombieFallback")
[node name="Cabeza" type="CSGSphere3D" parent="Zombie1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.95, 0)
radius = 0.26
material = SubResource("MatZombieFallback")
[node name="Modelo" parent="Zombie1" instance=ExtResource("5")]
transform = Transform3D(0.6, 0, 0, 0, 0.6, 0, 0, 0, 0.6, 0, -0.7, 0)

[node name="Zombie2" type="CharacterBody3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -14, 1.0, 8)
script = ExtResource("2")
[node name="CollisionShape3D" type="CollisionShape3D" parent="Zombie2"]
shape = SubResource("ZombieShape")
[node name="Cuerpo" type="CSGCylinder3D" parent="Zombie2"]
radius = 0.35
height = 1.3
material = SubResource("MatZombieFallback")
[node name="Cabeza" type="CSGSphere3D" parent="Zombie2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.95, 0)
radius = 0.26
material = SubResource("MatZombieFallback")
[node name="Modelo" parent="Zombie2" instance=ExtResource("10")]
transform = Transform3D(0.6, 0, 0, 0, 0.6, 0, 0, 0, 0.6, 0, -0.7, 0)

[node name="Zombie3" type="CharacterBody3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 5, 1.0, -16)
script = ExtResource("2")
[node name="CollisionShape3D" type="CollisionShape3D" parent="Zombie3"]
shape = SubResource("ZombieShape")
[node name="Cuerpo" type="CSGCylinder3D" parent="Zombie3"]
radius = 0.35
height = 1.3
material = SubResource("MatZombieFallback")
[node name="Cabeza" type="CSGSphere3D" parent="Zombie3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.95, 0)
radius = 0.26
material = SubResource("MatZombieFallback")
[node name="Modelo" parent="Zombie3" instance=ExtResource("5")]
transform = Transform3D(0.6, 0, 0, 0, 0.6, 0, 0, 0, 0.6, 0, -0.7, 0)

[node name="Zombie4" type="CharacterBody3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -8, 1.0, -18)
script = ExtResource("2")
[node name="CollisionShape3D" type="CollisionShape3D" parent="Zombie4"]
shape = SubResource("ZombieShape")
[node name="Cuerpo" type="CSGCylinder3D" parent="Zombie4"]
radius = 0.35
height = 1.3
material = SubResource("MatZombieFallback")
[node name="Cabeza" type="CSGSphere3D" parent="Zombie4"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.95, 0)
radius = 0.26
material = SubResource("MatZombieFallback")
[node name="Modelo" parent="Zombie4" instance=ExtResource("10")]
transform = Transform3D(0.6, 0, 0, 0, 0.6, 0, 0, 0, 0.6, 0, -0.7, 0)
'''
out.write_text(scene, encoding='utf-8', newline='\n')
print('ok')
