"""
Compilar Chavo Animado para streaming
"""
import sys
sys.path.insert(0, r"C:\Users\kevin\StudioProdigio")
from catalogo_tv import CATALOGO_SERIES
from kabalion_tv_engine import compilar_programa_tv

# Chavo Animado es el segundo de cartoon_network
chavo_animado = [CATALOGO_SERIES["cartoon_network"][1]]  # El Chavo Animado
print(f"Compilando: {chavo_animado[0]['titulo']}")
print(f"Playlist: {chavo_animado[0]['playlist']}")

out = compilar_programa_tv(chavo_animado, "MARATON_Chavo_Animado_KRC", ep_por_serie=3)
if out:
    print(f"\nVideo compilado: {out}")
else:
    print("\nCompilacion fallida")
