﻿from pathlib import Path
# small polish: ensure main scene visual consistency, cap max alive zombies in spawn logic for performance
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.gd")
t = p.read_text(encoding="utf-8")

# avoid too many zombies at once for performance
old_spawn = r'''func _spawn_one():
	if to_spawn <= 0 or _scenes.is_empty():
		to_spawn = 0
		return'''
new_spawn = r'''func _spawn_one():
	if to_spawn <= 0 or _scenes.is_empty():
		to_spawn = 0
		return
	var alive = get_tree().get_nodes_in_group("zombie").size()
	if alive >= 18:
		_spawn_timer = 0.5
		return'''
if old_spawn in t:
    t = t.replace(old_spawn, new_spawn)

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
