const fs = require('fs');
const dir = 'C:/Users/kevin/Desktop/VIDEOS_PUBLICADOS_Y_LISTOS';
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

const srcShort = 'C:/Users/kevin/Desktop/Carpeta de videos para transformar y publicar/SHORT PARA TIKTOK/SHORT_01_CHAVO_AGUAS_FRESCAS_VIRAL.mp4';
const srcThumb = 'C:/Users/kevin/Desktop/Carpeta de videos para transformar y publicar/SHORT PARA TIKTOK/PORTADA_VIRAL_KRC.jpg';

fs.copyFileSync(srcShort, dir + '/1_TIKTOK_INSTA_Short_Chavo_AguasFrescas.mp4');
fs.copyFileSync(srcThumb, dir + '/1_PORTADA_OFICIAL_KRC.jpg');

const copy = `👑 PUBLICACIÓN LISTA PARA TIKTOK, INSTAGRAM REELS Y FACEBOOK
----------------------------------------------------------------------
TÍTULO:
¡No contaban con mi astucia! 😂 Aguas Frescas del Chavo #ElChavoDel8 #KRC

DESCRIPCIÓN & COPY:
Parece de limón, sabe a tamarindo, pero es de jamaica 😭😂 
¡El Chavo revolucionó el emprendimiento antes de que existiera! 👑✨

¿Cuál era tu favorita? Déjamelo en los comentarios 👇

HASHTAGS:
#ElChavoDel8 #HumorLatino #Comedia #RememberLuxury #KRC #Nostalgia #ViralReels #TikTokHumor
----------------------------------------------------------------------`;

fs.writeFileSync(dir + '/TEXTO_Y_HASHTAGS_PARA_COPIAR.txt', copy, 'utf8');
console.log('Carpeta preparada al 100% en el Escritorio');
