"""
COMPILADOR MAESTRO KRC — IA de Producción Automática
========================================================
Toma todos los capítulos de SERIES_PENDIENTES (o dbz_to_play),
les quita marcas de agua externas, les pone el logo KRC,
los une en 1 solo video largo (6-8h) y lo deja listo en VIDEOS_COMPILADOS_STREAM.
N8N llama a este script cuando detecta trabajo pendiente.

USO:
  python compilador_maestro.py --serie "Dragon Ball Z" --input "C:/ruta" --output "C:/ruta"
  python compilador_maestro.py  (usa defaults)
"""

import sys, json, subprocess, shutil, argparse, re
from pathlib import Path
from datetime import datetime

FFMPEG  = Path(r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe")
STUDIO  = Path(r"C:\Users\kevin\StudioProdigio")
LOGO    = STUDIO / "assets" / "logo" / "Koyal-Photoroom.png"

DEFAULT_INPUT  = STUDIO / "SERIES_PENDIENTES"
DEFAULT_OUTPUT = STUDIO / "VIDEOS_COMPILADOS_STREAM"
STREAM_QUEUE   = STUDIO / "dbz_to_play"
FINALIZADOS    = STUDIO / "CAPITULOS_ESTRENADOS_PARA_SUBIR"
TEMP           = STUDIO / "video_temp"
LOG_FILE       = STUDIO / "compilador_maestro.log"

for d in [DEFAULT_OUTPUT, TEMP, FINALIZADOS, STREAM_QUEUE]:
    d.mkdir(parents=True, exist_ok=True)

def log(msg):
    ts = datetime.now().strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass

def ff(*args, check=False):
    cmd = [str(FFMPEG)] + list(args)
    r = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True, errors="ignore")
    if check and r.returncode != 0:
        log(f"  FFmpeg error: {r.stderr[-300:]}")
    return r.returncode == 0

def normalizar_capitulo(src: Path, dst: Path, logo_ok: bool) -> bool:
    """Normaliza 1 capítulo: 1280x720, 30fps, aac, logo KRC esquina inferior izquierda."""
    if dst.exists() and dst.stat().st_size > 5_000_000:
        log(f"  Ya normalizado: {dst.name}")
        return True

    log(f"  Procesando: {src.name}")

    if logo_ok:
        vf = (
            "[0:v]scale=1280:720:force_original_aspect_ratio=decrease,"
            "pad=1280:720:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30[bg];"
            "[1:v]scale=130:-1,format=rgba[lg];"
            "[bg][lg]overlay=14:H-h-14[v]"
        )
        ok = ff(
            "-y", "-i", str(src), "-i", str(LOGO),
            "-filter_complex", vf,
            "-map", "[v]", "-map", "0:a:0?",
            "-c:v", "libx264", "-preset", "fast", "-b:v", "2500k",
            "-c:a", "aac", "-b:a", "160k", "-ar", "44100", "-ac", "2",
            str(dst), check=True
        )
    else:
        ok = ff(
            "-y", "-i", str(src),
            "-vf", "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30",
            "-map", "0:v:0", "-map", "0:a:0?",
            "-c:v", "libx264", "-preset", "fast", "-b:v", "2500k",
            "-c:a", "aac", "-b:a", "160k", "-ar", "44100", "-ac", "2",
            str(dst), check=True
        )

    if not ok:
        log(f"  FALLO al procesar: {src.name}")
    return ok

def compilar_serie(input_dir: Path, output_dir: Path, nombre_serie: str) -> Path | None:
    capitulos = sorted([p for p in input_dir.glob("*.mp4") if p.stat().st_size > 1_000_000])
    if not capitulos:
        log(f"No hay capítulos en {input_dir}")
        return None

    log(f"=== COMPILANDO: {nombre_serie} ({len(capitulos)} caps) ===")
    logo_ok = LOGO.exists()

    # 1. Normalizar cada capítulo
    normalizados = []
    for cap in capitulos:
        dst = TEMP / f"norm_{cap.stem}.mp4"
        if normalizar_capitulo(cap, dst, logo_ok):
            normalizados.append(dst)

    if not normalizados:
        log("No se pudo normalizar ningún capítulo. Abortando.")
        return None

    # 2. Crear lista de concat
    ts_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    nombre_safe = re.sub(r'[^a-zA-Z0-9_]', '_', nombre_serie)[:30]
    output_name = f"MARATON_{nombre_safe}_{ts_str}.mp4"
    output_path = output_dir / output_name
    concat_list = TEMP / f"concat_{ts_str}.txt"

    with open(concat_list, "w", encoding="utf-8") as f:
        for p in normalizados:
            f.write(f"file '{p.as_posix()}'\n")

    log(f"Uniendo {len(normalizados)} capítulos en {output_name}...")
    ok = ff(
        "-y", "-f", "concat", "-safe", "0", "-i", str(concat_list),
        "-c:v", "libx264", "-preset", "veryfast", "-b:v", "2500k",
        "-c:a", "aac", "-b:a", "160k", "-ar", "44100", "-ac", "2",
        str(output_path), check=True
    )

    # 3. Limpiar temps
    for p in normalizados:
        p.unlink(missing_ok=True)
    concat_list.unlink(missing_ok=True)

    if ok and output_path.exists():
        size_gb = round(output_path.stat().st_size / 1024**3, 2)
        log(f"✅ MARATÓN LISTO: {output_name} ({size_gb} GB)")

        # 4. Mover capítulos originales a finalizados
        for cap in capitulos:
            try:
                shutil.move(str(cap), str(FINALIZADOS / cap.name))
            except Exception as e:
                log(f"  Aviso moviendo {cap.name}: {e}")

        # 5. Copiar a la cola de streaming (dbz_to_play)
        stream_copy = STREAM_QUEUE / output_name
        try:
            shutil.copy2(str(output_path), str(stream_copy))
            log(f"✅ Copiado a cola de stream: {stream_copy.name}")
        except Exception as e:
            log(f"  Aviso copiando a stream: {e}")

        # 6. Resultado JSON para n8n
        result = {
            "estado": "compilado",
            "serie": nombre_serie,
            "archivo": output_name,
            "capitulos_incluidos": len(capitulos),
            "tamano_gb": size_gb,
            "timestamp": datetime.now().isoformat()
        }
        print(json.dumps(result, ensure_ascii=False))
        return output_path
    else:
        log("❌ Falló la unión final")
        result = {"estado": "error", "serie": nombre_serie}
        print(json.dumps(result, ensure_ascii=False))
        return None

def main():
    p = argparse.ArgumentParser(description="Compilador Maestro KRC")
    p.add_argument("--serie",  default="Serie", help="Nombre de la serie")
    p.add_argument("--input",  default=str(DEFAULT_INPUT),  help="Carpeta de capítulos")
    p.add_argument("--output", default=str(DEFAULT_OUTPUT), help="Carpeta de salida")
    args = p.parse_args()
    compilar_serie(Path(args.input), Path(args.output), args.serie)

if __name__ == "__main__":
    main()
