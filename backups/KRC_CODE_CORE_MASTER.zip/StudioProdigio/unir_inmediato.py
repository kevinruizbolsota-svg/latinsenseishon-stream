import subprocess
import shutil
from pathlib import Path

FFMPEG = r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe"
NORM = Path(r"C:\Users\kevin\StudioProdigio\episodes_norm")
OUTPUT = Path(r"C:\Users\kevin\Desktop\VIDEOS LARGOS PARA STREAMING\MARATON_Chavo_del_8_KRC.mp4")
EN_COLA = Path(r"C:\Users\kevin\Desktop\KABALION TV\EN_COLA\0001_Chavo_Del_8_Master_KRC.mp4")

OUTPUT.parent.mkdir(parents=True, exist_ok=True)
EN_COLA.parent.mkdir(parents=True, exist_ok=True)

intro = NORM / "intro_n.mp4"
ep1 = NORM / "norm_ep01_Aq6BCL0e54o.mp4"
outro = NORM / "outro_n.mp4"

concat_txt = NORM / "fast_concat.txt"
with open(concat_txt, "w", encoding="utf-8") as f:
    f.write(f"file '{intro.as_posix()}'\n")
    f.write(f"file '{ep1.as_posix()}'\n")
    f.write(f"file '{outro.as_posix()}'\n")

print("Uniendo rapido con re-muxing...")
cmd = [
    FFMPEG, "-y", "-f", "concat", "-safe", "0", "-i", str(concat_txt),
    "-c", "copy", str(OUTPUT)
]
subprocess.run(cmd, check=True)

shutil.copyfile(str(OUTPUT), str(EN_COLA))
print(f"EXITO: Generado {OUTPUT.name} ({OUTPUT.stat().st_size / (1024*1024):.1f} MB)")
