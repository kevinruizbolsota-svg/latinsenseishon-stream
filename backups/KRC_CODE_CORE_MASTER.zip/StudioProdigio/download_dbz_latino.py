"""
Descarga episodios largos (main) de la playlist DBZ Latino a dbz_to_play en orden.
"""
import subprocess, json
from pathlib import Path

STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
OUT = STUDIO / "dbz_to_play"
OUT.mkdir(parents=True, exist_ok=True)
MANIFEST = STUDIO / "dbz_latino_manifest.json"

def safe_name(seq, title, vid):
    t = "".join(c for c in title if c.isalnum() or c in " -_").strip()[:70]
    return f"{seq:03d}_{t}_{vid}.mp4"

def main():
    data = json.loads(MANIFEST.read_text(encoding="utf-8-sig"))
    items = data["main"]
    # total 5 capitulos (001 ya reproducido + 002-005)
    items = items[:5]
    known_present = {"3Nuo9qK6Zks"}  # 001_saiyajin_latino.mp4 en vivo
    cookies = STUDIO / "youtube_cookies.txt"
    for seq, it in enumerate(items, 1):
        name = safe_name(seq, it["title"], it["id"])
        dest = OUT / name
        existing = list(OUT.glob("*.mp4")) + list((STUDIO/"dbz_played").glob("*.mp4")) + list((STUDIO/"dbz_archive_old").glob("*.mp4"))
        if it["id"] in known_present or any(it["id"] in p.name for p in existing):
            print(f"SKIP (id) {it['id']} {it['title'][:50]}")
            continue
        if dest.exists() and dest.stat().st_size > 50_000_000:
            print(f"SKIP {name}")
            continue
        url = f"https://www.youtube.com/watch?v={it['id']}"
        print(f"\n=== DESCARGANDO {seq}/{len(items)}: {it['title']} ({it['id']}) ===", flush=True)
        cmd = [
            "yt-dlp", "--js-runtimes", "node",
            "--remote-components", "ejs:github",
            "--ffmpeg-location", r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin",
        ]
        if cookies.exists():
            cmd += ["--cookies", str(cookies)]
        cmd += [
            "-f", "bv*[height<=720]+ba/b[ext=mp4][height<=720]/b[height<=720]/b",
            "--merge-output-format","mp4","--no-playlist",
            "--no-overwrites",
            "-o", str(dest), url
        ]
        r = subprocess.run(cmd)
        print(f"exit={r.returncode} -> {dest.name}", flush=True)
    print("\nDONE", flush=True)

if __name__ == "__main__":
    main()
