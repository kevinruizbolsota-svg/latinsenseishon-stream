"""
TWITCH AUTO-TITLE BOT — LOS CALLE TV
=====================================
Actualiza automaticamente el titulo, categoria y tags de Twitch
cada vez que el stream cultural comienza un nuevo capitulo.
81 scopes activos — control total del canal.
"""

import urllib.request, urllib.error, json, time, os
from pathlib import Path

STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
TOKENS_FILE = STUDIO / "twitch_oauth_tokens.json"
TITLES_FILE = STUDIO / "titulos_programacion.json"
STATE_FILE  = STUDIO / "twitch_stream_state.json"

def load_tokens():
    return json.loads(TOKENS_FILE.read_text(encoding="utf-8"))

def load_titles():
    try:
        return json.loads(TITLES_FILE.read_text(encoding="utf-8"))
    except:
        return {}

def twitch_patch(endpoint, payload, tokens):
    url = f"https://api.twitch.tv/helix/{endpoint}"
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={
        "Client-Id": tokens["client_id"],
        "Authorization": "Bearer " + tokens["access_token"],
        "Content-Type": "application/json"
    }, method="PATCH")
    try:
        with urllib.request.urlopen(req) as r:
            return r.status
    except urllib.error.HTTPError as e:
        print("Error API Twitch:", e.code, e.read().decode())
        return e.code

def twitch_post(endpoint, payload, tokens):
    url = f"https://api.twitch.tv/helix/{endpoint}"
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={
        "Client-Id": tokens["client_id"],
        "Authorization": "Bearer " + tokens["access_token"],
        "Content-Type": "application/json"
    }, method="POST")
    try:
        with urllib.request.urlopen(req) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        print("Error POST Twitch:", e.code, e.read().decode())
        return None

def update_channel(title, tokens, broadcaster_id="851574809"):
    status = twitch_patch(
        f"channels?broadcaster_id={broadcaster_id}",
        {"title": title},
        tokens
    )
    if status == 204:
        print(f"[TITULO ACTUALIZADO] -> {title}")
    return status

def send_chat_announcement(msg, tokens, broadcaster_id="851574809"):
    twitch_post(
        "chat/announcements?broadcaster_id=" + broadcaster_id + "&moderator_id=" + broadcaster_id,
        {"message": msg, "color": "orange"},
        tokens
    )
    print(f"[ANUNCIO EN CHAT] -> {msg}")

def watch_and_update():
    print("=== BOT DE TITULOS AUTOMATICOS LOS CALLE TV ===")
    tokens = load_tokens()
    last_file = None

    while True:
        try:
            titles_map = load_titles()
            # Leer el archivo actual en reproduccion
            current_file = None
            if STATE_FILE.exists():
                st = json.loads(STATE_FILE.read_text(encoding="utf-8"))
                current_file = st.get("file")

            # Revisar tambien twitch_to_play directamente
            if not current_file:
                videos = sorted([
                    p for p in (STUDIO / "twitch_to_play").glob("*.mp4")
                    if p.stat().st_size > 1_000_000
                ])
                if videos:
                    current_file = videos[0].name

            if current_file and current_file != last_file:
                meta = titles_map.get(current_file, {})
                title = meta.get("twitch_title", f"🔴 [24/7 RETRO] {Path(current_file).stem} | Los Calle TV")

                # Actualizar titulo
                update_channel(title, tokens)

                # Anunciar en el chat
                send_chat_announcement(
                    f"📺 AHORA TRANSMITIENDO: {title}",
                    tokens
                )

                last_file = current_file

        except Exception as e:
            print("Error en bot de titulos:", e)

        time.sleep(30)  # Revisar cada 30 segundos

if __name__ == "__main__":
    watch_and_update()
