const fs = require('fs');
const p = 'C:/Users/kevin/StudioProdigio/JuegoUrantino/project.godot';
let toml = fs.readFileSync(p, 'utf8');
toml = toml.replace('run/main_scene="res://MainUrantino.tscn"', 'run/main_scene="res://World3D.tscn"');
fs.writeFileSync(p, toml, 'utf8');
console.log('Escena principal configurada a World3D.tscn');
