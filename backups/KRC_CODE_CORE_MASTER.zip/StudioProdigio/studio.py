import os
import sys
import subprocess
from pathlib import Path

BASE_DIR = Path(r"C:\Users\kevin\StudioProdigio")
INPUT_DIR = BASE_DIR / "input"
OUTPUT_DIR = BASE_DIR / "output_shorts"
DESKTOP_DIR = Path(r"C:\Users\kevin\Desktop\SHORTS_PRODIGIO_LISTOS")
ASSETS_DIR = BASE_DIR / "assets"
INTRO_DIR = ASSETS_DIR / "intro"
OUTRO_DIR = ASSETS_DIR / "outro"
LOGO_DIR = ASSETS_DIR / "logo"

FFMPEG = r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe"
PYTHON = r"C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe"

DESKTOP_DIR.mkdir(parents=True, exist_ok=True)

def descargar_video_enlace(url: str):
    print(f"\n[*] Conectando a: {url}...")
    cmd = [
        PYTHON, "-m", "yt_dlp",
        "--no-check-certificates",
        "-f", "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best",
        "-o", str(INPUT_DIR / "%(title).50s.%(ext)s"),
        url
    ]
    res = subprocess.run(cmd)
    if res.returncode == 0:
        print("[+] Descarga exitosa y guardada en 'input'.")
        return True
    else:
        print("\n[!] AVISO DE DESCARGA:")
        print("    Si el video tiene restricción de edad (+18) o protección de YouTube:")
        print("    1. Descarga el video directamente con tu navegador.")
        print(f"    2. Pégalo en: {INPUT_DIR}")
        print("    3. Vuelve a ejecutar la opción [2] para procesar el clip con IA y cinemática.")
        return False

def procesar_clip_pro(video_in: Path, start_time: str, duration: int, titulo_short: str):
    print(f"\n[*] Procesando clip cinematográfico de {duration}s desde {start_time}...")
    temp_clip = BASE_DIR / "temp_cinematic.mp4"
    out_final_desktop = DESKTOP_DIR / f"{titulo_short}.mp4"
    out_final_studio = OUTPUT_DIR / f"{titulo_short}.mp4"
    
    # Filtro Cinematográfico:
    # 1. Escala y recorte vertical 9:16 (1080x1920)
    # 2. Corrección de color: Contraste aumentado (1.12), saturación viva (1.20)
    # 3. Filtro Unsharp (claridad y nitidez de micro-detalles)
    vf = (
        "scale=1080:1920:force_original_aspect_ratio=increase,"
        "crop=1080:1920,"
        "eq=contrast=1.12:brightness=0.01:saturation=1.20,"
        "unsharp=3:3:0.9:3:3:0.0"
    )
    
    cmd = [
        FFMPEG, "-y",
        "-ss", start_time,
        "-i", str(video_in),
        "-t", str(duration),
        "-vf", vf,
        "-c:v", "libx264", "-preset", "fast", "-crf", "19",
        "-c:a", "aac", "-b:a", "192k",
        str(temp_clip)
    ]
    
    subprocess.run(cmd)
    
    # Unir con Intro y Outro si existen en assets
    intro_file = next(INTRO_DIR.glob("*.mp4"), None)
    outro_file = next(OUTRO_DIR.glob("*.mp4"), None)
    
    if intro_file or outro_file:
        print("[*] Ensamblando Intro y Outro de Remember Luxury...")
        lista_txt = BASE_DIR / "concat_list.txt"
        with open(lista_txt, "w", encoding="utf-8") as f:
            if intro_file:
                f.write(f"file '{intro_file.resolve()}'\n")
            f.write(f"file '{temp_clip.resolve()}'\n")
            if outro_file:
                f.write(f"file '{outro_file.resolve()}'\n")
                
        cmd_concat = [
            FFMPEG, "-y",
            "-f", "concat", "-safe", "0",
            "-i", str(lista_txt),
            "-c", "copy",
            str(out_final_desktop)
        ]
        subprocess.run(cmd_concat)
        if lista_txt.exists():
            lista_txt.unlink()
    else:
        # Copiar directamente al Escritorio y a Output
        if temp_clip.exists():
            temp_clip.rename(out_final_desktop)
            
    # Guardar copia en el estudio
    if out_final_desktop.exists():
        import shutil
        shutil.copy2(out_final_desktop, out_final_studio)
        print(f"\n[★] ¡CORONASTE! Tu video corto profesional está listo en:")
        print(f"    🖥️ ESCRITORIO: {out_final_desktop}")
        print(f"    📁 STUDIO:     {out_final_studio}")
        return True
    return False

def menu():
    print("""
===================================================================
      ★ STUDIO PRODIGIO AI - SUITE TERMINAL ULTRA-PROFESIONAL ★
                 La Esquina de los Calle & Remember Luxury
===================================================================
 [1] Descargar video largo o directo desde enlace (YouTube / Web)
 [2] Generar Short Viral 9:16 Cinematográfico (al Escritorio)
 [3] Limpiar lote de videos de Drive (Deduplicar + Quitar marcas)
 [4] Ver carpetas de Intro, Outro y Salidas
 [0] Salir
===================================================================
    """)
    opc = input("Opción: ").strip()
    if opc == "1":
        link = input("Pega el enlace: ").strip()
        if link:
            descargar_video_enlace(link)
    elif opc == "2":
        videos = list(INPUT_DIR.glob("*.mp4"))
        if not videos:
            print(f"[-] No hay videos en {INPUT_DIR}. Copia o descarga tu video largo ahí primero.")
            return
        print("\nVideos listos:")
        for idx, v in enumerate(videos, 1):
            print(f"  [{idx}] {v.name}")
        sel = int(input("Selecciona video [1-N]: ").strip()) - 1
        start = input("Segundo/minuto de inicio (ej: 00:01:15): ").strip()
        dur = int(input("Duración en segundos (ej: 45): ").strip())
        name = input("Título del Short (sin espacios, ej: Short_Viral_Lujo_1): ").strip()
        procesar_clip_pro(videos[sel], start, dur, name)

if __name__ == "__main__":
    menu()
