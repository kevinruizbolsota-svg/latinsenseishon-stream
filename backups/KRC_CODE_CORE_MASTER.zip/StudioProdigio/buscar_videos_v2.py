import sys, json, time
sys.path.insert(0, r"C:\Users\kevin\StudioProdigio")
import yt_dlp

# Try searching for videos with "full episode" or "capitulo completo"
queries = [
    "Chavo del 8 capitulo completo",
    "Dragon Ball Z episodio completo",
    "Simpsons episodio completo",
    "Bob Esponja episodio completo",
    "Naruto episodio completo",
]

all_working = {}
for query in queries:
    try:
        opts = {"extract_flat": True, "quiet": True, "default_search": "ytsearch10"}
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(f"ytsearch10:{query}", download=False)
            entries = info.get("entries", [])
            vids = []
            for e in entries:
                vid_id = e.get("id", "")
                title = e.get("title", "")
                duration = e.get("duration", 0)
                # Try to find downloadable ones
                if vid_id and duration and 60 < duration < 1800:
                    # Test download
                    try:
                        test_opts = {"format": "best", "quiet": True, "no_warnings": True, "skip_download": True}
                        with yt_dlp.YoutubeDL(test_opts) as ydl2:
                            test_info = ydl2.extract_info(f"https://www.youtube.com/watch?v={vid_id}", download=False)
                        formats = test_info.get("formats", [])
                        if formats:
                            vids.append({"id": vid_id, "title": title, "duration": duration})
                            print(f"  OK: {title[:50]} ({duration}s, {len(formats)} formats)")
                            if len(vids) >= 3:
                                break
                    except:
                        pass
            if vids:
                key = query.split(" episodio")[0].split(" capitulo")[0]
                all_working[key] = vids[:3]
            time.sleep(3)
    except Exception as e:
        print(f"FAIL: {query}: {str(e)[:60]}")

with open(r"C:\Users\kevin\StudioProdigio\videos_working_v2.json", "w", encoding="utf-8") as f:
    json.dump(all_working, f, ensure_ascii=False, indent=2)
print(f"\nTotal series with downloadable videos: {len(all_working)}")
for k, v in all_working.items():
    print(f"  {k}: {len(v)} videos")
