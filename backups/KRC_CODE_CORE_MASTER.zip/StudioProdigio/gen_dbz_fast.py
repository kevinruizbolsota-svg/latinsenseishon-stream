"""
Generador de videos DBZ con FFmpeg (un solo comando por video)
Mas rapido y confiable
"""
import subprocess, sys, os
from pathlib import Path
from datetime import datetime

STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
FFMPEG = Path(r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe")
OUTPUT_DIR = STUDIO / "videos_generados"
DBZ_DIR = STUDIO / "dbz_to_play"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
DBZ_DIR.mkdir(parents=True, exist_ok=True)

episodes = [
    ("Dragon Ball Z - Frieza Saga Ep 1", "Goku arrives on Namek", "0x1a1a2e", "0x00ff00"),
    ("Dragon Ball Z - Frieza Saga Ep 2", "Battle with Frieza soldiers", "0x16213e", "0xff6600"),
    ("Dragon Ball Z - Frieza Saga Ep 3", "Goku vs Frieza begins", "0x0f3460", "0xff0000"),
    ("Dragon Ball Z - Frieza Saga Ep 4", "Frieza transforms", "0x533483", "0x9900ff"),
    ("Dragon Ball Z - Frieza Saga Ep 5", "Goku goes Super Saiyan", "0xe94560", "0xffff00"),
]

for i, (title, subtitle, bg_color, text_color) in enumerate(episodes, 1):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = OUTPUT_DIR / f"dbz_ep{i:02d}_{timestamp}.mp4"
    duration = 10

    print(f"[{i}/{len(episodes)}] Generating: {title}")

    # Single FFmpeg command to generate the entire video
    cmd = [
        str(FFMPEG), "-y",
        "-f", "lavfi", "-i", f"color=c={bg_color}:s=1280x720:r=30:d={duration}",
        "-vf", (
            f"drawtext=text='{title}':fontfile='C\\:/Windows/Fonts/arialbd.ttf':fontcolor={text_color}:fontsize=52:"
            f"x=(w-text_w)/2:y=(h-text_h)/2-30:box=1:boxcolor=black@0.6:boxborderw=12,"
            f"drawtext=text='{subtitle}':fontfile='C\\:/Windows/Fonts/arial.ttf':fontcolor=white:fontsize=32:"
            f"x=(w-text_w)/2:y=(h-text_h)/2+40:box=1:boxcolor=black@0.4:boxborderw=8,"
            f"drawtext=text='DBZ FRIEZA SAGA':fontfile='C\\:/Windows/Fonts/arialbd.ttf':fontcolor=0xffcc00:fontsize=24:"
            f"x=(w-text_w)/2:y=40"
        ),
        "-c:v", "libx264", "-preset", "fast", "-b:v", "2000k",
        "-pix_fmt", "yuv420p", str(output_file)
    ]

    result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    if result.returncode == 0 and output_file.exists() and output_file.stat().st_size > 0:
        size_mb = output_file.stat().st_size / (1024*1024)
        print(f"  OK: {output_file.name} ({size_mb:.1f}MB)")
        # Copy to dbz_to_play
        import shutil
        dst = DBZ_DIR / f"dbz_ep{i:02d}.mp4"
        shutil.copy(str(output_file), str(dst))
        print(f"  Copied to: {dst}")
    else:
        print(f"  ERROR: {result.stderr[-200:]}")

print(f"\nDone! Videos in dbz_to_play: {len(list(DBZ_DIR.glob('*.mp4')))}")
