"""
Descarga capítulos de la playlist DBZ (PLACO0KoJtoZc) a dbz_to_play en orden.
Prioriza Saga Freeza (10,11) primero, luego el resto.
"""
import subprocess, json, sys
from pathlib import Path

STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
OUT = STUDIO / "dbz_to_play"
OUT.mkdir(parents=True, exist_ok=True)
MANIFEST = STUDIO / "dbz_playlist_PLACO0KoJtoZc.json"

# Order: Freeza first (as requested), then Saiyajin, then Androides/Cell/Boo
PRIORITY_IDS = ["9upHefdl468","pDFq0QIECXA","_WqU2sBCXu4","g8yggREaY7Q","IcWHOHqFJBU","MSmzV7fsIKI","kd5VepKHBX0","jFI-dabHuJI","BKS7lRD2y6Y","_EaKe3dKH5o","vzEopf07-a0"]

def safe_name(seq, title, vid):
    t = "".join(c for c in title if c.isalnum() or c in " -_").strip()[:60]
    return f"{seq:03d}_{t}_{vid}.mp4"

def main():
    raw = MANIFEST.read_text(encoding="utf-8-sig")
    items = json.loads(raw)
    by_id = {it["id"]: it for it in items}
    ordered = [by_id[i] for i in PRIORITY_IDS if i in by_id]
    for seq, it in enumerate(ordered, 1):
        name = safe_name(seq, it["title"], it["id"])
        dest = OUT / name
        if dest.exists() and dest.stat().st_size > 50_000_000:
            print(f"SKIP {name}")
            continue
        existing = list(OUT.glob("*.mp4")) + list((STUDIO / "dbz_played").glob("*.mp4"))
        if any(it["id"] in p.name for p in existing):
            print(f"SKIP (id exists) {it['id']}")
            continue
        if it["id"] == "9upHefdl468" and any("Freeza Parte 1" in p.name or "010_Saga Freeza" in p.name for p in existing):
            print(f"SKIP (manual) {it['id']}")
            continue
        url = f"https://www.youtube.com/watch?v={it['id']}"
        print(f"\n=== DESCARGANDO {seq}/{len(ordered)}: {it['title']} ({it['id']}) ===", flush=True)
        cmd = [
            "yt-dlp", "-f",
            "bestvideo[ext=mp4][height<=720]+bestaudio[ext=m4a]/best[ext=mp4][height<=720]/best[height<=720]/best",
            "--merge-output-format","mp4","--no-playlist",
            "-o", str(dest), url
        ]
        r = subprocess.run(cmd)
        print(f"exit={r.returncode} -> {dest.name}", flush=True)
    print("\nDONE", flush=True)

if __name__ == "__main__":
    main()
