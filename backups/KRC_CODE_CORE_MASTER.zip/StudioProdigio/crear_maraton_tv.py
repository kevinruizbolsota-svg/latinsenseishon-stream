import json
import os
import subprocess
from pathlib import Path
import yt_dlp

STUDIO_DIR = Path(r"C:\Users\kevin\StudioProdigio")
OUTPUT_DIR = Path(r"C:\Users\kevin\Desktop\VIDEOS LARGOS PARA STREAMING")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

FFMPEG = r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe"
INTRO_FILE = STUDIO_DIR / "assets" / "intro" / "intro_oficial.mp4"
OUTRO_FILE = STUDIO_DIR / "assets" / "outro" / "outro_oficial.mp4"
LOGO_FILE = STUDIO_DIR / "assets" / "logo" / "logo_krc_transparent.png"
EPISODES_DIR = STUDIO_DIR / "episodes_raw"
EPISODES_DIR.mkdir(parents=True, exist_ok=True)

PLAYLIST_URL = "https://www.youtube.com/playlist?list=PLuxcLq9n25BEINVPnsS419gD8E6WSeiS-"

def get_playlist_items(limit=3):
    ydl_opts = {'extract_flat': True, 'quiet': True}
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        res = ydl.extract_info(PLAYLIST_URL, download=False)
        entries = res.get('entries', [])
        return entries[:limit]

def download_episode(video_id, title):
    out_template = str(EPISODES_DIR / f"{video_id}.%(ext)s")
    target_mp4 = EPISODES_DIR / f"{video_id}.mp4"
    if target_mp4.exists() and target_mp4.stat().st_size > 1000000:
        print(f"Capítulo ya descargado: {target_mp4}")
        return target_mp4
    
    ydl_opts = {
        'format': '134+140/best[ext=mp4]/best',
        'outtmpl': out_template,
        'ffmpeg_location': str(Path(FFMPEG).parent),
        'merge_output_format': 'mp4',
        'quiet': False
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        ydl.download([f"https://www.youtube.com/watch?v={video_id}"])
    return target_mp4

print("Script base listo para el compilador de maratones.")
