"""
KABALION TV - Master Schedule & Auto-Purger
Orden diario:
 06:00 - 08:00 : El Chavo del 8 (3 eps)
 08:00 - 10:00 : Bob Esponja (3 eps)
 10:00 - 12:00 : Dragon Ball Z (2 eps)
Ciclo continuo. Limite estricto de almacenamiento: maximo 20 capitulos en total.
"""
import sys, subprocess, json, time, os, shutil, threading
from pathlib import Path
from datetime import datetime
import yt_dlp

FFMPEG   = Path(r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe")
STUDIO   = Path(r"C:\Users\kevin\StudioProdigio")
TV_DIR   = Path(r"C:\Users\kevin\Desktop\KABALION TV")
EN_COLA       = TV_DIR / "EN_COLA"
TRANSMITIENDO = TV_DIR / "TRANSMITIENDO"
TRANSMITIDOS  = TV_DIR / "TRANSMITIDOS"
MANT          = TV_DIR / "MANTENIMIENTO"
TEMP_DIR      = STUDIO / "tv_temp"

for d in [EN_COLA, TRANSMITIENDO, TRANSMITIDOS, MANT, TEMP_DIR]:
    d.mkdir(parents=True, exist_ok=True)

INTRO    = STUDIO / "assets/intro/intro_oficial.mp4"
OUTRO    = STUDIO / "assets/outro/outro_oficial.mp4"
LOGO     = STUDIO / "assets/logo/logo_krc_transparent.png"
CFG_FILE = STUDIO / "stream_config.json"

SERIES_SCHEDULE = [
    {"serie": "El Chavo del 8", "url": "https://www.youtube.com/playlist?list=PLuxcLq9n25BEINVPnsS419gD8E6WSeiS-", "count": 3},
    {"serie": "Bob Esponja",    "url": "https://www.youtube.com/playlist?list=PLuKg-WnCU1f_YX8R-3JD8g5mGdGl6BTWL", "count": 3},
    {"serie": "Dragon Ball Z",  "url": "https://www.youtube.com/playlist?list=PLxqR1nAef2BHfk0hCGdNFzBjhp6hm9M4v", "count": 2}
]

MAX_CAPITULOS_TOTAL = 20

def log(msg):
    ts = datetime.now().strftime("%H:%M:%S")
    print(f"[{ts}] {msg}")

def contar_capitulos():
    c_cola = len(list(EN_COLA.glob("*.mp4")))
    c_trans = len(list(TRANSMITIENDO.glob("*.mp4")))
    c_done = len(list(TRANSMITIDOS.glob("*.mp4")))
    return c_cola + c_trans + c_done

def purgar_si_excede():
    while contar_capitulos() >= MAX_CAPITULOS_TOTAL:
        archivos = sorted(TRANSMITIDOS.glob("*.mp4"), key=lambda f: f.stat().st_mtime)
        if archivos:
            log(f"Purgando capitulo antiguo para liberar espacio: {archivos[0].name}")
            archivos[0].unlink()
        else:
            break

def get_calming_pause():
    pause_mp4 = MANT / "pantalla_universo.mp4"
    if not pause_mp4.exists():
        subprocess.run([
            str(FFMPEG), "-y",
            "-f", "lavfi", "-i", "color=c=0x060618:s=1280x720:d=30,format=yuv420p",
            "-f", "lavfi", "-i", "sine=f=174:r=44100",
            "-c:v", "libx264", "-preset", "ultrafast",
            "-c:a", "aac", "-b:a", "96k",
            str(pause_mp4)
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return pause_mp4

def iniciar_streams_rtmp(video_path):
    cfg = json.loads(CFG_FILE.read_text()) if CFG_FILE.exists() else {}
    procs = []
    
    # Twitch (100% verificado y conectado)
    tw = cfg.get("twitch", {})
    if tw.get("activo") and tw.get("key"):
        cmd = [
            str(FFMPEG), "-re", "-i", str(video_path),
            "-c:v", "libx264", "-preset", "veryfast", "-b:v", "3500k",
            "-maxrate", "3500k", "-bufsize", "7000k", "-pix_fmt", "yuv420p",
            "-g", "60", "-c:a", "aac", "-b:a", "160k", "-ar", "44100",
            "-f", "flv", f"rtmp://live.twitch.tv/app/{tw['key']}"
        ]
        p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        log(f"🔴 LIVE -> TWITCH (PID {p.pid})")
        procs.append(("twitch", p))
        
    return procs

def run_loop():
    log("=== KABALION TV V2: CICLO 20 CAPITULOS & PAUSA CALMANTE ===")
    pause_video = get_calming_pause()
    
    while True:
        purgar_si_excede()
        cola = sorted(EN_COLA.glob("*.mp4"))
        
        if not cola:
            log("Cola vacia momentaneamente -> Emitiendo pausa espacial con frecuencia armonica...")
            procs = iniciar_streams_rtmp(pause_video)
            for _, p in procs:
                p.wait()
            time.sleep(2)
            continue
            
        ep = cola[0]
        dest = TRANSMITIENDO / ep.name
        shutil.move(str(ep), str(dest))
        log(f"EN EL AIRE AHORA: {dest.name}")
        
        procs = iniciar_streams_rtmp(dest)
        for _, p in procs:
            p.wait()
            
        arch = TRANSMITIDOS / dest.name
        shutil.move(str(dest), str(arch))
        log(f"Terminado y archivado para clips: {arch.name}")
        purgar_si_excede()
        time.sleep(1)

if __name__ == "__main__":
    run_loop()
