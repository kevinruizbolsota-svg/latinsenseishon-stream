﻿import os
root = r"C:\Users\kevin\Documents\COLWAR_NUEVO"
out = os.path.join(root, "main.tscn")

# minimal, self-contained: no external assets, all CSG/built-in
scene = r'''[gd_scene load_steps=12 format=3]

[ext_resource type="Script" path="res://player.gd" id="1"]
[ext_resource type="Script" path="res://zombie.gd" id="2"]

[sub_resource type="ProceduralSkyMaterial" id="SkyMat"]
sky_top_color = Color(0.1, 0.35, 0.7, 1)
sky_horizon_color = Color(0.55, 0.7, 0.85, 1)
ground_bottom_color = Color(0.12, 0.18, 0.1, 1)
ground_horizon_color = Color(0.3, 0.4, 0.28, 1)

[sub_resource type="Sky" id="Sky1"]
sky_material = SubResource("SkyMat")

[sub_resource type="Environment" id="Env1"]
background_mode = 2
sky = SubResource("Sky1")
ambient_light_source = 2
ambient_light_color = Color(0.75, 0.8, 0.9, 1)
ambient_light_energy = 0.9
tonemap_mode = 2
glow_enabled = false

[sub_resource type="StandardMaterial3D" id="MatPasto"]
albedo_color = Color(0.18, 0.42, 0.16, 1)
roughness = 1.0

[sub_resource type="StandardMaterial3D" id="MatTronco"]
albedo_color = Color(0.35, 0.22, 0.12, 1)
roughness = 1.0

[sub_resource type="StandardMaterial3D" id="MatHojas"]
albedo_color = Color(0.1, 0.38, 0.12, 1)
roughness = 0.9

[sub_resource type="CapsuleShape3D" id="PlayerShape"]
radius = 0.4
height = 1.8

[sub_resource type="CapsuleShape3D" id="ZombieShape"]
radius = 0.45
height = 1.7

[sub_resource type="StandardMaterial3D" id="MatZombie"]
albedo_color = Color(0.25, 0.45, 0.22, 1)
roughness = 0.8

[node name="Main" type="Node3D"]

[node name="WorldEnvironment" type="WorldEnvironment" parent="."]
environment = SubResource("Env1")

[node name="Sol" type="DirectionalLight3D" parent="."]
transform = Transform3D(0.866025, -0.353553, 0.353553, 0, 0.707107, 0.707107, -0.5, -0.612372, 0.612372, 0, 40, 0)
light_energy = 1.4
shadow_enabled = true

[node name="Suelo" type="CSGBox3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.5, 0)
use_collision = true
size = Vector3(200, 1, 200)
material = SubResource("MatPasto")

[node name="Arboles" type="Node3D" parent="."]

[node name="A1" type="Node3D" parent="Arboles"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 8, 0, 6)
[node name="T" type="CSGCylinder3D" parent="Arboles/A1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.5, 0)
use_collision = true
radius = 0.25
height = 3.0
material = SubResource("MatTronco")
[node name="H" type="CSGSphere3D" parent="Arboles/A1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 3.6, 0)
radius = 1.6
material = SubResource("MatHojas")

[node name="A2" type="Node3D" parent="Arboles"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -10, 0, 5)
[node name="T" type="CSGCylinder3D" parent="Arboles/A2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.6, 0)
use_collision = true
radius = 0.28
height = 3.2
material = SubResource("MatTronco")
[node name="H" type="CSGSphere3D" parent="Arboles/A2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 3.8, 0)
radius = 1.8
material = SubResource("MatHojas")

[node name="A3" type="Node3D" parent="Arboles"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 6, 0, -12)
[node name="T" type="CSGCylinder3D" parent="Arboles/A3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.4, 0)
use_collision = true
radius = 0.22
height = 2.8
material = SubResource("MatTronco")
[node name="H" type="CSGSphere3D" parent="Arboles/A3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 3.3, 0)
radius = 1.5
material = SubResource("MatHojas")

[node name="A4" type="Node3D" parent="Arboles"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -7, 0, -14)
[node name="T" type="CSGCylinder3D" parent="Arboles/A4"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.7, 0)
use_collision = true
radius = 0.3
height = 3.4
material = SubResource("MatTronco")
[node name="H" type="CSGSphere3D" parent="Arboles/A4"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 4.0, 0)
radius = 1.9
material = SubResource("MatHojas")

[node name="A5" type="Node3D" parent="Arboles"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 15, 0, -4)
[node name="T" type="CSGCylinder3D" parent="Arboles/A5"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.5, 0)
use_collision = true
radius = 0.24
height = 3.0
material = SubResource("MatTronco")
[node name="H" type="CSGSphere3D" parent="Arboles/A5"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 3.6, 0)
radius = 1.7
material = SubResource("MatHojas")

[node name="A6" type="Node3D" parent="Arboles"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -15, 0, -2)
[node name="T" type="CSGCylinder3D" parent="Arboles/A6"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.5, 0)
use_collision = true
radius = 0.26
height = 3.0
material = SubResource("MatTronco")
[node name="H" type="CSGSphere3D" parent="Arboles/A6"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 3.6, 0)
radius = 1.6
material = SubResource("MatHojas")

[node name="Player" type="CharacterBody3D" parent="." groups=["player"]]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.0, 0)
script = ExtResource("1")

[node name="CollisionShape3D" type="CollisionShape3D" parent="Player"]
shape = SubResource("PlayerShape")

[node name="Camera3D" type="Camera3D" parent="Player"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.6, 0)
current = true

[node name="RayCast3D" type="RayCast3D" parent="Player/Camera3D"]
target_position = Vector3(0, 0, -60)
enabled = true

[node name="Mano" type="CSGBox3D" parent="Player/Camera3D"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0.25, -0.22, -0.45)
size = Vector3(0.08, 0.08, 0.35)

[node name="UI" type="CanvasLayer" parent="."]

[node name="Label" type="Label" parent="UI"]
offset_left = 16.0
offset_top = 16.0
offset_right = 900.0
offset_bottom = 50.0
text = "COLWAR - Cargando..."

[node name="Mira" type="Label" parent="UI"]
anchors_preset = 8
anchor_left = 0.5
anchor_top = 0.5
anchor_right = 0.5
anchor_bottom = 0.5
offset_left = -10.0
offset_top = -12.0
offset_right = 10.0
offset_bottom = 12.0
text = "+"
horizontal_alignment = 1
vertical_alignment = 1

[node name="Zombie1" type="CharacterBody3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 12, 1.0, 10)
script = ExtResource("2")

[node name="CollisionShape3D" type="CollisionShape3D" parent="Zombie1"]
shape = SubResource("ZombieShape")

[node name="Cuerpo" type="CSGCylinder3D" parent="Zombie1"]
radius = 0.4
height = 1.6
material = SubResource("MatZombie")

[node name="Cabeza" type="CSGSphere3D" parent="Zombie1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.05, 0)
radius = 0.28
material = SubResource("MatZombie")

[node name="Zombie2" type="CharacterBody3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -14, 1.0, 8)
script = ExtResource("2")

[node name="CollisionShape3D" type="CollisionShape3D" parent="Zombie2"]
shape = SubResource("ZombieShape")

[node name="Cuerpo" type="CSGCylinder3D" parent="Zombie2"]
radius = 0.4
height = 1.6
material = SubResource("MatZombie")

[node name="Cabeza" type="CSGSphere3D" parent="Zombie2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.05, 0)
radius = 0.28
material = SubResource("MatZombie")

[node name="Zombie3" type="CharacterBody3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 5, 1.0, -16)
script = ExtResource("2")

[node name="CollisionShape3D" type="CollisionShape3D" parent="Zombie3"]
shape = SubResource("ZombieShape")

[node name="Cuerpo" type="CSGCylinder3D" parent="Zombie3"]
radius = 0.4
height = 1.6
material = SubResource("MatZombie")

[node name="Cabeza" type="CSGSphere3D" parent="Zombie3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.05, 0)
radius = 0.28
material = SubResource("MatZombie")

[node name="Zombie4" type="CharacterBody3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -8, 1.0, -18)
script = ExtResource("2")

[node name="CollisionShape3D" type="CollisionShape3D" parent="Zombie4"]
shape = SubResource("ZombieShape")

[node name="Cuerpo" type="CSGCylinder3D" parent="Zombie4"]
radius = 0.4
height = 1.6
material = SubResource("MatZombie")

[node name="Cabeza" type="CSGSphere3D" parent="Zombie4"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.05, 0)
radius = 0.28
material = SubResource("MatZombie")
'''
open(out, 'w', encoding='utf-8', newline='\n').write(scene)
print('ok')
