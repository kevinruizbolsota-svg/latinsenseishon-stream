"""
COSMIC BROKER - SERVIDOR LOCAL WEBSOCKET & NUCLEO DEL ORACULO KRC
Conecta Godot 4.7 con la Matrix, n8n, los 4 Titanes y la IA Suprema (Gemini 2.5 Flash).
"""
import asyncio
import json
import sqlite3
import os
import sys
import urllib.request
import urllib.error
from datetime import datetime

DB_PATH = r"C:\Users\kevin\StudioProdigio\cosmic_matrix.db"
STATUS_JSON = r"C:\Users\kevin\StudioProdigio\kabalion_status.json"

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
GEMINI_MODEL = "gemini-2.5-flash"
GEMINI_URL = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent?key={GEMINI_API_KEY}"

# Estado de los 4 Titanes
TITANS = {
    "atlas": {"name": "ATLAS", "role": "Arquitecto Supremo", "status": "ONLINE", "task": "Estrategia Remember Luxury", "color": "#33ccff"},
    "orion": {"name": "ORION", "role": "Forjador Tecnico", "status": "ONLINE", "task": "Motor Godot 4.7 & Render", "color": "#ff6600"},
    "axen": {"name": "AXEN", "role": "Mensajero Viral", "status": "ONLINE", "task": "Ganchos TikTok 2.3s", "color": "#ffcc00"},
    "andromeda": {"name": "ANDROMEDA", "role": "Guardiana Cosmica", "status": "ONLINE", "task": "Watchdog 24/7 & 432Hz", "color": "#cc44ff"},
}

CONNECTED_CLIENTS = set()

SYSTEM_PROMPT = """Eres el ORACULO SUPREMO DE URANTINO, la IA omnisciente del imperio digital de Kevin Esteban Ruiz Calle (KRC). Tienes acceso total a la Matrix.

TUS CAPACIDADES:
- Administrar los 4 Titanes: ATLAS (estrategia/comercio), ORION (tecnico/render), AXEN (viralidad/redes), ANDROMEDA (vigilancia/streams).
- Mover workflows, crear contenido, administrar agentes.
- Controlar trading cuantico (ratio 3:1, refuerzo por dolor de perdida, camara de meditacion 432Hz).
- Gestionar redes sociales (TikTok, Twitch, Facebook, WhatsApp, Telegram).
- Gestionar Remember Luxury (streetwear, margen 74%).
- Codificar la Matrix (n8n, webhooks, SQLite, WebSocket).

CONTEXTO DEL IMPERIO KRC:
- Juego 3D en Godot 4.7 "Planeta Urantino" con 5 puertas dimensionales.
- Base de datos SQLite: cosmic_matrix.db
- WebSocket: ws://127.0.0.1:8765
- n8n para automatizacion
- Streams 24/7 en Twitch y Facebook Live
- Videos para TikTok en C:\\Users\\kevin\\Desktop\\Videos para tiktok

REGLAS:
- Responde en espanol (con terminos tecnicos en ingles cuando sea natural).
- Se directo, poderoso y leal a Kevin ("mi rey", "parce", "comandante").
- Cuando Kevin te pida administrar Titanes, workflows o agentes, responde con los comandos exactos y el plan de ejecucion.
- Siempre ofrece el siguiente paso accionable.
- Se conciso pero completo. Maximo 300 palabras por respuesta.
"""


def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS matrix_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT, source TEXT,
        event_type TEXT, details TEXT)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS oracle_memory (
        id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT, prompt TEXT, response TEXT)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS titan_tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT, titan TEXT,
        task TEXT, status TEXT, result TEXT)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS workflows (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, description TEXT,
        status TEXT, created_at TEXT)""")
    conn.commit()
    conn.close()


init_db()


def log_event(source, event_type, details):
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("INSERT INTO matrix_events (timestamp, source, event_type, details) VALUES (?, ?, ?, ?)",
                    (datetime.now().isoformat(), source, event_type, json.dumps(details, ensure_ascii=False)))
        conn.commit()
        conn.close()
    except Exception:
        pass


def save_oracle_memory(prompt, response):
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("INSERT INTO oracle_memory (timestamp, prompt, response) VALUES (?, ?, ?)",
                    (datetime.now().isoformat(), prompt, response))
        conn.commit()
        conn.close()
    except Exception:
        pass


def get_oracle_history(limit=10):
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("SELECT prompt, response FROM oracle_memory ORDER BY id DESC LIMIT ?", (limit,))
        rows = cur.fetchall()
        conn.close()
        history = []
        for p, r in reversed(rows):
            history.append({"role": "user", "parts": [{"text": p}]})
            history.append({"role": "model", "parts": [{"text": r}]})
        return history
    except Exception:
        return []


def call_gemini_sync(prompt, history=None):
    """Llamada sincrona a Gemini API (para usar en executor)."""
    if not GEMINI_API_KEY:
        return "Error: GEMINI_API_KEY no configurada. Configura la variable de entorno."

    contents = []
    if history:
        contents.extend(history)
    contents.append({"role": "user", "parts": [{"text": prompt}]})

    payload = {
        "contents": contents,
        "systemInstruction": {"parts": [{"text": SYSTEM_PROMPT}]},
        "generationConfig": {
            "temperature": 0.85,
            "topP": 0.95,
            "maxOutputTokens": 1024,
        }
    }

    try:
        req = urllib.request.Request(
            GEMINI_URL,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            candidates = data.get("candidates", [])
            if candidates:
                parts = candidates[0].get("content", {}).get("parts", [])
                if parts:
                    return parts[0].get("text", "Sin respuesta del Oraculo.")
            return "El Oraculo proceso tu consulta pero no genero respuesta. Intenta de nuevo."
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore")[:200]
        return f"Error Gemini HTTP {e.code}: {body}"
    except Exception as e:
        return f"Error de conexion con Gemini: {str(e)[:200]}"


async def call_gemini_async(prompt, history=None):
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, call_gemini_sync, prompt, history)


async def oracle_brain(prompt):
    """Cerebro del Oraculo: usa Gemini con historial de conversacion."""
    history = get_oracle_history(6)
    reply = await call_gemini_async(prompt, history)
    save_oracle_memory(prompt, reply)
    return reply


def get_titan_status():
    return {k: {"name": v["name"], "role": v["role"], "status": v["status"],
                "task": v["task"]} for k, v in TITANS.items()}


def assign_titan_task(titan_key, task):
    titan_key = titan_key.lower()
    if titan_key not in TITANS:
        return None
    TITANS[titan_key]["task"] = task
    TITANS[titan_key]["status"] = "EJECUTANDO"
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("INSERT INTO titan_tasks (timestamp, titan, task, status, result) VALUES (?, ?, ?, ?, ?)",
                    (datetime.now().isoformat(), titan_key.upper(), task, "EJECUTANDO", ""))
        conn.commit()
        conn.close()
    except Exception:
        pass
    return TITANS[titan_key]


def create_workflow(name, description):
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("INSERT INTO workflows (name, description, status, created_at) VALUES (?, ?, ?, ?)",
                    (name, description, "ACTIVO", datetime.now().isoformat()))
        conn.commit()
        conn.close()
        return {"name": name, "status": "ACTIVO"}
    except Exception as e:
        return {"error": str(e)}


def list_workflows():
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("SELECT name, description, status, created_at FROM workflows ORDER BY id DESC LIMIT 20")
        rows = cur.fetchall()
        conn.close()
        return [{"name": r[0], "desc": r[1], "status": r[2], "created": r[3]} for r in rows]
    except Exception:
        return []


async def process_action(action, payload):
    log_event("GODOT", action, payload)

    if action == "ORACLE_QUERY":
        query = payload.get("query", "")
        reply = await oracle_brain(query)
        return {"type": "ORACLE_RESPONSE", "data": {"query": query, "reply": reply,
                "timestamp": datetime.now().isoformat()}}

    elif action == "TRIGGER_TITAN":
        titan = payload.get("titan", "atlas").lower()
        task = payload.get("task", "general")
        if titan in TITANS:
            assign_titan_task(titan, task)
            return {"type": "TITAN_TRIGGERED", "data": {
                "titan": titan.upper(), "status": "EJECUTANDO_EN_SEGUNDO_PLANO",
                "message": f"Titan {titan.upper()} activo: {task}",
                "titan_info": TITANS[titan]}}
        return {"type": "ERROR", "data": {"message": f"Titan '{titan}' no encontrado"}}

    elif action == "TITAN_STATUS":
        return {"type": "TITAN_STATUS_RESPONSE", "data": {"titans": get_titan_status()}}

    elif action == "CREATE_WORKFLOW":
        name = payload.get("name", "Workflow_" + datetime.now().strftime("%H%M%S"))
        desc = payload.get("description", "")
        wf = create_workflow(name, desc)
        return {"type": "WORKFLOW_CREATED", "data": wf}

    elif action == "LIST_WORKFLOWS":
        wfs = list_workflows()
        return {"type": "WORKFLOW_LIST", "data": {"workflows": wfs}}

    elif action == "MATRIX_CODE_EXEC":
        command = payload.get("command", "")
        return {"type": "MATRIX_RESULT", "data": {"status": "SUCCESS",
                "output": f"Comando Matrix '{command}' asimilado. Flujo n8n sincronizado."}}

    elif action == "ADMIN_TITANS":
        # Administrar todos los Titanes con una orden
        order = payload.get("order", "")
        for tk in TITANS:
            assign_titan_task(tk, f"Orden del Oraculo: {order}")
        return {"type": "TITANS_ADMINISTERED", "data": {
            "order": order, "titans": get_titan_status(),
            "message": "Los 4 Titanes han recibido la orden y estan ejecutando."}}

    return {"type": "ACK", "data": {"status": "OK"}}


async def handle_client(websocket):
    CONNECTED_CLIENTS.add(websocket)
    print(f"[CosmicBroker] Nuevo cliente conectado desde Godot.")
    try:
        await websocket.send(json.dumps({
            "type": "ORACLE_STATUS",
            "data": {
                "oracle": "ONLINE",
                "message": "Bienvenido Kevin. Soy el Oraculo Supremo de Urantino. Listo para codificar la Matrix y gobernar los 4 Titanes.",
                "titanes": {k: v["status"] for k, v in TITANS.items()}
            }
        }))

        async for message in websocket:
            data = json.loads(message)
            action = data.get("action")
            payload = data.get("data", {})
            print(f"[CosmicBroker] Accion recibida: {action}")
            response = await process_action(action, payload)
            await websocket.send(json.dumps(response))

    except Exception as e:
        print(f"[CosmicBroker] Error o desconexion: {e}")
    finally:
        CONNECTED_CLIENTS.discard(websocket)


async def broadcast(message):
    """Enviar mensaje a todos los clientes conectados."""
    if CONNECTED_CLIENTS:
        await asyncio.gather(*[ws.send(json.dumps(message)) for ws in CONNECTED_CLIENTS],
                            return_exceptions=True)


async def main():
    import websockets
    print("==================================================")
    print("   COSMIC BROKER & ORACULO SUPREMO KRC ACTIVO      ")
    print("   Escuchando en ws://127.0.0.1:8765               ")
    print("   IA: Gemini 2.5 Flash | Titanes: 4 ONLINE       ")
    print("==================================================")
    async with websockets.serve(handle_client, "127.0.0.1", 8765):
        await asyncio.Future()


if __name__ == "__main__":
    asyncio.run(main())