﻿import re
from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.tscn")
t = p.read_text(encoding="utf-8")

# add wood texture ext_resource (id 6) and bump load_steps by 1 (for texture resource usage stays same count? ext_resource doesn't count in sub_resources, load_steps in tscn is ext+sub total roughly; better to bump)
t = re.sub(r'\[gd_scene load_steps=(\d+) format=3\]', lambda m: f'[gd_scene load_steps={int(m.group(1))+1} format=3]', t, count=1)
t = t.replace('[ext_resource type="PackedScene" path="res://demonio_pintado.glb" id="5"]',
              '[ext_resource type="PackedScene" path="res://demonio_pintado.glb" id="5"]\n[ext_resource type="Texture2D" path="res://madera.jpg" id="6"]')

# textured MatMadera
old_mat = r'''[sub_resource type="StandardMaterial3D" id="MatMadera"]
albedo_color = Color(0.45, 0.32, 0.18, 1)
roughness = 0.85'''
new_mat = r'''[sub_resource type="StandardMaterial3D" id="MatMadera"]
albedo_texture = ExtResource("6")
uv1_scale = Vector3(2, 2, 1)
roughness = 0.82'''
t = t.replace(old_mat, new_mat)

# improve materials a bit
t = t.replace('albedo_color = Color(0.28, 0.24, 0.2, 1)\nroughness = 0.95',
              'albedo_color = Color(0.32, 0.27, 0.22, 1)\nroughness = 0.92')
t = t.replace('albedo_color = Color(0.38, 0.36, 0.32, 1)\nroughness = 0.9',
              'albedo_color = Color(0.42, 0.39, 0.34, 1)\nroughness = 0.88')
t = t.replace('albedo_color = Color(0.22, 0.2, 0.18, 1)\nroughness = 1.0',
              'albedo_color = Color(0.24, 0.22, 0.2, 1)\nroughness = 0.96')
t = t.replace('albedo_color = Color(0.12, 0.16, 0.1, 1)\nroughness = 1.0',
              'albedo_color = Color(0.1, 0.14, 0.09, 1)\nroughness = 1.0')

# better lighting
t = t.replace('light_energy = 0.6\nshadow_enabled = false', 'light_energy = 0.7\nshadow_enabled = false')
t = t.replace('light_energy = 0.25\nshadow_enabled = false', 'light_energy = 0.3\nshadow_enabled = false')
t = t.replace('light_energy = 1.4\nomni_range = 14.0\nshadow_enabled = false',
              'light_energy = 1.6\nomni_range = 15.0\nomni_attenuation = 1.1\nshadow_enabled = false')

# add W3 after W2 block
w2_block = r'''[node name="W2" parent="Player/Camera3D/WeaponHolder" instance=ExtResource("4")]
transform = Transform3D(-0.013, 0, 0, 0, 0.013, 0, 0, 0, -0.013, 0.02, -0.01, 0.02)
visible = false'''
w3_block = w2_block + r'''

[node name="W3" parent="Player/Camera3D/WeaponHolder" instance=ExtResource("4")]
transform = Transform3D(-0.014, 0, 0, 0, 0.014, 0, 0, 0, -0.014, 0.01, -0.015, 0.01)
visible = false'''
t = t.replace(w2_block, w3_block)

# add more zombies at end
more = r'''
[node name="Zombie7" type="CharacterBody3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 14, 1.0, 10)
script = ExtResource("2")

[node name="CollisionShape3D" type="CollisionShape3D" parent="Zombie7"]
shape = SubResource("ZombieShape")

[node name="Modelo" parent="Zombie7" instance=ExtResource("5")]
transform = Transform3D(0.012, 0, 0, 0, 0.012, 0, 0, 0, 0.012, 0, -0.9, 0)

[node name="Zombie8" type="CharacterBody3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -14, 1.0, -10)
script = ExtResource("2")

[node name="CollisionShape3D" type="CollisionShape3D" parent="Zombie8"]
shape = SubResource("ZombieShape")

[node name="Modelo" parent="Zombie8" instance=ExtResource("5")]
transform = Transform3D(0.012, 0, 0, 0, 0.012, 0, 0, 0, 0.012, 0, -0.9, 0)

[node name="Zombie9" type="CharacterBody3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 16, 1.0, -6)
script = ExtResource("2")

[node name="CollisionShape3D" type="CollisionShape3D" parent="Zombie9"]
shape = SubResource("ZombieShape")

[node name="Modelo" parent="Zombie9" instance=ExtResource("5")]
transform = Transform3D(0.012, 0, 0, 0, 0.012, 0, 0, 0, 0.012, 0, -0.9, 0)

[node name="Zombie10" type="CharacterBody3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -16, 1.0, 6)
script = ExtResource("2")

[node name="CollisionShape3D" type="CollisionShape3D" parent="Zombie10"]
shape = SubResource("ZombieShape")

[node name="Modelo" parent="Zombie10" instance=ExtResource("5")]
transform = Transform3D(0.012, 0, 0, 0, 0.012, 0, 0, 0, 0.012, 0, -0.9, 0)
'''
if 'Zombie7' not in t:
    t = t.rstrip() + "\n" + more

p.write_text(t, encoding="utf-8", newline="\n")
print("ok")
