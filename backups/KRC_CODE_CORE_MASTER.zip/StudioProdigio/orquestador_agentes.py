"""
ORQUESTADOR DE FRECUENCIA & AGENTES KABALION (Ciclo de 30 a 60 minutos)
Activa y sincroniza cada agente en sus tiempos específicos:
 - Agente 1 (Buscador Nostalgia): Cada 60 minutos actualiza el catálogo hacia 200 series.
 - Agente 2 (El Cronista - Lore): Investiga curiosidades y secretos de cada serie.
 - Agente 3 (El Alquimista): Monitorea tv_temp cada 30 minutos y compila si la cola baja.
 - Agente 4 (El Emisor): Emite perpetuamente sin pausas.
 - Agente 5 (Clipper Social): Extrae momentos virales y programa a las 12pm y 7pm.
"""
import sys, subprocess, time, json
from pathlib import Path
from datetime import datetime

PYTHON = r"C:\Users\kevin\AppData\Local\Programs\Python\Python312\python.exe"
STUDIO = Path(r"C:\Users\kevin\StudioProdigio")

def log(msg):
    ts = datetime.now().strftime("%H:%M:%S")
    print(f"[{ts}] {msg}", flush=True)

def ejecutar_script(nombre):
    p = STUDIO / nombre
    if p.exists():
        log(f"⚡ Disparando Agente: {nombre}")
        subprocess.Popen([PYTHON, str(p)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def loop_orquestador():
    log("=========================================================")
    log("  👑 ORQUESTADOR MAESTRO DE AGENTES KABALION (24/7)     ")
    log("=========================================================")
    
    ultimo_escaneo_series = 0
    ultimo_escaneo_edicion = 0
    
    while True:
        ahora = time.time()
        
        # 1. Agente Explorador (Cada 60 minutos)
        if ahora - ultimo_escaneo_series >= 3600:
            ejecutar_script("buscador_series.py")
            ultimo_escaneo_series = ahora
            
        # 2. Agente Clipper de Redes (Cada 30 minutos)
        if ahora - ultimo_escaneo_edicion >= 1800:
            ejecutar_script("agente_clipper_redes.py")
            ultimo_escaneo_edicion = ahora
            
        time.sleep(60)

if __name__ == "__main__":
    loop_orquestador()
