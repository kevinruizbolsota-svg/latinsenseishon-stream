﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\player.gd")
t = p.read_text(encoding="utf-8")

# add onready refs
old_refs = r'''@onready var msg_label: Label = get_node_or_null("../UI/Msg")
@onready var hit_flash: ColorRect = get_node_or_null("../UI/HitFlash")'''
new_refs = r'''@onready var msg_label: Label = get_node_or_null("../UI/Msg")
@onready var hit_flash: ColorRect = get_node_or_null("../UI/HitFlash")
@onready var hit_marker: Label = get_node_or_null("../UI/HitMarker")
@onready var muzzle_flash: OmniLight3D = $Camera3D/MuzzleFlash
@onready var sfx_shot: AudioStreamPlayer = $SfxShot
@onready var sfx_shot_fast: AudioStreamPlayer = $SfxShotFast
@onready var sfx_reload: AudioStreamPlayer = $SfxReload
@onready var sfx_hit: AudioStreamPlayer = $SfxHit
@onready var sfx_empty: AudioStreamPlayer = $SfxEmpty
@onready var sfx_hurt: AudioStreamPlayer = $SfxHurt
@onready var sfx_kill: AudioStreamPlayer = $SfxKill'''
if old_refs in t: t = t.replace(old_refs, new_refs)

# add vars
old_vars = r'''var _msg_timer := 0.0'''
new_vars = r'''var _msg_timer := 0.0
var _flash_timer := 0.0
var _hitmarker_timer := 0.0
var _recoil := 0.0'''
if old_vars in t: t = t.replace(old_vars, new_vars)

# physics process: muzzle flash timer, hitmarker timer, recoil recovery
old_pp = r'''	if _msg_timer > 0.0:
		_msg_timer -= delta
		if _msg_timer <= 0.0 and msg_label:
			msg_label.text = ""
	if hit_flash and hit_flash.color.a > 0.0:
		hit_flash.color.a = max(hit_flash.color.a - delta * 1.5, 0.0)'''
new_pp = r'''	if _msg_timer > 0.0:
		_msg_timer -= delta
		if _msg_timer <= 0.0 and msg_label:
			msg_label.text = ""
	if hit_flash and hit_flash.color.a > 0.0:
		hit_flash.color.a = max(hit_flash.color.a - delta * 1.5, 0.0)
	if _flash_timer > 0.0:
		_flash_timer -= delta
		if _flash_timer <= 0.0 and muzzle_flash:
			muzzle_flash.visible = false
	if _hitmarker_timer > 0.0:
		_hitmarker_timer -= delta
		if _hitmarker_timer <= 0.0 and hit_marker:
			hit_marker.text = ""
	# recoil recovery
	if _recoil > 0.0:
		var rec = min(_recoil, delta * 3.5)
		camera.rotation.x = clamp(camera.rotation.x - rec, -1.45, 1.45)
		_recoil -= rec'''
if old_pp in t: t = t.replace(old_pp, new_pp)

# shoot: sounds, muzzle flash, recoil per weapon, hit marker on hit
old_shoot = r'''func _shoot():
	var w = weapons[current_weapon]
	if w.mag <= 0:
		_start_reload()
		return
	w.mag -= 1
	shoot_cd = w.rate
	camera.rotation.x = clamp(camera.rotation.x + 0.012, -1.45, 1.45)
	if ray and ray.is_colliding():
		var c = ray.get_collider()
		if c and c.has_method("take_damage") and c.is_in_group("zombie"):
			c.take_damage(w.damage)
		elif c and c.has_method("take_damage"):
			c.take_damage(w.damage)
	_update_ui()'''
new_shoot = r'''func _shoot():
	var w = weapons[current_weapon]
	if w.mag <= 0:
		if sfx_empty: sfx_empty.play()
		_start_reload()
		return
	w.mag -= 1
	shoot_cd = w.rate
	# recoil
	var kick = 0.018 if current_weapon == 0 else (0.012 if current_weapon == 1 else 0.01)
	camera.rotation.x = clamp(camera.rotation.x + kick, -1.45, 1.45)
	_recoil += kick * 0.7
	# muzzle flash
	if muzzle_flash:
		muzzle_flash.visible = true
		_flash_timer = 0.04
	# sound
	if current_weapon == 0:
		if sfx_shot: sfx_shot.play()
	else:
		if sfx_shot_fast: sfx_shot_fast.play()
	# raycast
	if ray and ray.is_colliding():
		var c = ray.get_collider()
		var hit_target = c and c.has_method("take_damage")
		if hit_target and c.is_in_group("zombie"):
			c.take_damage(w.damage)
			if sfx_hit: sfx_hit.play()
			if hit_marker:
				hit_marker.text = "x"
				_hitmarker_timer = 0.12
		elif hit_target:
			c.take_damage(w.damage)
			if sfx_hit: sfx_hit.play()
			if hit_marker:
				hit_marker.text = "x"
				_hitmarker_timer = 0.12
	_update_ui()'''
if old_shoot in t: t = t.replace(old_shoot, new_shoot)

# reload sounds
old_reload = r'''func _start_reload():
	var w = weapons[current_weapon]
	if reload_cd > 0.0 or w.mag >= w.mag_max or w.reserve <= 0:
		return
	reload_cd = 1.6
	_show_msg("Recargando...")
	_update_ui()'''
new_reload = r'''func _start_reload():
	var w = weapons[current_weapon]
	if reload_cd > 0.0 or w.mag >= w.mag_max or w.reserve <= 0:
		return
	reload_cd = 1.6
	_show_msg("Recargando...")
	if sfx_reload: sfx_reload.play()
	_update_ui()'''
if old_reload in t: t = t.replace(old_reload, new_reload)

# hurt sound in take_damage
old_dmg = r'''	health = max(health - amount, 0)
	_show_msg("¡Te golpearon! -%d" % amount)
	if hit_flash:
		hit_flash.color = Color(0.7, 0, 0, 0.35)'''
new_dmg = r'''	health = max(health - amount, 0)
	_show_msg("¡Te golpearon! -%d" % amount)
	if sfx_hurt: sfx_hurt.play()
	if hit_flash:
		hit_flash.color = Color(0.7, 0, 0, 0.35)'''
if old_dmg in t: t = t.replace(old_dmg, new_dmg)

# kill sound in add_kill_reward
old_kill = r'''func add_kill_reward(pts: int = 10):
	points += pts
	kills += 1
	_update_ui()'''
new_kill = r'''func add_kill_reward(pts: int = 10):
	points += pts
	kills += 1
	if sfx_kill: sfx_kill.play()
	if hit_marker:
		hit_marker.text = "X"
		_hitmarker_timer = 0.18
	_update_ui()'''
if old_kill in t: t = t.replace(old_kill, new_kill)

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
