"""
KABALION VIDEO FACTORY - Generador de Videos con IA desde Codigo
Kevin Esteban Ruiz Calle (KRC)

Modos de generacion:
1. FFMPEG (composicion de imagenes/texto/audio) - Gratis, local
2. STABLE_DIFFUSION (frames IA + FFmpeg) - Gratis/API
3. GEMINI (guion IA + frames + compilacion) - API
4. MANIM (animaciones matematicas/codigo) - Gratis, local

Uso:
  python video_factory.py --mode ffmpeg --prompt "Video de presentacion KRC"
  python video_factory.py --mode gemini --prompt "Video viral de TikTok sobre trading"
  python video_factory.py --mode manim --prompt "Animacion de formulas matematicas"
"""
import os
import sys
import json
import subprocess
import time
import argparse
from pathlib import Path
from datetime import datetime

# === RUTAS ===
STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
FFMPEG = Path(r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe")
OUTPUT_DIR = STUDIO / "videos_generados"
TEMP_DIR = STUDIO / "video_temp"
PYTHON = sys.executable

# API Keys
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "")

# Crear directorios
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
TEMP_DIR.mkdir(parents=True, exist_ok=True)

# === FUNCIONES AUXILIARES ===

def ff(*args):
    """Ejecuta FFmpeg."""
    r = subprocess.run([str(FFMPEG)] + list(args), capture_output=True, text=True)
    return r.returncode == 0, r.stderr

def call_gemini(prompt, system=None):
    """Llama a Gemini API."""
    import urllib.request
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={GEMINI_API_KEY}"
    contents = [{"role": "user", "parts": [{"text": prompt}]}]
    payload = {"contents": contents}
    if system:
        payload["systemInstruction"] = {"parts": [{"text": system}]}
    req = urllib.request.Request(url, data=json.dumps(payload).encode(), headers={"Content-Type": "application/json"})
    try:
        resp = urllib.request.urlopen(req, timeout=60)
        data = json.loads(resp.read())
        return data["candidates"][0]["content"]["parts"][0]["text"]
    except Exception as e:
        return f"Error: {e}"

def call_groq(prompt, system=None):
    """Llama a Groq API."""
    import urllib.request
    url = "https://api.groq.com/openai/v1/chat/completions"
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    payload = {"model": "llama-3.3-70b-versatile", "messages": messages, "max_tokens": 2048}
    req = urllib.request.Request(url, data=json.dumps(payload).encode(),
        headers={"Authorization": f"Bearer {GROQ_API_KEY}", "Content-Type": "application/json"})
    try:
        resp = urllib.request.urlopen(req, timeout=60)
        data = json.loads(resp.read())
        return data["choices"][0]["message"]["content"]
    except Exception as e:
        return f"Error: {e}"

# === MODO 1: FFMPEG COMPOSICION ===

def generate_ffmpeg_video(prompt, duration=10, style="cinematic"):
    """Genera video componiendo texto, fondos y audio con FFmpeg."""
    print(f"\n[FFmpeg] Generando video: '{prompt}' ({duration}s, estilo: {style})")
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = OUTPUT_DIR / f"ffmpeg_{timestamp}.mp4"

    # Generar guion con Gemini
    guion = call_gemini(
        f"Genera un guion para un video de {duration} segundos sobre: {prompt}. "
        f"Estilo: {style}. Formato: lista de escenas con texto en pantalla y descripcion visual. "
        f"Maximo 5 escenas. Responde en JSON con formato: [{{'escena':1,'texto':'...','visual':'...','duracion':2}}]"
    )
    print(f"  Guion generado: {guion[:200]}...")

    # Crear frames de texto
    frames_dir = TEMP_DIR / f"frames_{timestamp}"
    frames_dir.mkdir(exist_ok=True)

    try:
        guion_data = json.loads(guion)
    except:
        guion_data = [{"escena": 1, "texto": prompt, "visual": "fondo negro", "duracion": duration}]

    # Generar cada frame con FFmpeg (texto sobre fondo)
    frame_num = 0
    for scene in guion_data:
        text = scene.get("texto", prompt)
        dur = scene.get("duracion", 2)
        fps = 30
        frames_for_scene = int(dur * fps)

        # Crear imagen con texto usando FFmpeg
        for i in range(frames_for_scene):
            frame_path = frames_dir / f"frame_{frame_num:05d}.png"
            ok, err = ff(
                "-y", "-f", "lavfi", "-i", f"color=c=0x1a1a2e:s=1280x720:d=1",
                "-vf", f"drawtext=text='{text}':fontcolor=white:fontsize=48:x=(w-text_w)/2:y=(h-text_h)/2:box=1:boxcolor=black@0.5:boxborderw=10",
                "-frames:v", "1", str(frame_path)
            )
            frame_num += 1

    # Compilar frames en video
    print(f"  Compilando {frame_num} frames...")
    ok, err = ff(
        "-y", "-framerate", "30", "-i", str(frames_dir / "frame_%05d.png"),
        "-c:v", "libx264", "-preset", "fast", "-b:v", "2500k",
        "-pix_fmt", "yuv420p", str(output_file)
    )

    if ok and output_file.exists():
        print(f"  Video generado: {output_file}")
        return str(output_file)
    else:
        print(f"  Error: {err[:300]}")
        return None

# === MODO 2: GEMINI + FRAMES IA ===

def generate_gemini_video(prompt, duration=15, style="cinematic"):
    """Genera video usando Gemini para guion + frames con Stable Diffusion (si disponible)."""
    print(f"\n[Gemini] Generando video: '{prompt}' ({duration}s)")

    # Generar guion detallado
    guion = call_gemini(
        f"Genera un guion cinematografico para un video de {duration} segundos sobre: {prompt}. "
        f"Estilo: {style}. "
        f"Responde en JSON: {{'titulo':'...','escenas':[{{'num':1,'descripcion':'...','texto_pantalla':'...','duracion':3,'prompt_imagen':'prompt para generar imagen IA'}}]}}"
    )
    print(f"  Guion: {guion[:300]}...")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = OUTPUT_DIR / f"gemini_{timestamp}.mp4"

    try:
        guion_data = json.loads(guion)
    except:
        guion_data = {"titulo": prompt, "escenas": [{"num": 1, "descripcion": prompt, "texto_pantalla": prompt, "duracion": duration, "prompt_imagen": prompt}]}

    # Generar frames con texto (sin IA de imagen por ahora, pero estructura lista)
    frames_dir = TEMP_DIR / f"gemini_frames_{timestamp}"
    frames_dir.mkdir(exist_ok=True)

    frame_num = 0
    for scene in guion_data.get("escenas", []):
        text = scene.get("texto_pantalla", "")
        dur = scene.get("duracion", 3)
        fps = 30
        frames_for_scene = int(dur * fps)

        for i in range(frames_for_scene):
            frame_path = frames_dir / f"frame_{frame_num:05d}.png"
            # Fondo con gradiente + texto
            ok, err = ff(
                "-y", "-f", "lavfi", "-i", f"color=c=0x0f3460:s=1280x720:d=1",
                "-vf", f"drawtext=text='{text}':fontcolor=white:fontsize=52:x=(w-text_w)/2:y=(h-text_h)/2:box=1:boxcolor=0x16213e@0.7:boxborderw=15,drawtext=text='{guion_data.get('titulo','')}':fontcolor=0xe94560:fontsize=28:x=(w-text_w)/2:y=50",
                "-frames:v", "1", str(frame_path)
            )
            frame_num += 1

    # Compilar
    print(f"  Compilando {frame_num} frames...")
    ok, err = ff(
        "-y", "-framerate", "30", "-i", str(frames_dir / "frame_%05d.png"),
        "-c:v", "libx264", "-preset", "fast", "-b:v", "3000k",
        "-pix_fmt", "yuv420p", str(output_file)
    )

    if ok and output_file.exists():
        print(f"  Video generado: {output_file}")
        # Guardar guion
        guion_file = OUTPUT_DIR / f"gemini_{timestamp}_guion.json"
        guion_file.write_text(json.dumps(guion_data, ensure_ascii=False, indent=2), encoding="utf-8")
        return str(output_file)
    else:
        print(f"  Error: {err[:300]}")
        return None

# === MODO 3: MANIM (Animaciones de codigo) ===

def generate_manim_video(prompt, duration=10):
    """Genera video con animaciones matematicas usando Manim (si esta instalado)."""
    print(f"\n[Manim] Generando animacion: '{prompt}'")

    # Verificar si Manim esta instalado
    try:
        import manim
        print("  Manim disponible")
    except ImportError:
        print("  Manim no instalado. Instalando...")
        subprocess.run([PYTHON, "-m", "pip", "install", "manim"], capture_output=True)
        try:
            import manim
            print("  Manim instalado correctamente")
        except ImportError:
            print("  Error: No se pudo instalar Manim. Usando FFmpeg como fallback.")
            return generate_ffmpeg_video(prompt, duration, "manim_fallback")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = OUTPUT_DIR / f"manim_{timestamp}.mp4"

    # Generar codigo Manim con Gemini
    codigo = call_gemini(
        f"Genera codigo Python para Manim (Community Edition) que cree una animacion sobre: {prompt}. "
        f"Duracion aproximada: {duration} segundos. "
        f"Usa clases de manim como Scene, Text, MathTex, Create, Write, FadeIn, etc. "
        f"Responde SOLO con el codigo Python, sin explicaciones. "
        f"La clase principal debe llamarse VideoScene y extender de Scene."
    )

    # Limpiar codigo (remover markdown)
    codigo = codigo.replace("```python", "").replace("```", "").strip()

    # Guardar script
    script_path = TEMP_DIR / f"manim_script_{timestamp}.py"
    script_path.write_text(codigo, encoding="utf-8")
    print(f"  Script guardado: {script_path}")

    # Ejecutar Manim
    result = subprocess.run(
        [PYTHON, "-m", "manim", str(script_path), "VideoScene", "-o", str(output_file), "--media_dir", str(TEMP_DIR)],
        capture_output=True, text=True, timeout=300
    )

    if result.returncode == 0:
        # Buscar el archivo generado
        for f in TEMP_DIR.rglob("*.mp4"):
            if f.stat().st_mtime > time.time() - 60:
                import shutil
                shutil.copy(str(f), str(output_file))
                print(f"  Video generado: {output_file}")
                return str(output_file)
    else:
        print(f"  Error Manim: {result.stderr[:300]}")
        return generate_ffmpeg_video(prompt, duration, "manim_fallback")

# === MODO 4: MOVIEPY (Composicion avanzada de video) ===

def generate_moviepy_video(prompt, duration=15, style="cinematic"):
    """Genera video usando MoviePy para composicion avanzada de clips, texto, audio."""
    print(f"\n[MoviePy] Generando video: '{prompt}' ({duration}s, estilo: {style})")
    from moviepy.editor import (TextClip, ColorClip, CompositeVideoClip,
                                AudioFileClip, concatenate_videoclips, ImageClip)
    import numpy as np

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = OUTPUT_DIR / f"moviepy_{timestamp}.mp4"

    # Generar guion con Gemini
    guion = call_gemini(
        f"Genera un guion para video de {duration} segundos sobre: {prompt}. "
        f"Estilo: {style}. "
        f"Responde en JSON: {{'titulo':'...','escenas':[{{'num':1,'texto':'...','color':'#hex','duracion':3,'efecto':'fade/slide/zoom'}}]}}"
    )
    print(f"  Guion: {guion[:200]}...")

    try:
        guion_data = json.loads(guion)
    except:
        guion_data = {"titulo": prompt, "escenas": [{"num": 1, "texto": prompt, "color": "#1a1a2e", "duracion": duration, "efecto": "fade"}]}

    # Crear clips para cada escena
    clips = []
    for scene in guion_data.get("escenas", []):
        text = scene.get("texto", "")
        color = scene.get("color", "#1a1a2e")
        dur = scene.get("duracion", 3)
        efecto = scene.get("efecto", "fade")

        # Fondo de color
        bg = ColorClip(size=(1280, 720), color=hex_to_rgb(color), duration=dur)

        # Texto
        try:
            txt = TextClip(text, fontsize=52, color="white", font="Arial",
                          method="caption", size=(1100, None))
            txt = txt.set_position("center").set_duration(dur)
            if efecto == "fade":
                txt = txt.crossfadein(0.5).crossfadeout(0.5)
            clip = CompositeVideoClip([bg, txt], size=(1280, 720)).set_duration(dur)
        except Exception as e:
            print(f"  TextClip error: {e}. Usando solo fondo.")
            clip = bg

        clips.append(clip)

    # Concatenar clips
    if clips:
        final = concatenate_videoclips(clips, method="compose")
        final.write_videofile(str(output_file), fps=30, codec="libx264",
                            audio_codec="aac", preset="fast", logger=None)
        print(f"  Video generado: {output_file}")
        guion_file = OUTPUT_DIR / f"moviepy_{timestamp}_guion.json"
        guion_file.write_text(json.dumps(guion_data, ensure_ascii=False, indent=2), encoding="utf-8")
        return str(output_file)
    return None

def hex_to_rgb(hex_color):
    """Convierte hex a RGB tuple."""
    hex_color = hex_color.lstrip("#")
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

# === MODO 5: STABLE DIFFUSION + ANIMATEDIFF ===

def generate_sd_animatediff_video(prompt, duration=10, style="cinematic"):
    """Genera video usando Stable Diffusion + AnimateDiff (si disponible)."""
    print(f"\n[SD+AnimateDiff] Generando video: '{prompt}' ({duration}s)")

    # Verificar disponibilidad
    sd_available = False
    try:
        import torch
        from diffusers import AnimateDiffPipeline, MotionAdapter
        sd_available = True
        print("  AnimateDiff disponible!")
    except ImportError:
        print("  AnimateDiff no instalado. Intentando instalar...")
        subprocess.run([PYTHON, "-m", "pip", "install", "diffusers", "transformers", "accelerate", "torch"], capture_output=True, timeout=300)
        try:
            import torch
            from diffusers import AnimateDiffPipeline, MotionAdapter
            sd_available = True
            print("  AnimateDiff instalado!")
        except ImportError:
            print("  No se pudo instalar AnimateDiff. Usando FFmpeg como fallback.")
            return generate_gemini_video(prompt, duration, style)

    if not sd_available:
        return generate_gemini_video(prompt, duration, style)

    import torch
    from diffusers import AnimateDiffPipeline, MotionAdapter, DDIMScheduler

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = OUTPUT_DIR / f"sd_animatediff_{timestamp}.mp4"

    # Generar prompt optimizado para SD
    sd_prompt = call_gemini(
        f"Optimiza este prompt para Stable Diffusion (AnimateDiff): {prompt}. "
        f"Estilo: {style}. "
        f"Responde SOLO con el prompt optimizado en ingles, maximo 75 palabras. "
        f"Incluye detalles de iluminacion, calidad, estilo artistico."
    )
    print(f"  SD Prompt: {sd_prompt}")

    try:
        # Cargar modelo
        adapter = MotionAdapter.from_pretrained("guoyww/animatediff-motion-adapter-v1-5-2")
        pipe = AnimateDiffPipeline.from_pretrained(
            "runwayml/stable-diffusion-v1-5",
            motion_adapter=adapter,
            torch_dtype=torch.float16
        )
        pipe.scheduler = DDIMScheduler.from_config(pipe.scheduler.config)
        pipe.to("cuda" if torch.cuda.is_available() else "cpu")

        # Generar frames
        num_frames = duration * 8  # 8 fps para AnimateDiff
        output = pipe(
            prompt=sd_prompt,
            num_frames=num_frames,
            guidance_scale=7.5,
            num_inference_steps=25,
            height=512,
            width=512
        )

        # Guardar como video
        frames = output.frames[0]
        frames_dir = TEMP_DIR / f"sd_frames_{timestamp}"
        frames_dir.mkdir(exist_ok=True)
        for i, frame in enumerate(frames):
            frame.save(str(frames_dir / f"frame_{i:05d}.png"))

        # Compilar con FFmpeg a 1280x720
        ok, err = ff(
            "-y", "-framerate", "8", "-i", str(frames_dir / "frame_%05d.png"),
            "-vf", "scale=1280:720:flags=lanczos",
            "-c:v", "libx264", "-preset", "fast", "-b:v", "3000k",
            "-pix_fmt", "yuv420p", "-r", "30", str(output_file)
        )

        if ok and output_file.exists():
            print(f"  Video SD generado: {output_file}")
            return str(output_file)
        else:
            print(f"  Error compilando: {err[:300]}")
            return generate_gemini_video(prompt, duration, style)

    except Exception as e:
        print(f"  Error SD: {str(e)[:300]}")
        print("  Usando fallback Gemini...")
        return generate_gemini_video(prompt, duration, style)

# === MODO 4: VIDEO CON IA DE IMAGEN (Stable Diffusion) ===

def generate_ai_video(prompt, duration=10, style="cinematic"):
    """Genera video usando IA para imagenes + FFmpeg para composicion."""
    print(f"\n[AI Video] Generando video con IA: '{prompt}' ({duration}s)")

    # Generar guion con escenas
    guion = call_gemini(
        f"Genera un guion para video de {duration} segundos sobre: {prompt}. "
        f"Estilo: {style}. "
        f"Responde en JSON: {{'titulo':'...','escenas':[{{'num':1,'descripcion':'...','texto':'...','duracion':3,'prompt_sd':'prompt detallado para Stable Diffusion'}}]}}"
    )

    try:
        guion_data = json.loads(guion)
    except:
        guion_data = {"titulo": prompt, "escenas": [{"num": 1, "descripcion": prompt, "texto": prompt, "duracion": duration, "prompt_sd": prompt}]}

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    frames_dir = TEMP_DIR / f"ai_frames_{timestamp}"
    frames_dir.mkdir(exist_ok=True)
    output_file = OUTPUT_DIR / f"ai_video_{timestamp}.mp4"

    # Intentar usar Stable Diffusion local (si esta disponible)
    sd_available = False
    try:
        import torch
        from diffusers import StableDiffusionPipeline
        sd_available = True
    except ImportError:
        print("  Stable Diffusion no disponible localmente. Usando FFmpeg con texto.")

    frame_num = 0
    for scene in guion_data.get("escenas", []):
        text = scene.get("texto", "")
        dur = scene.get("duracion", 3)
        fps = 30
        frames_for_scene = int(dur * fps)
        sd_prompt = scene.get("prompt_sd", text)

        for i in range(frames_for_scene):
            frame_path = frames_dir / f"frame_{frame_num:05d}.png"

            if sd_available:
                # Generar imagen con SD (implementar si esta disponible)
                pass
            else:
                # Fallback: FFmpeg con texto y gradiente
                colors = ["0x1a1a2e", "0x16213e", "0x0f3460", "0x533483", "0xe94560"]
                color = colors[frame_num % len(colors)]
                ok, err = ff(
                    "-y", "-f", "lavfi", "-i", f"color=c={color}:s=1280x720:d=1",
                    "-vf", f"drawtext=text='{text}':fontcolor=white:fontsize=52:x=(w-text_w)/2:y=(h-text_h)/2:box=1:boxcolor=black@0.6:boxborderw=15,drawtext=text='{guion_data.get('titulo','')}':fontcolor=0xe94560:fontsize=24:x=(w-text_w)/2:y=40",
                    "-frames:v", "1", str(frame_path)
                )
            frame_num += 1

    # Compilar
    print(f"  Compilando {frame_num} frames...")
    ok, err = ff(
        "-y", "-framerate", "30", "-i", str(frames_dir / "frame_%05d.png"),
        "-c:v", "libx264", "-preset", "fast", "-b:v", "3000k",
        "-pix_fmt", "yuv420p", str(output_file)
    )

    if ok and output_file.exists():
        print(f"  Video generado: {output_file}")
        guion_file = OUTPUT_DIR / f"ai_{timestamp}_guion.json"
        guion_file.write_text(json.dumps(guion_data, ensure_ascii=False, indent=2), encoding="utf-8")
        return str(output_file)
    else:
        print(f"  Error: {err[:300]}")
        return None

# === MAIN ===

def main():
    parser = argparse.ArgumentParser(description="Kabalion Video Factory - Generador de Videos con IA")
    parser.add_argument("--mode", choices=["ffmpeg", "gemini", "manim", "ai", "moviepy", "sd"], default="gemini",
                        help="Modo de generacion: ffmpeg, gemini, manim, ai, moviepy, sd")
    parser.add_argument("--prompt", type=str, required=True, help="Descripcion del video")
    parser.add_argument("--duration", type=int, default=15, help="Duracion en segundos")
    parser.add_argument("--style", type=str, default="cinematic", help="Estilo del video")
    args = parser.parse_args()

    print("=" * 60)
    print("  KABALION VIDEO FACTORY - Generador de Videos con IA")
    print("  Kevin Esteban Ruiz Calle (KRC)")
    print("=" * 60)
    print(f"  Modo: {args.mode}")
    print(f"  Prompt: {args.prompt}")
    print(f"  Duracion: {args.duration}s")
    print(f"  Estilo: {args.style}")
    print("=" * 60)

    result = None
    if args.mode == "ffmpeg":
        result = generate_ffmpeg_video(args.prompt, args.duration, args.style)
    elif args.mode == "gemini":
        result = generate_gemini_video(args.prompt, args.duration, args.style)
    elif args.mode == "manim":
        result = generate_manim_video(args.prompt, args.duration)
    elif args.mode == "ai":
        result = generate_ai_video(args.prompt, args.duration, args.style)
    elif args.mode == "moviepy":
        result = generate_moviepy_video(args.prompt, args.duration, args.style)
    elif args.mode == "sd":
        result = generate_sd_animatediff_video(args.prompt, args.duration, args.style)

    if result:
        print(f"\n✅ VIDEO GENERADO: {result}")
    else:
        print("\n❌ Error generando video")

if __name__ == "__main__":
    main()
