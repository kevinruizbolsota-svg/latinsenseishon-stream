"""
KABALION TV 24/7 - Sistema de Televisión Automatizado
Motor de búsqueda automática de series + playlist infinito + streaming RTMP
Kevin Esteban Ruiz Calle (KRC)
"""

# =============================================================================
# CATÁLOGO MAESTRO DE SERIES - Organizadas por canal/red
# La IA busca automáticamente las playlists en YouTube y las agrega aquí
# =============================================================================

CATALOGO_SERIES = {

    # ═══════ CARTOON NETWORK ═══════
    "cartoon_network": [
        {"titulo": "El Chavo del 8",         "playlist": "https://www.youtube.com/playlist?list=PLuxcLq9n25BEINVPnsS419gD8E6WSeiS-", "activo": True},
        {"titulo": "El Chavo Animado",        "playlist": "https://www.youtube.com/playlist?list=PLuKg-WnCU1f_DxFkB0aHMI-UqPdaTDe_j", "activo": True},
        {"titulo": "Dragon Ball Z",           "playlist": "https://www.youtube.com/playlist?list=PLxqR1nAef2BHfk0hCGdNFzBjhp6hm9M4v", "activo": True},
        {"titulo": "Dragon Ball GT",          "playlist": "https://www.youtube.com/playlist?list=PLxqR1nAef2BHRE4wXyZ1GAbOKQ8V7lsVB", "activo": True},
        {"titulo": "Coraje el Perro Cobarde", "playlist": "https://www.youtube.com/playlist?list=PLuKg-WnCU1f99bALRWBjENwzlFVJQ78VH", "activo": True},
        {"titulo": "Dexter",                  "playlist": "https://www.youtube.com/playlist?list=PLBF2A0FEAE2D9B23A",                  "activo": True},
        {"titulo": "Johnny Bravo",            "playlist": "https://www.youtube.com/playlist?list=PLOaxFCwFTCqMiETcHoX3BoO9A2BDJP_SC", "activo": True},
        {"titulo": "El Lab de Dexter",        "playlist": "https://www.youtube.com/playlist?list=PLuKg-WnCU1f_6vV1X5SBOIeIbEJkMGX_e", "activo": True},
    ],

    # ═══════ NICKELODEON ═══════
    "nickelodeon": [
        {"titulo": "Bob Esponja",             "playlist": "https://www.youtube.com/playlist?list=PLuKg-WnCU1f_YX8R-3JD8g5mGdGl6BTWL", "activo": True},
        {"titulo": "Avatar La Leyenda",       "playlist": "https://www.youtube.com/playlist?list=PLuKg-WnCU1f_cT4PdTbRy5VW49zl1b_Nk", "activo": True},
        {"titulo": "El Padrino Mágico",       "playlist": "https://www.youtube.com/playlist?list=PLuKg-WnCU1f_p_AVZ1QbMSUNrh30s-KPz", "activo": True},
        {"titulo": "Jimmy Neutron",           "playlist": "https://www.youtube.com/playlist?list=PLuKg-WnCU1f_m5HSRqXjRj53AZxqxpY_I", "activo": True},
    ],

    # ═══════ DISNEY XD ═══════
    "disney_xd": [
        {"titulo": "Los Simpsons",            "playlist": "https://www.youtube.com/playlist?list=PLhN5WQMJ62L3VCSS7XKWzVFBN67GCe6U5", "activo": True},
        {"titulo": "Kim Possible",            "playlist": "https://www.youtube.com/playlist?list=PLuKg-WnCU1f8bq6IyXhfzqG7JfYgmvZ-9", "activo": True},
        {"titulo": "Phineas y Ferb",          "playlist": "https://www.youtube.com/playlist?list=PLuKg-WnCU1f_a6pf3h9HNdyvhVvMMjqSB", "activo": True},
    ],

    # ═══════ ANIME ═══════
    "anime": [
        {"titulo": "Dragon Ball Super",       "playlist": "https://www.youtube.com/playlist?list=PLxqR1nAef2BHrOLlpXxPZf0Iqk0mLcEbR", "activo": True},
        {"titulo": "Naruto",                  "playlist": "https://www.youtube.com/playlist?list=PLBzpF0bAQ1yGJN8DKq0a3V1SiHCPTJkYi", "activo": True},
        {"titulo": "One Piece",               "playlist": "https://www.youtube.com/playlist?list=PLxqR1nAef2BHHi8bWKC0AMQC4GZ2KFjP3", "activo": True},
        {"titulo": "Saint Seiya Caballeros",  "playlist": "https://www.youtube.com/playlist?list=PLxqR1nAef2BHlZ4E5H9HnFvOUZJZcO1A5", "activo": True},
    ],
}

# =============================================================================
# BLOQUES DE PROGRAMACIÓN - Como un canal real
# =============================================================================
PROGRAMACION_TV = [
    # Hora      Canal               Duración episodios
    {"hora": "06:00", "canal": "cartoon_network", "serie_idx": 0,  "ep_count": 3},
    {"hora": "08:00", "canal": "nickelodeon",      "serie_idx": 0,  "ep_count": 3},
    {"hora": "10:00", "canal": "anime",            "serie_idx": 0,  "ep_count": 2},
    {"hora": "12:00", "canal": "cartoon_network",  "serie_idx": 1,  "ep_count": 3},
    {"hora": "14:00", "canal": "disney_xd",        "serie_idx": 0,  "ep_count": 3},
    {"hora": "16:00", "canal": "anime",            "serie_idx": 1,  "ep_count": 3},
    {"hora": "18:00", "canal": "nickelodeon",      "serie_idx": 1,  "ep_count": 2},
    {"hora": "20:00", "canal": "cartoon_network",  "serie_idx": 2,  "ep_count": 4},
    {"hora": "22:00", "canal": "anime",            "serie_idx": 2,  "ep_count": 3},
    {"hora": "00:00", "canal": "cartoon_network",  "serie_idx": 0,  "ep_count": 6},  # Maratón nocturno
]

PRINT_CATALOGO = True

if __name__ == "__main__" and PRINT_CATALOGO:
    total = sum(len(v) for v in CATALOGO_SERIES.values())
    print(f"\n╔══════════════════════════════════════════╗")
    print(f"║  KABALION TV - CATÁLOGO DE SERIES        ║")
    print(f"║  Total: {total} series en {len(CATALOGO_SERIES)} canales              ║")
    print(f"╚══════════════════════════════════════════╝\n")
    for canal, series in CATALOGO_SERIES.items():
        print(f"  📺 {canal.upper().replace('_',' ')}")
        for s in series:
            estado = "✅" if s["activo"] else "⏸"
            print(f"     {estado} {s['titulo']}")
    print(f"\n  📅 PROGRAMACIÓN: {len(PROGRAMACION_TV)} bloques horarios diarios")
