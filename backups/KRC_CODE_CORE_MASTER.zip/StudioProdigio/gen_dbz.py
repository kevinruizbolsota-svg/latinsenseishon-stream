import subprocess, sys
sys.argv = ['video_factory.py']
exec(open('video_factory.py').read().split('if __name__')[0])

# Generate DBZ episodes
episodes = [
    ("Dragon Ball Z - Frieza Saga Ep 1: Goku arrives on Namek", "anime", 10),
    ("Dragon Ball Z - Frieza Saga Ep 2: Battle with Frieza's elite soldiers", "anime", 10),
    ("Dragon Ball Z - Frieza Saga Ep 3: Goku vs Frieza begins", "anime", 10),
]

for i, (prompt, style, dur) in enumerate(episodes, 1):
    print(f"\n=== Generating Episode {i} ===")
    result = generate_gemini_video(prompt, dur, style)
    print(f"Result: {result}")
    if result:
        # Move to dbz_to_play folder
        import shutil
        from pathlib import Path
        src = Path(result)
        dst = Path(r"C:\Users\kevin\StudioProdigio\dbz_to_play") / f"dbz_ep{i:02d}.mp4"
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(str(src), str(dst))
        print(f"Copied to: {dst}")
