import sys, json, time
sys.path.insert(0, r"C:\Users\kevin\StudioProdigio")
import yt_dlp

# Search for Dragon Ball Z Frieza saga videos
queries = [
    "Dragon Ball Z saga Freezer episodio completo español latino",
    "Dragon Ball Z Freezer saga capitulo completo",
    "DBZ Freezer saga episodio español",
]

working = []
for query in queries:
    try:
        opts = {"extract_flat": True, "quiet": True, "default_search": "ytsearch10"}
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(f"ytsearch10:{query}", download=False)
            entries = info.get("entries", [])
            for e in entries:
                vid_id = e.get("id", "")
                title = e.get("title", "")
                duration = e.get("duration", 0)
                if vid_id and duration and 300 < duration < 1800:
                    # Test if downloadable
                    try:
                        test_opts = {"format": "best", "quiet": True, "no_warnings": True, "skip_download": True}
                        with yt_dlp.YoutubeDL(test_opts) as ydl2:
                            test_info = ydl2.extract_info(f"https://www.youtube.com/watch?v={vid_id}", download=False)
                        formats = test_info.get("formats", [])
                        if formats:
                            working.append({"id": vid_id, "title": title, "duration": duration})
                            print(f"OK: {title[:60]} ({duration}s)")
                            if len(working) >= 5:
                                break
                    except Exception as e:
                        pass
            time.sleep(2)
    except Exception as e:
        print(f"FAIL: {query}: {str(e)[:60]}")

print(f"\nTotal working DBZ videos: {len(working)}")
if working:
    with open(r"C:\Users\kevin\StudioProdigio\dbz_videos.json", "w", encoding="utf-8") as f:
        json.dump(working, f, ensure_ascii=False, indent=2)
    print("Saved to dbz_videos.json")
