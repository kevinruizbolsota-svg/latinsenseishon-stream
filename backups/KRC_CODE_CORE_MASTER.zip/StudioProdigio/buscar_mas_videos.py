import sys, json, time
sys.path.insert(0, r"C:\Users\kevin\StudioProdigio")
import yt_dlp

# Load existing found videos
existing = {}
try:
    with open(r"C:\Users\kevin\StudioProdigio\videos_encontrados.json", "r", encoding="utf-8") as f:
        existing = json.load(f)
except:
    pass

# More series to search
more_series = [
    "Coraje el Perro Cobarde capitulos completos español",
    "Dexter laboratorio capitulos completos español",
    "Johnny Bravo capitulos completos español",
    "Avatar La Leyenda de Aang capitulos completos español",
    "Kim Possible capitulos completos español",
    "Jimmy Neutron capitulos completos español",
    "Dragon Ball Super capitulos completos español",
    "Saint Seiya capitulos completos español",
    "Phineas y Ferb capitulos completos español",
    "Padrino Magico capitulos completos español",
]

working_videos = existing.copy()

for query in more_series:
    try:
        opts = {"extract_flat": True, "quiet": True, "default_search": "ytsearch5"}
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(f"ytsearch3:{query}", download=False)
            entries = info.get("entries", [])
            videos = []
            for e in entries:
                vid_id = e.get("id", "")
                title = e.get("title", "")
                if vid_id and "playlist" not in (e.get("url") or "").lower():
                    videos.append({"id": vid_id, "title": title})
            if videos:
                key = query.split(" capitulos")[0].split(" episodios")[0]
                working_videos[key] = videos[:3]
                print(f"OK: {key} - {len(videos[:3])} videos")
            time.sleep(2)
    except Exception as e:
        print(f"FAIL: {query}: {str(e)[:60]}")

# Save
with open(r"C:\Users\kevin\StudioProdigio\videos_encontrados.json", "w", encoding="utf-8") as f:
    json.dump(working_videos, f, ensure_ascii=False, indent=2)

total = sum(len(v) for v in working_videos.values())
print(f"\nTotal series: {len(working_videos)}, Total videos: {total}")
