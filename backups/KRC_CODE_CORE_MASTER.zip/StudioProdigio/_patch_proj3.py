﻿import re
from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\project.godot")
t = p.read_text(encoding="utf-8")
if 'weapon_3=' not in t:
    add = r'weapon_3={ "deadzone": 0.5, "events": [Object(InputEventKey,"resource_local_to_scene":false,"resource_name":"","device":-1,"window_id":0,"alt_pressed":false,"shift_pressed":false,"ctrl_pressed":false,"meta_pressed":false,"pressed":false,"keycode":0,"physical_keycode":51,"key_label":0,"unicode":51,"location":0,"echo":false,"script":null)] }
'
    t = t.replace('\n[rendering]', '\n' + add + '\n[rendering]')
p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
