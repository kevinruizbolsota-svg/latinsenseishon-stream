﻿import re
from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.tscn")
t = p.read_text(encoding="utf-8")

# --- Weapons: make more gun-like and adjust GLB model ---
old_w1 = r'''[node name="W1" type="Node3D" parent="Player/Camera3D/WeaponHolder"]

[node name="Modelo" parent="Player/Camera3D/WeaponHolder/W1" instance=ExtResource("4")]
transform = Transform3D(-1, 0, 0, 0, 1, 0, 0, 0, -1, 0, -0.05, 0.1)

[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.02, -0.15)
size = Vector3(0.08, 0.1, 0.55)
material = SubResource("MatTecho")

[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, -0.48)
size = Vector3(0.04, 0.04, 0.25)
material = SubResource("MatPared")'''
new_w1 = r'''[node name="W1" type="Node3D" parent="Player/Camera3D/WeaponHolder"]

[node name="Modelo" parent="Player/Camera3D/WeaponHolder/W1" instance=ExtResource("4")]
transform = Transform3D(0.9, 0, 0, 0, 0.9, 0, 0, 0, 0.9, 0, -0.08, -0.05)

[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.03, -0.18)
size = Vector3(0.07, 0.09, 0.5)
material = SubResource("MatMadera")

[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.0, -0.52)
size = Vector3(0.03, 0.03, 0.35)
material = SubResource("MatTecho")

[node name="Culata" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W1"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.04, 0.08)
size = Vector3(0.06, 0.1, 0.18)
material = SubResource("MatMadera")'''
if old_w1 in t: t = t.replace(old_w1, new_w1)

old_w2 = r'''[node name="W2" type="Node3D" parent="Player/Camera3D/WeaponHolder"]
visible = false

[node name="Modelo" parent="Player/Camera3D/WeaponHolder/W2" instance=ExtResource("4")]
transform = Transform3D(-1, 0, 0, 0, 1, 0, 0, 0, -1, 0, -0.05, 0.1)

[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.02, -0.12)
size = Vector3(0.07, 0.09, 0.45)
material = SubResource("MatPiso")

[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, -0.4)
size = Vector3(0.035, 0.035, 0.22)
material = SubResource("MatPared")'''
new_w2 = r'''[node name="W2" type="Node3D" parent="Player/Camera3D/WeaponHolder"]
visible = false

[node name="Modelo" parent="Player/Camera3D/WeaponHolder/W2" instance=ExtResource("4")]
transform = Transform3D(0.85, 0, 0, 0, 0.85, 0, 0, 0, 0.85, 0, -0.08, -0.05)

[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.02, -0.14)
size = Vector3(0.065, 0.085, 0.42)
material = SubResource("MatTecho")

[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.0, -0.43)
size = Vector3(0.028, 0.028, 0.3)
material = SubResource("MatPared")

[node name="Culata" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W2"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.03, 0.07)
size = Vector3(0.055, 0.09, 0.15)
material = SubResource("MatMadera")'''
if old_w2 in t: t = t.replace(old_w2, new_w2)

old_w3 = r'''[node name="W3" type="Node3D" parent="Player/Camera3D/WeaponHolder"]
visible = false

[node name="Modelo" parent="Player/Camera3D/WeaponHolder/W3" instance=ExtResource("4")]
transform = Transform3D(-1.1, 0, 0, 0, 1.1, 0, 0, 0, -1.1, 0, -0.06, 0.12)

[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.03, -0.18)
size = Vector3(0.09, 0.11, 0.6)
material = SubResource("MatMadera")

[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, -0.55)
size = Vector3(0.045, 0.045, 0.28)
material = SubResource("MatPared")'''
new_w3 = r'''[node name="W3" type="Node3D" parent="Player/Camera3D/WeaponHolder"]
visible = false

[node name="Modelo" parent="Player/Camera3D/WeaponHolder/W3" instance=ExtResource("4")]
transform = Transform3D(1.0, 0, 0, 0, 1.0, 0, 0, 0, 1.0, 0, -0.09, -0.06)

[node name="Cuerpo" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.03, -0.2)
size = Vector3(0.085, 0.1, 0.58)
material = SubResource("MatPared")

[node name="Canon" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.0, -0.58)
size = Vector3(0.035, 0.035, 0.38)
material = SubResource("MatTecho")

[node name="Culata" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.04, 0.1)
size = Vector3(0.065, 0.1, 0.2)
material = SubResource("MatMadera")

[node name="Cargador" type="CSGBox3D" parent="Player/Camera3D/WeaponHolder/W3"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.12, -0.12)
size = Vector3(0.04, 0.16, 0.08)
material = SubResource("MatTecho")'''
if old_w3 in t: t = t.replace(old_w3, new_w3)

# --- Zombies: hide green CSG fallback, make GLB model primary with better scale ---
# Replace Cuerpo+Cabeza blocks for each zombie with hidden/smaller fallbacks
for n in range(1, 13): # up to Zombie12
    old_z = f'''[node name="Cuerpo" type="CSGCylinder3D" parent="Zombie{n}"]
radius = 0.4
height = 1.5
material = SubResource("MatZombieFallback")

[node name="Cabeza" type="CSGSphere3D" parent="Zombie{n}"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.0, 0)
radius = 0.28
material = SubResource("MatZombieFallback")'''
    new_z = f'''[node name="Cuerpo" type="CSGCylinder3D" parent="Zombie{n}"]
visible = false
radius = 0.4
height = 1.5
material = SubResource("MatZombieFallback")

[node name="Cabeza" type="CSGSphere3D" parent="Zombie{n}"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.0, 0)
visible = false
radius = 0.28
material = SubResource("MatZombieFallback")'''
    if old_z in t:
        t = t.replace(old_z, new_z)

# Increase GLB model scale for zombies (was 0.012) - try 1.0 as baseline
t = t.replace('transform = Transform3D(0.012, 0, 0, 0, 0.012, 0, 0, 0, 0.012, 0, -0.9, 0)',
              'transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.9, 0)')

p.write_text(t, encoding="utf-8", newline="\n")
print("ok")
