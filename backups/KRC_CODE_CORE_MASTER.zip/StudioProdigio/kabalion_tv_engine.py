"""
KABALION TV ENGINE - Motor Central 24/7
Descarga, edita, compila y emite en bucle infinito como un canal de TV real
Kevin Esteban Ruiz Calle (KRC)
"""
import sys, subprocess, json, time, os, threading
from pathlib import Path
from datetime import datetime
import yt_dlp

# ═══ RUTAS ═══════════════════════════════════════════════════════
FFMPEG   = Path(r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe")
STUDIO   = Path(r"C:\Users\kevin\StudioProdigio")
INTRO    = STUDIO / "assets/intro/intro_oficial.mp4"
OUTRO    = STUDIO / "assets/outro/outro_oficial.mp4"
LOGO     = STUDIO / "assets/logo/logo_krc_transparent.png"
EPISODES = STUDIO / "tv_episodes"
COMPILED = STUDIO / "tv_compiled"
OUTPUT   = Path(r"C:\Users\kevin\Desktop\VIDEOS LARGOS PARA STREAMING")
CFG_FILE = STUDIO / "stream_config.json"

for d in [EPISODES, COMPILED, OUTPUT]:
    d.mkdir(parents=True, exist_ok=True)

RTMP_BASES = {
    "youtube":  "rtmp://a.rtmp.youtube.com/live2/",
    "twitch":   "rtmp://live.twitch.tv/app/",
    "kick":     "rtmps://fa723794a661.global-contribute.live-video.net:443/app/",
    "facebook": "rtmps://live-api-s.facebook.com:443/rtmp/"
}

BLOQUES_COMERCIALES_MINS = 55  # Cada cuántos minutos de serie → comercial


def ff(*args):
    """Ejecuta FFmpeg silencioso, retorna True si ok."""
    r = subprocess.run([str(FFMPEG)] + list(args), capture_output=True)
    return r.returncode == 0


def descargar_ep(video_id, titulo, out_dir):
    mp4 = out_dir / f"{video_id}.mp4"
    if mp4.exists() and mp4.stat().st_size > 300_000:
        return mp4
    opts = {
        "format": "bv[height<=720]+ba/best[height<=720]",
        "outtmpl": str(out_dir / f"{video_id}.%(ext)s"),
        "ffmpeg_location": str(FFMPEG.parent),
        "merge_output_format": "mp4",
        "quiet": True,
    }
    with yt_dlp.YoutubeDL(opts) as ydl:
        ydl.download([f"https://www.youtube.com/watch?v={video_id}"])
    return mp4 if mp4.exists() else None


def normalizar(src, dst, logo=True):
    """1280x720 30fps + logo KRC flotante."""
    if dst.exists() and dst.stat().st_size > 100_000:
        return dst
    if logo and LOGO.exists():
        logo_filter = (
            "[0:v]scale=1280:720:force_original_aspect_ratio=decrease,"
            "pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=30[base];"
            "[1:v]scale=140:140,format=rgba,"
            "fade=t=in:st=2:d=1:alpha=1,fade=t=out:st=55:d=1:alpha=1[logo];"
            "[base][logo]overlay=W-w-20:H-h-30[v]"
        )
        ok = ff("-y", "-i", str(src), "-i", str(LOGO),
                "-filter_complex", logo_filter,
                "-map", "[v]", "-map", "0:a",
                "-c:v", "libx264", "-preset", "fast", "-b:v", "2500k",
                "-c:a", "aac", "-ar", "44100", "-ac", "2", "-b:a", "160k",
                str(dst))
    else:
        ok = ff("-y", "-i", str(src),
                "-vf", "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=30",
                "-c:v", "libx264", "-preset", "fast", "-b:v", "2500k",
                "-c:a", "aac", "-ar", "44100", "-ac", "2", "-b:a", "160k",
                str(dst))
    return dst if ok else None


def norm_asset(src):
    dst = COMPILED / f"_asset_{src.stem}.mp4"
    if dst.exists(): return dst
    ff("-y", "-i", str(src),
       "-vf", "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=30",
       "-c:v", "libx264", "-preset", "fast",
       "-c:a", "aac", "-ar", "44100", "-ac", "2", str(dst))
    return dst


def obtener_episodios_playlist(playlist_url, limite=5):
    opts = {"extract_flat": True, "quiet": True}
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(playlist_url, download=False)
    return info.get("entries", [])[:limite]


def compilar_bloque_serie(serie_data, num_eps=3, label="serie"):
    """Descarga num_eps episodios de una serie, los normaliza con logo, retorna lista de paths."""
    eps_dir = EPISODES / label.replace(" ", "_")
    eps_dir.mkdir(exist_ok=True)
    comp_dir = COMPILED / label.replace(" ", "_")
    comp_dir.mkdir(exist_ok=True)

    entries = obtener_episodios_playlist(serie_data["playlist"], num_eps)
    paths = []
    for e in entries:
        raw = descargar_ep(e["id"], e.get("title","ep"), eps_dir)
        if raw and raw.exists():
            norm = comp_dir / f"norm_{e['id']}.mp4"
            result = normalizar(raw, norm)
            if result and result.exists():
                paths.append(result)
    return paths


def compilar_programa_tv(series_list, nombre_programa, ep_por_serie=2):
    """
    Construye un archivo largo:
    [Intro] → [Ep S1] → [Outro] → [Intro] → [Ep S2] → ... → [Outro final]
    Con bloques de comercial cada ~55min (si existen)
    """
    intro_n = norm_asset(INTRO)
    outro_n = norm_asset(OUTRO)

    todos_eps = []
    for serie_data in series_list:
        eps = compilar_bloque_serie(serie_data, ep_por_serie, serie_data["titulo"])
        todos_eps.extend(eps)
        print(f"  📦 {serie_data['titulo']}: {len(eps)} episodios procesados")

    if not todos_eps:
        print("  ⚠ No se obtuvieron episodios")
        return None

    # Construir concat
    segmentos = []
    for ep in todos_eps:
        segmentos.append(str(intro_n))
        segmentos.append(str(ep))
        segmentos.append(str(outro_n))

    concat_txt = COMPILED / f"{nombre_programa}_concat.txt"
    with open(concat_txt, "w", encoding="utf-8") as f:
        for s in segmentos:
            f.write(f"file '{s}'\n")

    out_mp4 = OUTPUT / f"{nombre_programa}.mp4"
    print(f"\n  🎬 Compilando → {out_mp4.name}...")
    ok = ff("-y", "-f", "concat", "-safe", "0", "-i", str(concat_txt),
            "-c:v", "libx264", "-preset", "fast", "-b:v", "2500k",
            "-c:a", "aac", "-ar", "44100", "-ac", "2", "-b:a", "160k",
            str(out_mp4))

    if ok and out_mp4.exists():
        gb = out_mp4.stat().st_size / 1024**3
        print(f"  ✅ LISTO: {out_mp4.name} ({gb:.2f} GB)")
        return out_mp4
    return None


def iniciar_stream(video_path, plataforma, key, loop=True):
    rtmp = RTMP_BASES.get(plataforma, "") + key
    cmd = [str(FFMPEG), "-re"]
    if loop:
        cmd += ["-stream_loop", "-1"]
    cmd += [
        "-i", str(video_path),
        "-c:v", "libx264", "-preset", "veryfast", "-b:v", "4500k",
        "-maxrate", "4500k", "-bufsize", "9000k", "-pix_fmt", "yuv420p",
        "-g", "60", "-c:a", "aac", "-b:a", "160k", "-ar", "44100",
        "-f", "flv", rtmp
    ]
    print(f"  ► LIVE → {plataforma.upper()}: {video_path.name}")
    return subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def stream_to_all(video_path):
    cfg = json.loads(CFG_FILE.read_text()) if CFG_FILE.exists() else {}
    procs = []
    for plat, data in cfg.items():
        if data.get("activo") and data.get("key") and "PEGA" not in data["key"]:
            p = iniciar_stream(video_path, plat, data["key"])
            procs.append((plat, p))
    return procs


if __name__ == "__main__":
    from catalogo_tv import CATALOGO_SERIES, PROGRAMACION_TV

    print("\n╔═══════════════════════════════════════════╗")
    print("║  🎮 KABALION TV ENGINE - 24/7 ACTIVO      ║")
    print("╚═══════════════════════════════════════════╝\n")

    # Compilar el primer bloque: Cartoon Network (Chavo + Chavo Animado)
    series_bloque_1 = CATALOGO_SERIES["cartoon_network"][:2]  # Chavo del 8 + Chavo Animado

    out = compilar_programa_tv(series_bloque_1, "BLOQUE_01_CartoonNetwork_KRC", ep_por_serie=2)
    if out:
        print("\n🔴 Iniciando transmisión en vivo a todas las plataformas activas...")
        procs = stream_to_all(out)
        if procs:
            print(f"  Transmitiendo en {len(procs)} plataformas. Ctrl+C para detener.\n")
            try:
                while True:
                    time.sleep(30)
            except KeyboardInterrupt:
                for plat, p in procs:
                    p.terminate()
                    print(f"  ⏹ {plat} detenido.")
        else:
            print("  ⚠ Ninguna plataforma activa con key válida.")
            print(f"  → Abre: {CFG_FILE} y llena tus stream keys")
    else:
        print("⚠ Compilación fallida.")
