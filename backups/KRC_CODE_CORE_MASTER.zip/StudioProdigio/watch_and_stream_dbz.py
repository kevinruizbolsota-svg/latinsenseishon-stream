import time, subprocess, sys
from pathlib import Path
STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
OUT = STUDIO / "dbz_to_play"
LOG = STUDIO / "dbz_watch.log"
def log(m):
    print(m, flush=True)
    try: LOG.open("a", encoding="utf-8").write(m+"\n")
    except: pass
log("Watcher: esperando primer capitulo completo en dbz_to_play...")
while True:
    files = sorted([p for p in OUT.glob("*.mp4") if p.stat().st_size > 80_000_000 and not p.name.endswith(".part")])
    if files:
        log(f"Listo: {files[0].name} ({files[0].stat().st_size//1024//1024}MB). Iniciando stream...")
        subprocess.Popen([sys.executable, "-u", str(STUDIO/"dbz_stream_all.py")], cwd=str(STUDIO))
        log("dbz_stream_all.py iniciado.")
        break
    time.sleep(15)
