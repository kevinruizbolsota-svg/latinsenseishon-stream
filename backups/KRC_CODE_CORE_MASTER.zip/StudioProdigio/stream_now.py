﻿import subprocess, time

FFMPEG = r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe"
VIDEO = r"C:\Users\kevin\Desktop\O\VIDEOS LARGOS PARA STREAMING\MARATON_Chavo_del_8_KRC.mp4"

# Twitch
cmd1 = [FFMPEG, "-re", "-stream_loop", "-1", "-i", VIDEO,
        "-c:v", "libx264", "-preset", "veryfast", "-b:v", "4500k",
        "-maxrate", "4500k", "-bufsize", "9000k", "-pix_fmt", "yuv420p",
        "-g", "60", "-c:a", "aac", "-b:a", "160k", "-ar", "44100",
        "-f", "flv", "rtmp://live.twitch.tv/app/live_851574809_cckGIiMFJwCTm8Ce5NFfjm4CRkWN8m"]
p1 = subprocess.Popen(cmd1, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

# Kick
cmd2 = [FFMPEG, "-re", "-stream_loop", "-1", "-i", VIDEO,
        "-c:v", "libx264", "-preset", "veryfast", "-b:v", "4500k",
        "-maxrate", "4500k", "-bufsize", "9000k", "-pix_fmt", "yuv420p",
        "-g", "60", "-c:a", "aac", "-b:a", "160k", "-ar", "44100",
        "-f", "flv", "rtmps://fa723794a661.global-contribute.live-video.net:443/app/sk_us-west-2_WA6SbsmU87cG_Ab6oRtrRR5SEyYViSA2rWoAuAeGdlR"]
p2 = subprocess.Popen(cmd2, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

print("Twitch + Kick streaming started")
while True:
    time.sleep(30)
