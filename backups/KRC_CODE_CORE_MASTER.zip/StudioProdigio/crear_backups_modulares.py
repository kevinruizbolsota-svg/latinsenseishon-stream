"""
GENERADOR DE BACKUPS MAESTROS KRC (3 NIVELES)
- Nivel 1 (KRC_CODE_CORE): Scripts Python, JS, HTML, JSON, BAT, configs (super ligero < 15MB)
- Nivel 2 (KRC_MEDIA_ASSETS): Logos, tickers, audios, overlays, modelos pequeños (< 60MB)
- Nivel 3 (KRC_WORKFLOWS_N8N): Flujos de automatización de N8N y metadatos
"""
import zipfile, os, time
from pathlib import Path

DEST_DIR = Path(r"C:\Users\kevin\latinsenseishon-stream\backups")
DEST_DIR.mkdir(parents=True, exist_ok=True)

# 1. GENERAR BACKUP CODE CORE (Todos los proyectos de código y automatización)
core_zip_path = DEST_DIR / "KRC_CODE_CORE_MASTER.zip"
code_exts = {'.py', '.js', '.json', '.bat', '.sh', '.html', '.css', '.md', '.txt', '.yaml', '.yml', '.env.example', '.sql', '.gd', '.tscn', '.tres'}
ignore_dirs = {'node_modules', '.git', '__pycache__', '.pytest_cache', 'dbz_to_play', 'dbz_played', 'video_temp', 'SERIES_3_HORAS_MASTER', '01_EN_EMISION_ACTUAL', 'twitch_to_play'}

core_count = 0
with zipfile.ZipFile(core_zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
    for base in [Path(r"C:\Users\kevin\StudioProdigio"), Path(r"C:\Users\kevin\LATINSENSEISHON"), Path(r"C:\Users\kevin\Videos_Limpiador"), Path(r"C:\Users\kevin\Desktop")]:
        if not base.exists(): continue
        for root, dirs, files in os.walk(base):
            dirs[:] = [d for d in dirs if d not in ignore_dirs]
            for f in files:
                p = Path(root) / f
                if p.suffix.lower() in code_exts and p.stat().st_size < 15 * 1024 * 1024:
                    rel = p.relative_to(base)
                    z.write(p, arcname=f"{base.name}/{rel}")
                    core_count += 1

print(f"✅ Core Code generado: {core_zip_path.name} ({core_zip_path.stat().st_size / 1024:.1f} KB con {core_count} archivos)")

# 2. GENERAR BACKUP ASSETS BRANDING & OVERLAYS (Logos, Tickers, Banners)
assets_zip_path = DEST_DIR / "KRC_BRANDING_ASSETS.zip"
asset_exts = {'.png', '.jpg', '.jpeg', '.svg', '.webp', '.ico', '.ttf', '.otf', '.mp3', '.wav'}

asset_count = 0
with zipfile.ZipFile(assets_zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
    for base in [Path(r"C:\Users\kevin\StudioProdigio\assets"), Path(r"C:\Users\kevin\LATINSENSEISHON")]:
        if not base.exists(): continue
        for root, dirs, files in os.walk(base):
            dirs[:] = [d for d in dirs if d not in ignore_dirs and 'colwar_assets' not in root]
            for f in files:
                p = Path(root) / f
                if p.suffix.lower() in asset_exts and p.stat().st_size < 20 * 1024 * 1024:
                    rel = p.relative_to(base)
                    z.write(p, arcname=f"Assets/{rel}")
                    asset_count += 1

print(f"✅ Branding Assets generado: {assets_zip_path.name} ({assets_zip_path.stat().st_size / 1024:.1f} KB con {asset_count} archivos)")

# 3. GENERAR BACKUP N8N & AUTOMATION CONFIGS
n8n_zip_path = DEST_DIR / "KRC_N8N_AUTOMATION.zip"
n8n_count = 0
n8n_base = Path(r"C:\Users\kevin\.n8n")
if n8n_base.exists():
    with zipfile.ZipFile(n8n_zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(n8n_base):
            for f in files:
                p = Path(root) / f
                if p.suffix.lower() in {'.json', '.sqlite', '.env', '.txt'} and p.stat().st_size < 30 * 1024 * 1024:
                    rel = p.relative_to(n8n_base)
                    z.write(p, arcname=f"n8n_config/{rel}")
                    n8n_count += 1
    print(f"✅ N8N Config generado: {n8n_zip_path.name} ({n8n_zip_path.stat().st_size / 1024:.1f} KB con {n8n_count} archivos)")
