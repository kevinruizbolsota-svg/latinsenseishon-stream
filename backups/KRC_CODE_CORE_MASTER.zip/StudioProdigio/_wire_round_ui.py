﻿from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.gd")
t = p.read_text(encoding="utf-8")

# add ronda anuncio ref and timer
if '@onready var _menu_pausa' in t and '@onready var _ronda_label' not in t:
    t = t.replace('@onready var _menu_pausa: ColorRect = get_node_or_null("UI/Pausa")',
                  '@onready var _menu_pausa: ColorRect = get_node_or_null("UI/Pausa")\n@onready var _ronda_label: Label = get_node_or_null("UI/RondaAnuncio")')

if 'var _ronda_msg_t := 0.0' not in t:
    t = t.replace('var _paused := false', 'var _paused := false\nvar _ronda_msg_t := 0.0')

# helper to show round announcement
if 'func _show_ronda(' not in t:
    insert = r'''

func _show_ronda(text: String, t: float = 3.0):
	if _ronda_label:
		_ronda_label.text = text
	_ronda_msg_t = t
'''
    t = t.replace('\nfunc _start_next_round():', insert + '\nfunc _start_next_round():')

# tick ronda message timer in process
old_proc = r'''func _process(delta):
	_update_round_ui()
	if not _started or _paused or get_tree().paused:
		return'''
new_proc = r'''func _process(delta):
	_update_round_ui()
	if _ronda_msg_t > 0.0:
		_ronda_msg_t -= delta
		if _ronda_msg_t <= 0.0 and _ronda_label:
			_ronda_label.text = ""
	if not _started or _paused or get_tree().paused:
		return'''
if old_proc in t:
    t = t.replace(old_proc, new_proc)

# use ronda announcement
t = t.replace('p._show_msg("¡Ronda %d completada! Prepárate..." % round_num, 3.5)',
              'p._show_msg("¡Ronda %d completada! Prepárate..." % round_num, 3.5)\n\t\t\t_show_ronda("RONDA %d COMPLETADA" % round_num, 3.0)')
t = t.replace('p._show_msg("RONDA %d  -  %d zombis" % [round_num, to_spawn], 3.0)',
              'p._show_msg("RONDA %d  -  %d zombis" % [round_num, to_spawn], 3.0)\n\t\t_show_ronda("RONDA %d" % round_num, 2.5)')
t = t.replace('p._show_msg("RONDA 1 - ¡Sobrevive!", 3.0)',
              'p._show_msg("RONDA 1 - ¡Sobrevive!", 3.0)\n\t\t_show_ronda("RONDA 1", 2.5)')

p.write_text(t, encoding='utf-8', newline='\n')
print('ok')
