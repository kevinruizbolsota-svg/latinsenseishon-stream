﻿"""
INICIAR STREAM AHORA - Stream inmediato a plataformas activas
"""
import subprocess, time, json
from pathlib import Path

FFMPEG = r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe"
CONFIG_FILE = Path(r"C:\Users\kevin\StudioProdigio\stream_config.json")
VIDEO = Path(r"C:\Users\kevin\Desktop\O\VIDEOS LARGOS PARA STREAMING\MARATON_Chavo_del_8_KRC.mp4")

RTMP_BASES = {
    "twitch": "rtmp://live.twitch.tv/app/",
    "facebook": "rtmps://live-api-s.facebook.com:443/rtmp/"
}

keys = json.loads(CONFIG_FILE.read_text())
procs = []

for plat, cfg in keys.items():
    if cfg.get("activo") and "PEGA" not in cfg.get("key", "") and plat in RTMP_BASES:
        rtmp = RTMP_BASES[plat] + cfg["key"]
        cmd = [FFMPEG, "-re", "-stream_loop", "-1", "-i", str(VIDEO),
               "-c:v", "libx264", "-preset", "veryfast", "-b:v", "4500k",
               "-maxrate", "4500k", "-bufsize", "9000k", "-pix_fmt", "yuv420p",
               "-g", "60", "-c:a", "aac", "-b:a", "160k", "-ar", "44100",
               "-f", "flv", rtmp]
        print(f"Iniciando stream a {plat.upper()}...")
        p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        time.sleep(5)
        if p.poll() is None:
            print(f"  OK - PID: {p.pid}")
            procs.append((plat, p))
        else:
            err = p.stderr.read().decode()[-200:]
            print(f"  FAILED: {err}")

print(f"\nStreaming a {len(procs)} plataformas: {[p[0] for p in procs]}")
try:
    while True:
        time.sleep(30)
except KeyboardInterrupt:
    for plat, p in procs:
        p.terminate()
        print(f"  {plat} detenido.")
