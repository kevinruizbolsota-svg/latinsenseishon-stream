import sys
sys.path.insert(0, r"C:\Users\kevin\StudioProdigio")
from catalogo_tv import CATALOGO_SERIES
import yt_dlp

for canal, series in CATALOGO_SERIES.items():
    for s in series[:2]:
        try:
            opts = {"extract_flat": True, "quiet": True, "playlist_items": "1"}
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(s["playlist"], download=False)
            entries = info.get("entries", [])
            print(f"OK  {s['titulo']} ({canal}) - {len(entries)} entries")
        except Exception as e:
            print(f"FAIL {s['titulo']} ({canal}) - {str(e)[:60]}")
