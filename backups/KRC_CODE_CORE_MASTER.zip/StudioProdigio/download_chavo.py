import sys, json, time, os
from pathlib import Path
sys.path.insert(0, r"C:\Users\kevin\StudioProdigio")

STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
EPISODES_DIR = STUDIO / "tv_episodes" / "El_Chavo_del_8"
EPISODES_DIR.mkdir(parents=True, exist_ok=True)

import yt_dlp

# Chavo del 8 playlist (the only working one)
PLAYLIST_URL = "https://www.youtube.com/playlist?list=PLuxcLq9n25BEINVPnsS419gD8E6WSeiS-"

# Get playlist entries
opts = {"extract_flat": True, "quiet": True}
with yt_dlp.YoutubeDL(opts) as ydl:
    info = ydl.extract_info(PLAYLIST_URL, download=False)
entries = info.get("entries", [])
print(f"Playlist has {len(entries)} entries")

# Download first 30
downloaded = 0
for i, entry in enumerate(entries[:30], 1):
    vid_id = entry.get("id", "")
    title = entry.get("title", f"Episodio {i}")
    if not vid_id:
        continue

    mp4 = EPISODES_DIR / f"{vid_id}.mp4"
    if mp4.exists() and mp4.stat().st_size > 100_000:
        print(f"[{i}/30] SKIP (exists): {title[:50]}")
        downloaded += 1
        continue

    print(f"[{i}/30] Downloading: {title[:50]}...")
    dl_opts = {
        "format": "best",
        "outtmpl": str(EPISODES_DIR / f"{vid_id}.%(ext)s"),
        "merge_output_format": "mp4",
        "quiet": True,
        "no_warnings": True,
        "socket_timeout": 60,
    }
    try:
        with yt_dlp.YoutubeDL(dl_opts) as ydl:
            ydl.download([f"https://www.youtube.com/watch?v={vid_id}"])
        if mp4.exists() and mp4.stat().st_size > 100_000:
            size_mb = mp4.stat().st_size / (1024*1024)
            print(f"  OK ({size_mb:.1f}MB)")
            downloaded += 1
        else:
            print(f"  FAILED (file not created or too small)")
    except Exception as e:
        print(f"  ERROR: {str(e)[:80]}")
    time.sleep(1)

print(f"\nDescargados: {downloaded}/30")

# Create organization file
org = {
    "total_series": 1,
    "total_chapters": downloaded,
    "series": {
        "El Chavo del 8": {
            "folder": "El_Chavo_del_8",
            "chapters": [f.name for f in EPISODES_DIR.glob("*.mp4")],
            "count": len(list(EPISODES_DIR.glob("*.mp4")))
        }
    }
}
org_file = STUDIO / "video_organization.json"
org_file.write_text(json.dumps(org, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"Organizacion guardada en: {org_file}")
print(f"Total archivos en carpeta: {len(list(EPISODES_DIR.glob('*.mp4')))}")
