import os, shutil, zipfile, glob
src = r"C:\Users\kevin\Downloads\COLWAR"
dst = r"C:\Users\kevin\Documents\GodotFPS-Zombies-Template\colwar_assets"
cats = {
 "mapas_bosque": [".glb",".zip"], "personajes_criaturas": [".glb"], "armas": [".glb",".zip"],
 "texturas_hdris": [".zip",".png",".jpg",".jpeg",".exr",".hdr"], "props_vehiculos": [".glb"], "otros": []
}
# simple routing by name
def route(name, ext):
    n=name.lower()
    if ext=='.crdownload' or name.endswith('.tmp'): return None
    if any(k in n for k in ['forest','pine_forest','terrain','rome','scene','peak-cliff','mountain','road-at-night']):
        return 'mapas_bosque'
    if any(k in n for k in ['akm','gewehr','m4','weapon','arma','sword','magnifier','pack-de-armas']):
        return 'armas'
    if any(k in n for k in ['hdri','pavement','cobblestone','pebbles','patterned','environmenthdri']):
        return 'texturas_hdris'
    if ext in ['.glb'] and any(k in n for k in ['arash','husqavarna','moto','car']):
        return 'props_vehiculos'
    if ext=='.glb':
        return 'personajes_criaturas'
    if ext=='.zip':
        return 'otros'
    return 'otros'

os.makedirs(dst, exist_ok=True)
for c in set(list(cats.keys())+['mapas_bosque','personajes_criaturas','armas','texturas_hdris','props_vehiculos','otros']):
    os.makedirs(os.path.join(dst,c), exist_ok=True)

for fn in os.listdir(src):
    fp=os.path.join(src,fn)
    if not os.path.isfile(fp): continue
    if fn.lower().endswith('.crdownload') or fn.endswith('.tmp'): continue
    ext=os.path.splitext(fn)[1].lower()
    cat=route(fn,ext)
    if not cat: continue
    outdir=os.path.join(dst,cat)
    target=os.path.join(outdir,fn)
    if not os.path.exists(target):
        shutil.copy2(fp,target)
        print('copy',cat,fn)
    if ext=='.zip':
        exdir=os.path.join(outdir, os.path.splitext(fn)[0])
        if not os.path.exists(exdir):
            os.makedirs(exdir, exist_ok=True)
            try:
                with zipfile.ZipFile(target) as zf: zf.extractall(exdir)
                print('extract',exdir)
            except Exception as e: print('ziperr',fn,e)
# nested zip (pack-de-armas/source/4.zip)
for root,_,files in os.walk(dst):
    for f in files:
        if f.lower().endswith('.zip') and root.count(os.sep) - dst.count(os.sep) <= 4:
            p=os.path.join(root,f); ex=os.path.join(root,os.path.splitext(f)[0])
            if not os.path.exists(ex) and f!='4.zip': # avoid reprocessing aggressively except nested
                pass
nzip=os.path.join(dst,'armas','pack-de-armas','source','4.zip')
if os.path.exists(nzip):
    ex=os.path.join(dst,'armas','pack-de-armas','source','4')
    if not os.path.exists(ex):
        os.makedirs(ex,exist_ok=True)
        try:
            with zipfile.ZipFile(nzip) as zf: zf.extractall(ex)
            print('extract nested',ex)
        except Exception as e: print('err',e)
print('DONE')
