
def safe_move(src, dst, max_retries=6, delay=1.5):
    for i in range(max_retries):
        try:
            shutil.move(str(src), str(dst))
            return True
        except PermissionError:
            time.sleep(delay)
        except Exception:
            break
    try:
        shutil.copyfile(str(src), str(dst))
        time.sleep(0.5)
        os.unlink(str(src))
        return True
    except Exception as e:
        log(f"Aviso al mover {Path(src).name}: {e}")
        return False

"""
KABALION TV - Motor de Transmisión con Cola Inteligente
Sistema de descarga → normaliza → transmite → elimina (ciclo infinito)
Con pantalla de mantenimiento automática cuando la cola está vacía
"""
import sys, subprocess, json, time, os, shutil, threading, queue
from pathlib import Path
from datetime import datetime
import yt_dlp

# ═══ RUTAS ═══
FFMPEG   = Path(r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe")
STUDIO   = Path(r"C:\Users\kevin\StudioProdigio")
TV_DIR   = Path(r"C:\Users\kevin\Desktop\KABALION TV")
EN_COLA      = TV_DIR / "EN_COLA"        # Listos para transmitir
TRANSMITIENDO= TV_DIR / "TRANSMITIENDO"  # Actualmente al aire
TRANSMITIDOS = TV_DIR / "TRANSMITIDOS"   # Ya fueron al aire (se purgan)
MANT         = TV_DIR / "MANTENIMIENTO"  # Pantalla de mantenimiento
INTRO    = STUDIO / "assets/intro/intro_oficial.mp4"
OUTRO    = STUDIO / "assets/outro/outro_oficial.mp4"
LOGO     = STUDIO / "assets/logo/logo_krc_transparent.png"
CFG_FILE = STUDIO / "stream_config.json"
TEMP_DIR = STUDIO / "tv_temp"
TEMP_DIR.mkdir(exist_ok=True)

# Límite de disco: eliminar transmitidos si se supera
MAX_DISK_GB = 20

RTMP_BASES = {
    "twitch":   "rtmp://live.twitch.tv/app/",
    "kick":     "rtmps://fa723794a661.global-contribute.live-video.net:443/app/",
    "facebook": "rtmps://live-api-s.facebook.com:443/rtmp/"
}

PLAYLIST_CHAVO = "https://www.youtube.com/playlist?list=PLuxcLq9n25BEINVPnsS419gD8E6WSeiS-"

stream_procs = []  # procesos ffmpeg activos
ep_index = 0       # índice global de episodios descargados

def log(msg):
    ts = datetime.now().strftime("%H:%M:%S")
    print(f"[{ts}] {msg}")

def ff(*args, silent=True):
    cap = subprocess.DEVNULL if silent else None
    r = subprocess.run([str(FFMPEG)] + list(args), stdout=cap, stderr=cap)
    return r.returncode == 0

def get_playlist(url, start=0, count=3):
    opts = {"extract_flat": True, "quiet": True}
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=False)
    return info.get("entries", [])[start:start+count]

def descargar_ep(video_id, out_path):
    if out_path.exists() and out_path.stat().st_size > 300_000:
        return out_path
    opts = {
        "format": "bv[height<=720]+ba/best[height<=720]",
        "outtmpl": str(out_path.with_suffix('.%(ext)s')),
        "ffmpeg_location": str(FFMPEG.parent),
        "merge_output_format": "mp4",
        "quiet": True,
    }
    with yt_dlp.YoutubeDL(opts) as ydl:
        ydl.download([f"https://www.youtube.com/watch?v={video_id}"])
    return out_path if out_path.exists() else None

def build_episodio(raw_path, out_path):
    """Intro + ep normalizado + logo KRC + outro → archivo listo para stream"""
    if out_path.exists() and out_path.stat().st_size > 100_000:
        return out_path

    # 1. Normalizar episodio con logo
    norm_path = TEMP_DIR / f"norm_{raw_path.stem}.mp4"
    if not (norm_path.exists() and norm_path.stat().st_size > 100_000):
        logo_filter = (
            "[0:v]scale=1280:720:force_original_aspect_ratio=decrease,"
            "pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=30[base];"
            "[1:v]scale=140:140,format=rgba,"
            "fade=t=in:st=2:d=1:alpha=1,fade=t=out:st=55:d=1:alpha=1[logo];"
            "[base][logo]overlay=W-w-20:H-h-30[v]"
        )
        ok = ff("-y", "-i", str(raw_path), "-i", str(LOGO),
                "-filter_complex", logo_filter,
                "-map", "[v]", "-map", "0:a",
                "-c:v", "libx264", "-preset", "fast", "-b:v", "2500k",
                "-c:a", "aac", "-ar", "44100", "-ac", "2", "-b:a", "160k",
                str(norm_path))
        if not ok: return None

    # 2. Normalizar intro/outro al mismo formato
    def norm_asset(src):
        d = TEMP_DIR / f"_a_{src.stem}.mp4"
        if d.exists(): return d
        ff("-y", "-i", str(src),
           "-vf", "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=30",
           "-c:v", "libx264", "-preset", "fast",
           "-c:a", "aac", "-ar", "44100", "-ac", "2", str(d))
        return d

    intro_n = norm_asset(INTRO)
    outro_n = norm_asset(OUTRO)

    # 3. Concat: intro → ep → outro
    concat_txt = TEMP_DIR / f"concat_{raw_path.stem}.txt"
    with open(concat_txt, "w") as f:
        f.write(f"file '{intro_n}'\n")
        f.write(f"file '{norm_path}'\n")
        f.write(f"file '{outro_n}'\n")

    ok = ff("-y", "-f", "concat", "-safe", "0", "-i", str(concat_txt),
            "-c:v", "libx264", "-preset", "fast", "-b:v", "2500k",
            "-c:a", "aac", "-ar", "44100", "-ac", "2", "-b:a", "160k",
            str(out_path))

    # Limpiar temporales del episodio
    try:
        norm_path.unlink(missing_ok=True)
        concat_txt.unlink(missing_ok=True)
    except: pass

    return out_path if ok and out_path.exists() else None

def iniciar_streams(video_path):
    """Lanza ffmpeg RTMP a todas las plataformas activas. Retorna lista de procesos."""
    cfg = json.loads(CFG_FILE.read_text()) if CFG_FILE.exists() else {}
    procs = []
    for plat, data in cfg.items():
        if not data.get("activo") or "PEGA" in data.get("key",""):
            continue
        base = RTMP_BASES.get(plat)
        if not base:
            continue
        rtmp = base + data["key"]
        cmd = [
            str(FFMPEG), "-re",
            "-i", str(video_path),
            "-c:v", "libx264", "-preset", "veryfast",
            "-b:v", "4500k", "-maxrate", "4500k", "-bufsize", "9000k",
            "-pix_fmt", "yuv420p", "-g", "60",
            "-c:a", "aac", "-b:a", "160k", "-ar", "44100",
            "-f", "flv", rtmp
        ]
        p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        log(f"🔴 LIVE → {plat.upper()} (PID {p.pid})")
        procs.append((plat, p))
    return procs

def detener_streams(procs):
    for plat, p in procs:
        try:
            p.terminate()
            log(f"⏹ Detenido {plat}")
        except: pass

def purgar_transmitidos():
    """Elimina archivos en TRANSMITIDOS si excede MAX_DISK_GB"""
    total_gb = sum(f.stat().st_size for f in TRANSMITIDOS.glob("*.mp4")) / 1024**3
    if total_gb > MAX_DISK_GB:
        archivos = sorted(TRANSMITIDOS.glob("*.mp4"), key=lambda f: f.stat().st_mtime)
        for f in archivos:
            log(f"🗑 Eliminando transmitido: {f.name}")
            f.unlink()
            total_gb -= f.stat().st_size / 1024**3
            if total_gb <= MAX_DISK_GB * 0.8:
                break

def descargador_en_segundo_plano(playlist_url):
    """Thread que descarga y prepara episodios continuamente."""
    global ep_index
    log("⬇ Descargador iniciado en segundo plano")
    while True:
        entries = get_playlist(playlist_url, ep_index, 2)
        if not entries:
            ep_index = 0  # reinicia desde el principio
            entries = get_playlist(playlist_url, 0, 2)

        for entry in entries:
            vid_id = entry.get("id","")
            titulo = entry.get("title","ep")[:40]
            ep_index += 1

            raw = TEMP_DIR / f"{vid_id}.mp4"
            out = EN_COLA / f"{ep_index:04d}_{vid_id}.mp4"

            if out.exists():
                continue

            log(f"⬇ Descargando: {titulo}")
            raw_dl = descargar_ep(vid_id, raw)
            if raw_dl:
                log(f"🎬 Compilando con intro/logo/outro: {titulo}")
                result = build_episodio(raw_dl, out)
                if result:
                    log(f"✅ EN COLA: {out.name}")
                try:
                    raw.unlink(missing_ok=True)
                except: pass
            time.sleep(2)

        # Si la cola tiene 5+ episodios, esperar un poco
        cola_count = len(list(EN_COLA.glob("*.mp4")))
        if cola_count >= 5:
            time.sleep(60)

def main():
    global stream_procs

    log("╔══════════════════════════════════════════╗")
    log("║  📺 KABALION TV - INICIANDO SISTEMA 24/7  ║")
    log("╚══════════════════════════════════════════╝")

    # Verificar pantalla de mantenimiento
    mant_screen = MANT / "pantalla_mantenimiento.mp4"
    if not mant_screen.exists():
        log("⚙ Generando pantalla de mantenimiento...")
        subprocess.run([
            sys.executable,
            str(STUDIO / "generar_mantenimiento.py")
        ], capture_output=True)

    # Iniciar descargador en hilo separado
    t = threading.Thread(target=descargador_en_segundo_plano,
                         args=(PLAYLIST_CHAVO,), daemon=True)
    t.start()

    log("⏳ Esperando primer episodio en cola...")
    while not list(EN_COLA.glob("*.mp4")):
        time.sleep(10)
        log("  ... preparando primer episodio ...")

    while True:
        cola = sorted(EN_COLA.glob("*.mp4"))

        if not cola:
            # Sin contenido → pantalla de mantenimiento en loop
            if not list(TRANSMITIENDO.glob("*.mp4")):
                log("📺 Cola vacía → Pantalla de mantenimiento")
                stream_procs = iniciar_streams(mant_screen)
                while not list(EN_COLA.glob("*.mp4")):
                    time.sleep(15)
                detener_streams(stream_procs)
                stream_procs = []
            time.sleep(5)
            continue

        # Tomar el siguiente episodio
        ep = cola[0]
        # Mover a TRANSMITIENDO
        dest = TRANSMITIENDO / ep.name
        safe_move(ep, dest)
        log(f"\n🎬 AHORA EN VIVO: {ep.name}")

        # Lanzar streams
        stream_procs = iniciar_streams(dest)

        # Esperar que ffmpeg termine (el video termina de reproducirse)
        for plat, p in stream_procs:
            p.wait()

        # Mover a TRANSMITIDOS
        arch = TRANSMITIDOS / dest.name
        safe_move(dest, arch)
        log(f"✅ Transmitido y archivado: {arch.name}")

        # Purgar si se llena el disco
        purgar_transmitidos()
        stream_procs = []
        time.sleep(2)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        log("🛑 Sistema detenido manualmente")
        detener_streams(stream_procs)
