import subprocess, sys, os
os.chdir(r"C:\Users\kevin\StudioProdigio")
# Test ffmpeg mode
result = subprocess.run(
    [sys.executable, "video_factory.py", "--mode", "ffmpeg", "--prompt", "Test video", "--duration", "3"],
    capture_output=True, text=True, timeout=120
)
print("STDOUT:", result.stdout[-500:] if result.stdout else "EMPTY")
print("STDERR:", result.stderr[-500:] if result.stderr else "EMPTY")
print("Return code:", result.returncode)
