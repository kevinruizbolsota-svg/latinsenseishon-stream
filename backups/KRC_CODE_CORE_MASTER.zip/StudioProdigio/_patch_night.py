﻿import re
from pathlib import Path
p = Path(r"C:\Users\kevin\Documents\COLWAR_NUEVO\main.tscn")
t = p.read_text(encoding="utf-8")

# Night sky colors
t = t.replace('sky_top_color = Color(0.1, 0.35, 0.7, 1)\nsky_horizon_color = Color(0.55, 0.7, 0.85, 1)\nground_bottom_color = Color(0.12, 0.18, 0.1, 1)\nground_horizon_color = Color(0.3, 0.4, 0.28, 1)',
              'sky_top_color = Color(0.03, 0.05, 0.12, 1)\nsky_horizon_color = Color(0.12, 0.16, 0.28, 1)\nground_bottom_color = Color(0.02, 0.03, 0.03, 1)\nground_horizon_color = Color(0.08, 0.1, 0.14, 1)')

# Environment: night + fog, no heavy effects
old_env = r'''[sub_resource type="Environment" id="Env1"]
background_mode = 2
sky = SubResource("Sky1")
ambient_light_source = 2
ambient_light_color = Color(0.75, 0.8, 0.9, 1)
ambient_light_energy = 0.9
tonemap_mode = 2
glow_enabled = false'''
new_env = r'''[sub_resource type="Environment" id="Env1"]
background_mode = 2
sky = SubResource("Sky1")
ambient_light_source = 2
ambient_light_color = Color(0.38, 0.45, 0.62, 1)
ambient_light_energy = 1.15
tonemap_mode = 2
tonemap_exposure = 1.05
glow_enabled = false
fog_enabled = true
fog_light_color = Color(0.14, 0.18, 0.3, 1)
fog_light_energy = 0.9
fog_density = 0.012
fog_aerial_perspective = 0.35
fog_sky_affect = 0.4
volumetric_fog_enabled = false'''
t = t.replace(old_env, new_env)

# Moon light, no shadows (Intel UHD)
old_sol = r'''[node name="Sol" type="DirectionalLight3D" parent="."]
transform = Transform3D(0.866025, -0.353553, 0.353553, 0, 0.707107, 0.707107, -0.5, -0.612372, 0.612372, 0, 40, 0)
light_energy = 1.4
shadow_enabled = true'''
new_sol = r'''[node name="Luna" type="DirectionalLight3D" parent="."]
transform = Transform3D(0.939693, -0.17101, 0.296198, 0, 0.866025, 0.5, -0.34202, -0.469846, 0.813798, 0, 50, 0)
light_color = Color(0.72, 0.8, 1, 1)
light_energy = 0.55
shadow_enabled = false

[node name="Relleno" type="DirectionalLight3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 0.35, 0.93675, 0, -0.93675, 0.35, 0, 20, 0)
light_color = Color(0.45, 0.52, 0.7, 1)
light_energy = 0.25
shadow_enabled = false'''
t = t.replace(old_sol, new_sol)

# Remove temporary CSG Arboles block (from [node name="Arboles"...] up to [node name="Player"...])
t = re.sub(r'\n\[node name="Arboles" type="Node3D" parent="\."\]\n.*?(?=\n\[node name="Player")', '\n', t, flags=re.S)

# Make suelo collision-only feel less intrusive? keep as-is (green) under forest is ok; optionally tint darker
t = t.replace('albedo_color = Color(0.18, 0.42, 0.16, 1)', 'albedo_color = Color(0.12, 0.18, 0.1, 1)')

p.write_text(t, encoding="utf-8", newline="\n")
print("ok")
