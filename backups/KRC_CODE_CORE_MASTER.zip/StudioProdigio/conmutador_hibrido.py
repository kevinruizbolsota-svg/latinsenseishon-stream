"""
CONMUTADOR HÍBRIDO INTELIGENTE (SMART CLOUD-PC FAILOVER)
- Cuando el PC está prendido: Apaga el stream de Render y emite tu PC local (con logo y marco retro).
- Cuando el PC se apaga o se cierra la app: Activa el stream de Render 24/7 en la nube para que nunca se caiga la señal.
"""

import urllib.request, json, time, atexit, signal, sys

RENDER_URL = "https://latinsenseishon-stream.onrender.com/api/control/toggle_stream"

def set_render(accion):
    try:
        data = json.dumps({"accion": accion}).encode("utf-8")
        req = urllib.request.Request(RENDER_URL, data=data, method="POST", headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            pass
    except Exception:
        pass

def on_pc_shutdown(signum=None, frame=None):
    # Enciende la nube automáticamente antes de que el PC se apague
    set_render("start")
    sys.exit(0)

# Registrar eventos de salida (cierre de ventana o apagado del sistema)
atexit.register(lambda: set_render("start"))
signal.signal(signal.SIGINT, on_pc_shutdown)
signal.signal(signal.SIGTERM, on_pc_shutdown)

if __name__ == "__main__":
    # Al arrancar el PC: Apagar Render para que el PC tenga la vía libre
    set_render("stop")
    while True:
        # Enviar un latido cada 60s recordando a Render que el PC sigue vivo
        time.sleep(60)
        set_render("stop")
