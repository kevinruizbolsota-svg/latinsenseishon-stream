import re
from pathlib import Path
p = Path(r'C:\Users\kevin\Documents\GodotFPS-Zombies-Template\player\player.tscn')
t = p.read_text(encoding='utf-8')
t = t.replace('[ext_resource type="PackedScene" path="res://colwar_assets/armas/gewehr_41_w_low-poly.glb" id="23_gewehr"]\n', '')
t = re.sub(r'\n\[node name="ArmaEspalda" parent="CuerpoVisible" instance=ExtResource\("23_gewehr"\)\]\n[^\[]*', '\n', t)
p.write_text(t, encoding='utf-8')
print('ok', 'gewehr' in t)
