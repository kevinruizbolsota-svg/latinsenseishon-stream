"""
KABALION VIDEO CHAT - Interfaz Web para Generacion de Videos con IA
Permite al usuario especificar como quiere el video mediante chat
"""
import http.server
import socketserver
import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path
from datetime import datetime

STUDIO = Path(r"C:\Users\kevin\StudioProdigio")
PORT = 8900

HTML_PAGE = r"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kabalion Video Factory - Chat</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Segoe UI', sans-serif; background: #0a0a1a; color: #e0e0e0; }
.container { max-width: 900px; margin: 0 auto; padding: 20px; }
.header { text-align: center; padding: 20px; background: linear-gradient(135deg, #1a1a2e, #16213e, #0f3460); border-radius: 12px; margin-bottom: 20px; }
.header h1 { color: #e94560; font-size: 2em; }
.header p { color: #a0a0a0; margin-top: 5px; }
.chat-box { background: #1a1a2e; border-radius: 12px; padding: 20px; height: 500px; overflow-y: auto; margin-bottom: 20px; border: 1px solid #16213e; }
.message { margin-bottom: 15px; padding: 12px 16px; border-radius: 8px; max-width: 85%; }
.user-msg { background: #0f3460; margin-left: auto; text-align: right; }
.ai-msg { background: #16213e; border-left: 3px solid #e94560; }
.system-msg { background: #2a2a3e; text-align: center; font-style: italic; color: #888; max-width: 100%; }
.input-area { display: flex; gap: 10px; }
.input-area input { flex: 1; padding: 12px 16px; border: 1px solid #16213e; border-radius: 8px; background: #1a1a2e; color: #e0e0e0; font-size: 1em; }
.input-area button { padding: 12px 24px; border: none; border-radius: 8px; background: #e94560; color: white; font-size: 1em; cursor: pointer; font-weight: bold; }
.input-area button:hover { background: #ff6b6b; }
.modes { display: flex; gap: 8px; margin-bottom: 15px; flex-wrap: wrap; }
.mode-btn { padding: 8px 16px; border: 1px solid #16213e; border-radius: 6px; background: #1a1a2e; color: #e0e0e0; cursor: pointer; font-size: 0.85em; }
.mode-btn.active { background: #e94560; border-color: #e94560; }
.status { text-align: center; padding: 10px; color: #888; font-size: 0.9em; }
.video-link { color: #e94560; text-decoration: none; font-weight: bold; }
.video-link:hover { text-decoration: underline; }
.options { margin-top: 10px; }
.option-btn { padding: 6px 12px; margin: 4px; border: 1px solid #16213e; border-radius: 4px; background: #2a2a3e; color: #e0e0e0; cursor: pointer; font-size: 0.85em; }
.option-btn:hover { background: #e94560; }
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>🎬 KABALION VIDEO FACTORY</h1>
    <p>Generador de Videos con IA - Kevin Esteban Ruiz Calle (KRC)</p>
  </div>
  <div class="modes">
    <button class="mode-btn active" onclick="setMode('gemini')">🤖 Gemini IA</button>
    <button class="mode-btn" onclick="setMode('moviepy')">🎬 MoviePy</button>
    <button class="mode-btn" onclick="setMode('ffmpeg')">🎨 FFmpeg</button>
    <button class="mode-btn" onclick="setMode('manim')">📐 Manim</button>
    <button class="mode-btn" onclick="setMode('ai')">🧠 AI Video</button>
    <button class="mode-btn" onclick="setMode('sd')">🖼️ SD+AnimateDiff</button>
  </div>
  <div class="chat-box" id="chatBox">
    <div class="message system-msg">Bienvenido a Kabalion Video Factory. Describe el video que quieres crear y lo generare para ti.</div>
    <div class="message system-msg">Modos disponibles: Gemini (guion IA + frames), FFmpeg (composicion), Manim (animaciones), AI Video (IA completa)</div>
  </div>
  <div class="input-area">
    <input type="text" id="userInput" placeholder="Describe tu video... (ej: 'Video viral de TikTok sobre trading con estilo cyberpunk')" onkeypress="if(event.key==='Enter')sendMessage()">
    <button onclick="sendMessage()">ENVIAR</button>
  </div>
  <div class="status" id="status">Listo para generar videos</div>
</div>
<script>
let currentMode = 'gemini';
function setMode(mode) {
  currentMode = mode;
  document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
  event.target.classList.add('active');
  addMessage('system', 'Modo cambiado a: ' + mode.toUpperCase());
}
function addMessage(type, text) {
  const chatBox = document.getElementById('chatBox');
  const msg = document.createElement('div');
  msg.className = 'message ' + type + '-msg';
  msg.innerHTML = text.replace(/\n/g, '<br>');
  chatBox.appendChild(msg);
  chatBox.scrollTop = chatBox.scrollHeight;
}
function sendMessage() {
  const input = document.getElementById('userInput');
  const text = input.value.trim();
  if (!text) return;
  addMessage('user', text);
  input.value = '';
  document.getElementById('status').textContent = 'Generando video...';
  fetch('/generate', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({prompt: text, mode: currentMode, duration: 15})
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      addMessage('ai', 'Video generado exitosamente!<br><a class="video-link" href="/video/' + data.filename + '" target="_blank">Ver video</a><br>Guion: ' + (data.guion || 'N/A').substring(0, 200));
    } else {
      addMessage('ai', 'Error: ' + data.error);
    }
    document.getElementById('status').textContent = 'Listo para generar videos';
  })
  .catch(err => {
    addMessage('ai', 'Error de conexion: ' + err);
    document.getElementById('status').textContent = 'Error';
  });
}
</script>
</body>
</html>"""

class VideoChatHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/":
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(HTML_PAGE.encode())
        elif self.path.startswith("/video/"):
            filename = self.path.split("/video/")[1]
            filepath = STUDIO / "videos_generados" / filename
            if filepath.exists():
                self.send_response(200)
                self.send_header("Content-Type", "video/mp4")
                self.send_header("Content-Disposition", f"inline; filename={filename}")
                self.end_headers()
                with open(filepath, "rb") as f:
                    self.wfile.write(f.read())
            else:
                self.send_response(404)
                self.end_headers()
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path == "/generate":
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length).decode('utf-8')
            data = json.loads(body)
            prompt = data.get("prompt", "")
            mode = data.get("mode", "gemini")
            duration = data.get("duration", 15)

            # Run video generation in background
            result = run_video_generation(prompt, mode, duration)
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(result).encode())
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format, *args):
        pass

def run_video_generation(prompt, mode, duration):
    try:
        cmd = [sys.executable, str(STUDIO / "video_factory.py"),
               "--mode", mode, "--prompt", prompt, "--duration", str(duration)]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300,
                               cwd=str(STUDIO))
        # Find generated video
        videos = sorted((STUDIO / "videos_generados").glob("*.mp4"),
                       key=lambda f: f.stat().st_mtime, reverse=True)
        if videos and videos[0].stat().st_mtime > time.time() - 300:
            filename = videos[0].name
            # Try to read guion
            guion_files = sorted((STUDIO / "videos_generados").glob("*_guion.json"),
                               key=lambda f: f.stat().st_mtime, reverse=True)
            guion = ""
            if guion_files and guion_files[0].stat().st_mtime > time.time() - 300:
                guion = guion_files[0].read_text(encoding="utf-8")[:300]
            return {"success": True, "filename": filename, "guion": guion}
        else:
            return {"success": False, "error": result.stderr[:500] if result.stderr else "No video generated"}
    except subprocess.TimeoutExpired:
        return {"success": False, "error": "Timeout: video took too long to generate"}
    except Exception as e:
        return {"success": False, "error": str(e)}

if __name__ == "__main__":
    print(f"Kabalion Video Chat running on http://localhost:{PORT}")
    print(f"Abre tu navegador en: http://localhost:{PORT}")
    with socketserver.TCPServer(("", PORT), VideoChatHandler) as httpd:
        httpd.serve_forever()
