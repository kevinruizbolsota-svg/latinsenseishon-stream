import os
import sys
import hashlib
import subprocess
from pathlib import Path

BASE_DIR = Path(r"C:\Users\kevin\Videos_Limpiador")
INPUT_DIR = BASE_DIR / "originales"
OUTPUT_DIR = BASE_DIR / "limpios"
DUPLICADOS_DIR = BASE_DIR / "duplicados_eliminados"

INPUT_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
DUPLICADOS_DIR.mkdir(parents=True, exist_ok=True)

FFMPEG_PATH = r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe"
FFPROBE_PATH = r"C:\Users\kevin\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffprobe.exe"

def calcular_hash_video(archivo_path: Path):
    try:
        hasher = hashlib.md5()
        tamano = archivo_path.stat().st_size
        with open(archivo_path, "rb") as f:
            hasher.update(f.read(1024 * 1024))
            if tamano > 2 * 1024 * 1024:
                f.seek(-1024 * 1024, os.SEEK_END)
                hasher.update(f.read(1024 * 1024))
        return (hasher.hexdigest(), tamano)
    except Exception as e:
        return None

def obtener_dimensiones(archivo_path: Path):
    cmd = [
        FFPROBE_PATH,
        "-v", "error",
        "-select_streams", "v:0",
        "-show_entries", "stream=width,height",
        "-of", "csv=s=x:p=0",
        str(archivo_path)
    ]
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if res.returncode == 0 and res.stdout.strip():
        parts = res.stdout.strip().split("x")
        if len(parts) == 2:
            return int(parts[0]), int(parts[1])
    return 576, 1024

def limpiar_video(input_path: Path, output_path: Path):
    w, h = obtener_dimensiones(input_path)
    
    # Cobertura perfecta (35% de ancho y 10% de alto para cubrir nombres de usuarios largos)
    top_w = int(w * 0.35)
    top_h = int(h * 0.09)
    top_x = int(w * 0.015)
    top_y = int(h * 0.012)
    
    bot_w = int(w * 0.35)
    bot_h = int(h * 0.10)
    bot_x = w - bot_w - int(w * 0.015)
    bot_y = h - bot_h - int(h * 0.008)
    
    delogo_filter = f"delogo=x={top_x}:y={top_y}:w={top_w}:h={top_h},delogo=x={bot_x}:y={bot_y}:w={bot_w}:h={bot_h}"
    
    cmd = [
        FFMPEG_PATH,
        "-y",
        "-i", str(input_path),
        "-vf", delogo_filter,
        "-c:v", "libx264",
        "-preset", "fast",
        "-crf", "22",
        "-c:a", "copy",
        str(output_path)
    ]
    
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    return res.returncode == 0

def procesar_todo(lote_maximo=None, mover_duplicados=True):
    print("========================================================")
    print("   MOTOR AUTOMÁTICO DE LIMPIEZA & DEDUPLICACIÓN 700+    ")
    print("========================================================")
    archivos = list(INPUT_DIR.rglob("*.mp4")) + list(INPUT_DIR.rglob("*.MP4"))
    # Filtrar que no provengan de duplicados_eliminados
    archivos = [f for f in archivos if "duplicados_eliminados" not in str(f)]
    print(f"[+] Total de videos escaneados: {len(archivos)}")
    
    hashes_vistos = {}
    unicos = []
    duplicados = []
    
    for f in archivos:
        info_hash = calcular_hash_video(f)
        if not info_hash:
            continue
        if info_hash in hashes_vistos:
            duplicados.append(f)
        else:
            hashes_vistos[info_hash] = f
            unicos.append(f)
            
    print(f"[+] Videos únicos listos: {len(unicos)}")
    print(f"[-] Duplicados detectados: {len(duplicados)}")
    
    if mover_duplicados and duplicados:
        print("[*] Aislanto duplicados a la carpeta 'duplicados_eliminados' para ahorrar espacio...")
        for dup in duplicados:
            try:
                destino = DUPLICADOS_DIR / dup.name
                if not destino.exists():
                    dup.rename(destino)
                else:
                    dup.unlink() # Eliminar si ya existe copia aislada
            except Exception as e:
                pass
        print("[OK] Duplicados aislados y limpiados con éxito.")

    a_procesar = unicos if lote_maximo is None else unicos[:lote_maximo]
    print(f"\n[*] Procesando {len(a_procesar)} videos únicos...")
    
    exitosos = 0
    for idx, f in enumerate(a_procesar, 1):
        out_name = f"limpio_{idx}_{f.name}"
        out_path = OUTPUT_DIR / out_name
        if out_path.exists() and out_path.stat().st_size > 10000:
            print(f"[{idx}/{len(a_procesar)}] [SALTO] Ya limpio: {out_name}")
            exitosos += 1
            continue
            
        print(f"[{idx}/{len(a_procesar)}] Limpiando: {f.name}...")
        if limpiar_video(f, out_path):
            print(f"    -> [OK] Guardado en: {out_name}")
            exitosos += 1
        else:
            print(f"    -> [ERROR] Falló al limpiar {f.name}")
            
    print(f"\n[★] ¡FINALIZADO! {exitosos} videos limpios en:\n    {OUTPUT_DIR}")

if __name__ == "__main__":
    limite = None
    if len(sys.argv) > 1:
        try:
            limite = int(sys.argv[1])
        except:
            pass
    procesar_todo(limite)
